import { useEffect } from 'react';
import { useOnline } from './pwa';
import { NavLink, Navigate, Route, Routes } from 'react-router-dom';
import { NAV } from './nav';
import { useCareer } from './store';
import Dashboard from './pages/Dashboard';
import Profile from './pages/Profile';
import Login from './pages/Login';
import Creator from './pages/Creator';
import Settings from './pages/Settings';
import Trening from './pages/Trening';
import Zdrowie from './pages/Zdrowie';
import Kalendarz from './pages/Kalendarz';
import Walki from './pages/Walki';
import Finanse from './pages/Finanse';
import Federacje from './pages/Federacje';
import Rankingi from './pages/Rankingi';
import Sztab from './pages/Sztab';
import Media from './pages/Media';
import Historia from './pages/Historia';
import StagePlaceholder from './pages/StagePlaceholder';

export default function App() {
  const { fighter, status, init } = useCareer();
  const online = useOnline();
  useEffect(() => { void init(); }, [init]);
  if (status === 'loading') return <div className="h-full grid place-items-center text-mute">Ładowanie...</div>;
  if (status === 'anon') return <Login />;
  if (!fighter) {
    return (
      <Routes>
        <Route path="*" element={<Creator />} />
      </Routes>
    );
  }
  return (
    <div className="h-full flex flex-col md:flex-row">
      <aside className="fixed bottom-0 inset-x-0 z-40 md:static md:w-60 shrink-0 bg-panel border-t md:border-t-0 md:border-r border-line md:overflow-y-auto pb-[env(safe-area-inset-bottom)] md:pb-0">
        <div className="hidden md:block px-5 py-6 border-b border-line">
          <div className="font-display text-2xl font-extrabold leading-none">KSW <span className="text-red">Career</span></div>
          <div className="text-mute text-sm mt-1">Symulator kariery MMA</div>
        </div>
        <nav className="flex md:flex-col overflow-x-auto md:overflow-visible p-2 gap-1" aria-label="Główna nawigacja">
          {NAV.map((n) => (
            <NavLink
              key={n.path} to={n.path} end={n.path === '/'}
              className={({ isActive }) =>
                `whitespace-nowrap px-3 py-2 rounded text-sm font-medium flex items-center justify-between gap-3 ${
                  isActive ? 'bg-red text-white' : 'text-ink hover:bg-raised'
                }`}
            >
              {n.label}
              {n.stage > 1 && <span className="text-xs text-mute">etap {n.stage}</span>}
            </NavLink>
          ))}
        </nav>
      </aside>
      <main className="flex-1 overflow-y-auto p-4 md:p-8 pb-28 md:pb-8">
        {!online && <p className="mb-4 text-sm border border-line rounded px-3 py-2 bg-panel" role="status">Brak połączenia z internetem. Możesz przeglądać ekrany, ale akcje w grze wymagają sieci.</p>}
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/profil" element={<Profile />} />
          <Route path="/trening" element={<Trening />} />
          <Route path="/zdrowie" element={<Zdrowie />} />
          <Route path="/kalendarz" element={<Kalendarz />} />
          <Route path="/finanse" element={<Finanse />} />
          <Route path="/federacje" element={<Federacje />} />
          <Route path="/rankingi" element={<Rankingi />} />
          <Route path="/media" element={<Media />} />
          <Route path="/historia" element={<Historia />} />
          <Route path="/sztab" element={<Sztab />} />
          <Route path="/walki" element={<Walki />} />
          <Route path="/ustawienia" element={<Settings />} />
          {NAV.filter((n) => n.stage > 1).map((n) => (
            <Route key={n.path} path={n.path} element={<StagePlaceholder item={n} />} />
          ))}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
    </div>
  );
}
