import type { ReactNode } from 'react';

export function Panel({ title, children, className = '' }: { title?: string; children: ReactNode; className?: string }) {
  return (
    <section className={`bg-panel border border-line rounded-md p-4 ${className}`}>
      {title && <h2 className="font-display text-xl font-bold tracking-wide mb-3">{title}</h2>}
      {children}
    </section>
  );
}

export function Meter({ label, value, invert = false }: { label: string; value: number; invert?: boolean }) {
  const good = invert ? 100 - value : value;
  const color = good >= 65 ? 'bg-ink' : good >= 35 ? 'bg-mute' : 'bg-red';
  return (
    <div>
      <div className="flex justify-between text-sm mb-1">
        <span className="text-mute">{label}</span>
        <span className="font-semibold tabular-nums">{Math.round(value)}</span>
      </div>
      <div className="h-1.5 bg-raised rounded-full overflow-hidden" role="meter" aria-label={label} aria-valuenow={value} aria-valuemin={0} aria-valuemax={100}>
        <div className={`h-full ${color} transition-[width] duration-300`} style={{ width: `${Math.min(100, Math.max(0, value))}%` }} />
      </div>
    </div>
  );
}

export function Empty({ children }: { children: ReactNode }) {
  return <p className="text-mute text-sm border border-dashed border-line rounded p-3">{children}</p>;
}
