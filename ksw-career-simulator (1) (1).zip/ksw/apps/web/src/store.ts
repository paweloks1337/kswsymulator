import { create } from 'zustand';
import type { Attribute, Fighter, FighterProfile, FightFrame, FightResult, Injury, RoundSummary, Tactics, World } from '@ksw/engine';
import { api, ApiError, getToken, setToken } from './api';

type Status = 'loading' | 'anon' | 'ready';
type TrainOutcome = { ok: true; gains: Partial<Record<Attribute, number>>; injury?: Injury } | { ok: false; reason: string };
type State2 = { fighter: Fighter | null; world: World | null };
export type RoundOutcome =
  | { ok: true; summary: RoundSummary; frames: FightFrame[]; maxHp: [number, number]; result?: FightResult; injury?: Injury; opponent: string }
  | { ok: false; reason: string };

interface CareerState extends State2 {
  status: Status;
  init: () => Promise<void>;
  authenticate: (mode: 'login' | 'register', email: string, password: string) => Promise<void>;
  logout: () => void;
  startCareer: (profile: FighterProfile) => Promise<string | null>;
  resetCareer: () => Promise<void>;
  train: (activityId: string) => Promise<TrainOutcome>;
  rest: (days: number) => Promise<string | null>;
  acceptOffer: (federationId: string) => Promise<string | null>;
  fightStart: (t: Tactics) => Promise<RoundOutcome>;
  fightNext: (t: Tactics) => Promise<RoundOutcome>;
  mediaAction: (id: string) => Promise<{ ok: true; text: string; good: boolean } | { ok: false; reason: string }>;
  signSponsor: (id: string) => Promise<string | null>;
  changeLifestyle: (kind: 'housing' | 'car' | 'gym', id?: string) => Promise<string | null>;
  hireStaff: (candidateId: string) => Promise<string | null>;
  fireStaff: (staffId: string) => Promise<string | null>;
}

export const useCareer = create<CareerState>()((set, get) => {
  const load = async () => { const r = await api<State2>('/career'); set({ status: 'ready', fighter: r.fighter, world: r.world }); };
  const act = async <T extends State2>(path: string, body: unknown): Promise<T> => {
    const r = await api<T>(path, 'POST', body); set({ fighter: r.fighter, world: r.world }); return r;
  };
  type R = State2 & { summary: RoundSummary; frames: FightFrame[]; result?: FightResult; injury?: Injury };
  const round = async (path: string, t: Tactics): Promise<RoundOutcome> => {
    const before = get().fighter;
    const oppId = before?.activeFight?.opponentId ?? before?.nextFight?.opponentId;
    const opponent = get().world?.npcs.find((n) => n.id === oppId)?.name ?? 'Rywal';
    try {
      const r = await act<R>(path, t);
      const maxHp = r.result?.maxHp ?? r.fighter!.activeFight!.state.maxHp;
      return { ok: true, summary: r.summary, frames: r.frames, maxHp, result: r.result, injury: r.injury, opponent };
    } catch (e) { return { ok: false, reason: (e as Error).message }; }
  };
  return {
    status: 'loading', fighter: null, world: null,
    init: async () => {
      if (!getToken()) return set({ status: 'anon' });
      try { await load(); } catch (e) { if (e instanceof ApiError && e.status === 401) setToken(null); set({ status: 'anon' }); }
    },
    authenticate: async (mode, email, password) => {
      const { token } = await api<{ token: string }>(`/auth/${mode}`, 'POST', { email, password });
      setToken(token); await load();
    },
    logout: () => { setToken(null); set({ status: 'anon', fighter: null, world: null }); },
    startCareer: async (profile) => { try { await act('/career', profile); return null; } catch (e) { return (e as Error).message; } },
    resetCareer: async () => { await api('/career', 'DELETE'); set({ fighter: null, world: null }); },
    train: async (activityId) => {
      try { const r = await act<State2 & { gains: Partial<Record<Attribute, number>>; injury?: Injury }>('/career/train', { activityId }); return { ok: true, gains: r.gains, injury: r.injury }; }
      catch (e) { return { ok: false, reason: (e as Error).message }; }
    },
    rest: async (days) => { try { await act('/career/rest', { days }); return null; } catch (e) { return (e as Error).message; } },
    acceptOffer: async (federationId) => { try { await act('/career/offers/accept', { federationId }); return null; } catch (e) { return (e as Error).message; } },
    mediaAction: async (id) => {
      try { const r = await act<State2 & { text: string; good: boolean }>('/career/media', { id }); return { ok: true, text: r.text, good: r.good }; }
      catch (e) { return { ok: false, reason: (e as Error).message }; }
    },
    signSponsor: async (id) => { try { await act('/career/sponsor/sign', { id }); return null; } catch (e) { return (e as Error).message; } },
    changeLifestyle: async (kind, id) => { try { await act('/career/lifestyle', { kind, id }); return null; } catch (e) { return (e as Error).message; } },
    hireStaff: async (id) => { try { await act('/career/staff/hire', { id }); return null; } catch (e) { return (e as Error).message; } },
    fireStaff: async (id) => { try { await act('/career/staff/fire', { id }); return null; } catch (e) { return (e as Error).message; } },
    fightStart: (t) => round('/career/fight/start', t),
    fightNext: (t) => round('/career/fight/round', t),
  };
});
