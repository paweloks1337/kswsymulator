export interface NavItem { path: string; label: string; stage: number; blurb: string }

// stage 1 = gotowe w tym etapie; wyższe numery pokazują ekran ze statusem, a nie atrapę.
export const NAV: NavItem[] = [
  { path: '/', label: 'Dashboard', stage: 1, blurb: '' },
  { path: '/profil', label: 'Profil zawodnika', stage: 1, blurb: '' },
  { path: '/trening', label: 'Trening', stage: 1, blurb: 'Aktywności treningowe z kosztem, intensywnością, zmęczeniem, ryzykiem kontuzji i malejącymi zyskami.' },
  { path: '/sztab', label: 'Sztab', stage: 1, blurb: 'Trenerzy, fizjoterapeuta i menedżer z umiejętnościami, reputacją i wynagrodzeniem.' },
  { path: '/zdrowie', label: 'Zdrowie', stage: 1, blurb: 'Regeneracja, sen, nawodnienie oraz kontuzje z czasem leczenia i kosztem rehabilitacji.' },
  { path: '/federacje', label: 'Federacje', stage: 1, blurb: 'Fikcyjne organizacje MMA, kategorie wagowe, mistrzowie, gale i kontrakty.' },
  { path: '/walki', label: 'Walki', stage: 1, blurb: 'Symulacja walki z AI obu zawodników i wizualizacją 3D.' },
  { path: '/rankingi', label: 'Rankingi', stage: 1, blurb: 'Rankingi federacji w każdej kategorii wagowej.' },
  { path: '/media', label: 'Media', stage: 1, blurb: 'Wywiady, face-offy, trash talk i ich konsekwencje.' },
  { path: '/finanse', label: 'Finanse', stage: 1, blurb: 'Przychody, wydatki, sponsorzy, mieszkanie i sprzęt.' },
  { path: '/kalendarz', label: 'Kalendarz', stage: 1, blurb: 'Przewijanie czasu, terminy walk i kontraktów.' },
  { path: '/historia', label: 'Historia', stage: 1, blurb: 'Przebieg kariery i raporty z walk.' },
  { path: '/ustawienia', label: 'Ustawienia', stage: 1, blurb: '' },
];
