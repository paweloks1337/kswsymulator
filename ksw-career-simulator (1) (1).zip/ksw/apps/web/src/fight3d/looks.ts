import { APPEARANCE_OPTIONS, type Fighter, type Npc, WEIGHT_CLASSES } from '@ksw/engine';

export type HairStyle = (typeof APPEARANCE_OPTIONS.hair)[number];
export type TattooStyle = (typeof APPEARANCE_OPTIONS.tattoos)[number];
export interface Look {
  heightM: number; build: number; skin: string; hair: string; hairStyle: HairStyle;
  beard: boolean; kit: string; tattoos: TattooStyle;
}

const KIT: Record<string, string> = { Czerwony: '#c2181f', Czarny: '#17171a', Biały: '#e6e6e6', Grafitowy: '#4a4d55' };
const BUILD: Record<string, number> = { Szczupła: 0.88, Atletyczna: 1, Muskularna: 1.12, Masywna: 1.25 };
const SKIN = ['#f1c9a5', '#e0ac82', '#c68642', '#a06a44', '#7b4a2d'];
const HAIR = ['#1b1410', '#3a2618', '#6b4a2b', '#a77b45', '#2a2a2a'];
const weightFactor = (kg: number) => Math.pow(Math.min(1.4, Math.max(0.75, kg / 77)), 0.3);

function hash(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
  return h >>> 0;
}

export function lookFromFighter(f: Fighter): Look {
  const p = f.profile, h = hash(f.id);
  return {
    heightM: p.heightCm / 100, build: (BUILD[p.appearance.build] ?? 1) * weightFactor(p.weightKg),
    skin: SKIN[h % SKIN.length]!, hair: HAIR[(h >> 3) % HAIR.length]!, hairStyle: p.appearance.hair,
    beard: p.appearance.beard !== 'Brak', kit: KIT[p.appearance.kit] ?? '#c2181f', tattoos: p.appearance.tattoos,
  };
}

export function lookFromNpc(n: Npc): Look {
  const h = hash(n.id);
  const wc = WEIGHT_CLASSES.find((c) => c.id === n.weightClassId) ?? WEIGHT_CLASSES[2]!;
  const styles = APPEARANCE_OPTIONS.hair, tattoos = APPEARANCE_OPTIONS.tattoos;
  return {
    heightM: 1.7 + ((wc.maxKg - 66) / 54) * 0.18 + ((h >> 5) % 5) / 100,
    build: (0.95 + ((h >> 7) % 4) * 0.08) * weightFactor(wc.maxKg),
    skin: SKIN[h % SKIN.length]!, hair: HAIR[(h >> 3) % HAIR.length]!, hairStyle: styles[(h >> 9) % styles.length]!,
    beard: (h >> 11) % 3 === 0, kit: '#1f4fa8', tattoos: tattoos[(h >> 13) % tattoos.length]!,
  };
}
