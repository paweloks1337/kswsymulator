import { Component, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import * as THREE from 'three';
import { isLowPower } from '../pwa';
import type { FightFrame } from '@ksw/engine';
import { commentary, frameInfo, type Sim } from './choreo';
import Fighter3D from './Fighter3D';
import Octagon from './Octagon';
import type { Look } from './looks';

type Cam = 'side' | 'corner' | 'top';
const CAMS: Record<Cam, string> = { side: 'Z boku', corner: 'Z narożnika', top: 'Z góry' };
const METHOD = { KO: 'KO', TKO: 'TKO', SUB: 'poddanie', DEC: 'decyzja sędziów', DRAW: 'remis' } as const;

function Playback({ sim, onTick, onDone }: { sim: React.MutableRefObject<Sim>; onTick: (i: number) => void; onDone: (d: boolean) => void }) {
  const last = useRef(-1);
  const wasDone = useRef(false);
  const { gl, setDpr } = useThree();
  const slow = useRef({ t: 0, n: 0 });
  useFrame((_, dt) => {
    const s = sim.current;
    s.time += dt;
    // adaptacyjna rozdzielczość: gdy średnio poniżej ok. 40 FPS przez 2 s, obniż jakość
    const m = slow.current; m.t += dt; m.n++;
    if (m.t >= 2) {
      if (m.n / m.t < 40) { const cur = gl.getPixelRatio(); if (cur > 0.75) setDpr(Math.max(0.75, cur * 0.8)); }
      m.t = 0; m.n = 0;
    }
    if (s.playing && s.t < s.frames.length) s.t = Math.min(s.frames.length, s.t + dt * s.speed);
    const { idx } = frameInfo(s);
    if (idx !== last.current) { last.current = idx; onTick(idx); }
    const d = s.frames.length > 0 && s.t >= s.frames.length;
    if (d !== wasDone.current) { wasDone.current = d; onDone(d); }
  });
  return null;
}

function CameraRig({ sim, mode }: { sim: React.MutableRefObject<Sim>; mode: Cam }) {
  const { camera } = useThree();
  const look = useRef(new THREE.Vector3(0, 1, 0));
  useFrame((_, dt) => {
    const s = sim.current;
    const f = s.frames[frameInfo(s).idx];
    const ground = !!f?.ground;
    const k = 1 - Math.exp(-3 * dt);
    const t = s.time;
    let pos: [number, number, number], tgt: [number, number, number];
    if (mode === 'top') { pos = [0, 6.5, 0.01]; tgt = [0, 0, 0]; }
    else if (mode === 'corner') { pos = ground ? [2.2, 1.4, 2.2] : [3.4, 1.8, 3.4]; tgt = [0, ground ? 0.4 : 1, 0]; }
    else { pos = ground ? [Math.sin(t * 0.2) * 0.8, 1.3, 3.0] : [Math.sin(t * 0.15) * 0.6, 1.55, 4.6]; tgt = [0, ground ? 0.4 : 1.0, 0]; }
    camera.position.lerp(new THREE.Vector3(...pos), k);
    look.current.lerp(new THREE.Vector3(...tgt), k);
    camera.lookAt(look.current);
  });
  return null;
}

class Boundary extends Component<{ children: ReactNode }, { failed: boolean }> {
  state = { failed: false };
  static getDerivedStateFromError() { return { failed: true }; }
  render() {
    return this.state.failed
      ? <div className="h-full grid place-items-center p-6 text-center text-mute">Nie udało się uruchomić grafiki 3D na tym urządzeniu (WebGL). Wynik walki jest widoczny w tekście.</div>
      : this.props.children;
  }
}

export interface FinalInfo { winner: 0 | 1 | null; method: keyof typeof METHOD; round: number }
interface Props { frames: FightFrame[]; maxHp: [number, number]; final: FinalInfo | null; roundLabel: string; names: [string, string]; looks: [Look, Look]; onClose: () => void }

export default function FightViewer({ frames, maxHp, final, roundLabel, names, looks, onClose }: Props) {
  const sim = useRef<Sim>({ t: 0, speed: 1, playing: true, frames, time: 0 });
  const [tick, setTick] = useState(0);
  const [speed, setSpeed] = useState(1);
  const [playing, setPlaying] = useState(true);
  const [cam, setCam] = useState<Cam>('side');
  const [done, setDone] = useState(false);
  const shadows = useMemo(() => typeof window !== 'undefined' && window.matchMedia('(min-width: 900px) and (pointer: fine)').matches, []);
  useEffect(() => { sim.current.frames = frames; sim.current.t = 0; setTick(0); setDone(false); }, [frames]);
  useEffect(() => { sim.current.speed = speed; sim.current.playing = playing; }, [speed, playing]);

  const f = frames[Math.min(tick, frames.length - 1)]!;
  const clock = Math.min(300, f.sec + 5);
  const hpPct = (i: 0 | 1) => `${Math.round((f.hp[i] / maxHp[i]) * 100)}%`;
  const btn = (on: boolean) => `px-3 py-2.5 rounded text-sm border ${on ? 'bg-red border-red text-white' : 'border-line bg-raised'}`;

  return (
    <div className="fixed inset-0 z-50 bg-base flex flex-col">
      <div className="p-3 pt-[max(0.75rem,env(safe-area-inset-top))] grid grid-cols-[1fr_auto_1fr] items-center gap-3 bg-panel border-b border-line">
        {([0, 1] as const).map((i) => (
          <div key={i} className={i === 1 ? 'col-start-3 text-right' : 'col-start-1'}>
            <div className="font-display text-xl font-bold truncate">{names[i]}</div>
            <div className="h-2 bg-raised rounded-full overflow-hidden"><div className={`h-full bg-red ${i === 1 ? 'ml-auto' : ''}`} style={{ width: hpPct(i) }} /></div>
            <div className="h-1 mt-1 bg-raised rounded-full overflow-hidden"><div className={`h-full bg-mute ${i === 1 ? 'ml-auto' : ''}`} style={{ width: `${Math.round(f.stamina[i])}%` }} /></div>
          </div>
        ))}
        <div className="col-start-2 row-start-1 text-center">
          <div className="font-display text-2xl font-bold tabular-nums">R{f.round} {Math.floor(clock / 60)}:{String(clock % 60).padStart(2, '0')}</div>
        </div>
      </div>
      <div className="flex-1 relative min-h-0">
        <Boundary>
          <Canvas shadows={shadows} dpr={isLowPower() ? [1, 1.25] : [1, 2]} camera={{ fov: 40, position: [0, 1.6, 4.6] }} gl={{ antialias: true }}>
            <color attach="background" args={['#050506']} />
            <fog attach="fog" args={['#050506', 9, 22]} />
            <hemisphereLight args={['#ffffff', '#1a1a1f', 0.8]} />
            <directionalLight position={[3, 6, 4]} intensity={1.6} castShadow={shadows} shadow-mapSize={[1024, 1024]} shadow-camera-left={-5} shadow-camera-right={5} shadow-camera-top={5} shadow-camera-bottom={-5} />
            <spotLight position={[0, 8, 0]} angle={0.8} penumbra={0.7} intensity={70} color="#ffe9e0" />
            <Octagon />
            <Fighter3D sim={sim} index={0} look={looks[0]} shadows={shadows} />
            <Fighter3D sim={sim} index={1} look={looks[1]} shadows={shadows} />
            <CameraRig sim={sim} mode={cam} />
            <Playback sim={sim} onTick={setTick} onDone={setDone} />
          </Canvas>
        </Boundary>
        <div className="absolute left-0 right-0 bottom-3 text-center pointer-events-none px-4">
          {done ? (
            <div className="inline-block bg-black/80 border border-line rounded px-5 py-3">
              {final ? (<>
                <div className="font-display text-3xl font-extrabold">{final.winner === null ? 'Remis' : `${names[final.winner]} wygrywa`}</div>
                <div className="text-mute">{METHOD[final.method]}, runda {final.round}</div></>) : (<>
                <div className="font-display text-3xl font-extrabold">Koniec rundy {roundLabel}</div>
                <div className="text-mute">Przejdź do przerwy, aby zmienić taktykę</div></>)}
            </div>
          ) : <span className="inline-block bg-black/70 rounded px-3 py-1 text-sm">{commentary(f, names)}</span>}
        </div>
      </div>
      <div className="p-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] flex flex-wrap gap-2 items-center bg-panel border-t border-line">
        <button className={btn(false)} onClick={() => { if (done) { sim.current.t = 0; setPlaying(true); } else setPlaying(!playing); }}>{done ? 'Od nowa' : playing ? 'Pauza' : 'Graj'}</button>
        {[1, 2, 4].map((v) => <button key={v} className={btn(speed === v)} onClick={() => setSpeed(v)}>{v}x</button>)}
        <button className={btn(false)} onClick={() => { sim.current.t = frames.length; }}>Pomiń</button>
        <span className="mx-1 text-line">|</span>
        {(Object.keys(CAMS) as Cam[]).map((c) => <button key={c} className={btn(cam === c)} onClick={() => setCam(c)}>{CAMS[c]}</button>)}
        <button className="ml-auto px-4 py-1.5 rounded bg-raised border border-line" onClick={onClose}>{done && !final ? 'Przerwa' : 'Zamknij'}</button>
      </div>
    </div>
  );
}
