import { useMemo, useRef, type MutableRefObject } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { endedFor, frameInfo, JOINTS, layoutFor, poseFor, type Sim } from './choreo';
import type { Look } from './looks';

interface Props { sim: MutableRefObject<Sim>; index: 0 | 1; look: Look; shadows: boolean }

const dampAngle = (cur: number, target: number, lambda: number, dt: number) => {
  const d = ((((target - cur + Math.PI) % (2 * Math.PI)) + 2 * Math.PI) % (2 * Math.PI)) - Math.PI;
  return cur + d * (1 - Math.exp(-lambda * dt));
};

/** Postać złożona ze szkieletu grup (biodra, kręgosłup, barki, łokcie, uda, kolana) z proporcjami z wzrostu i budowy. */
export default function Fighter3D({ sim, index, look, shadows }: Props) {
  const h = look.heightM, b = look.build;
  const refs = useRef<Record<string, THREE.Object3D | null>>({});
  const outer = useRef<THREE.Group>(null);
  const lay = useRef<THREE.Group>(null);
  const set = (k: string) => (o: THREE.Object3D | null) => { refs.current[k] = o; };

  const mats = useMemo(() => ({
    skin: new THREE.MeshStandardMaterial({ color: look.skin, roughness: 0.65 }),
    hair: new THREE.MeshStandardMaterial({ color: look.hair, roughness: 0.9 }),
    kit: new THREE.MeshStandardMaterial({ color: look.kit, roughness: 0.55 }),
    glove: new THREE.MeshStandardMaterial({ color: look.kit === '#17171a' ? '#8c1017' : '#17171a', roughness: 0.4 }),
    ink: new THREE.MeshStandardMaterial({ color: '#1d2b44', roughness: 0.8 }),
  }), [look]);

  const thigh = 0.25 * h, shin = 0.25 * h, upper = 0.17 * h, fore = 0.15 * h;
  const rT = 0.062 * h * b, rS = 0.042 * h * b, rU = 0.04 * h * b, rF = 0.033 * h * b;

  const limb = (len: number, r: number, mat: THREE.Material, key?: string) => (
    <mesh position={[0, -len / 2, 0]} castShadow={shadows} material={mat} key={key}>
      <capsuleGeometry args={[r, Math.max(0.01, len - 2 * r), 4, 10]} />
    </mesh>
  );

  useFrame((_, dt) => {
    const s = sim.current;
    if (!s.frames.length || !outer.current || !lay.current) return;
    const { idx, phase } = frameInfo(s);
    const frame = s.frames[idx]!;
    const ended = idx === s.frames.length - 1 ? endedFor(frame, index) : null;
    const L = layoutFor(frame, index, phase, s.time, h, ended);
    const role = ended === 'ko' && L.role === 'stand' ? 'stand' : L.role;
    const m = poseFor(role, frame.actions[index], frame.actions[1 - index as 0 | 1], phase, s.time, ended);
    const o = outer.current;
    o.position.x = THREE.MathUtils.damp(o.position.x, L.x, 7, dt);
    o.position.y = THREE.MathUtils.damp(o.position.y, L.rootY, 9, dt);
    o.rotation.y = dampAngle(o.rotation.y, L.yaw, 9, dt);
    lay.current.rotation.x = THREE.MathUtils.damp(lay.current.rotation.x, L.lay, 8, dt);
    lay.current.position.z = THREE.MathUtils.damp(lay.current.position.z, m.lunge, 12, dt);
    for (const j of JOINTS) {
      const node = refs.current[j]; if (!node) continue;
      const t = m.pose[j];
      node.rotation.x = THREE.MathUtils.damp(node.rotation.x, t[0], 16, dt);
      node.rotation.y = THREE.MathUtils.damp(node.rotation.y, t[1], 16, dt);
      node.rotation.z = THREE.MathUtils.damp(node.rotation.z, t[2], 16, dt);
    }
  });

  const shoulderX = 0.115 * h * b;
  const arm = (side: 1 | -1) => (
    <group ref={set(side === 1 ? 'shL' : 'shR')} position={[side * shoulderX, 0.005 * h, 0]}>
      {limb(upper, rU, mats.skin)}
      {look.tattoos === 'Ramiona' || look.tattoos === 'Pełne' ? (
        <mesh position={[0, -upper * 0.45, 0]} material={mats.ink}><cylinderGeometry args={[rU * 1.06, rU * 1.06, upper * 0.35, 12]} /></mesh>
      ) : null}
      <group ref={set(side === 1 ? 'elL' : 'elR')} position={[0, -upper, 0]}>
        {limb(fore, rF, mats.skin)}
        <mesh position={[0, -fore - 0.02 * h, 0.01]} material={mats.glove} castShadow={shadows}>
          <sphereGeometry args={[0.05 * h, 14, 12]} />
        </mesh>
      </group>
    </group>
  );
  const leg = (side: 1 | -1) => (
    <group ref={set(side === 1 ? 'hipL' : 'hipR')} position={[side * 0.055 * h * b, -0.03 * h, 0]}>
      {limb(thigh, rT, mats.skin)}
      <group ref={set(side === 1 ? 'knL' : 'knR')} position={[0, -thigh, 0]}>
        {limb(shin, rS, mats.skin)}
        <mesh position={[0, -shin - 0.01 * h, 0.04 * h]} material={mats.skin} castShadow={shadows}><boxGeometry args={[0.07 * h * b, 0.035 * h, 0.14 * h]} /></mesh>
      </group>
    </group>
  );

  return (
    <group ref={outer} position={[index === 0 ? -0.85 : 0.85, 0.46 * h, 0]} rotation-y={index === 0 ? Math.PI / 2 : -Math.PI / 2}>
      <group ref={lay}>
        {/* miednica i spodenki */}
        <mesh material={mats.kit} castShadow={shadows} position={[0, -0.01 * h, 0]} scale={[1.25 * b, 0.9, 0.9]}>
          <capsuleGeometry args={[0.075 * h, 0.04 * h, 4, 12]} />
        </mesh>
        <mesh position={[0, 0.045 * h, 0]} material={mats.glove}><cylinderGeometry args={[0.093 * h * b, 0.093 * h * b, 0.018 * h, 16]} /></mesh>
        {leg(1)}{leg(-1)}
        <group ref={set('spine')} position={[0, 0.04 * h, 0]}>
          <mesh position={[0, 0.12 * h, 0]} material={mats.skin} castShadow={shadows} scale={[1.2 * b, 1, 0.78 * (0.9 + 0.1 * b)]}>
            <capsuleGeometry args={[0.095 * h, 0.12 * h, 4, 14]} />
          </mesh>
          {look.tattoos === 'Tułów' || look.tattoos === 'Pełne' ? (
            <mesh position={[0, 0.14 * h, 0.077 * h * (0.9 + 0.1 * b)]} material={mats.ink}><boxGeometry args={[0.1 * h * b, 0.09 * h, 0.004 * h]} /></mesh>
          ) : null}
          <group ref={set('chest')} position={[0, 0.25 * h, 0]}>
            {arm(1)}{arm(-1)}
            <group ref={set('neck')} position={[0, 0.03 * h, 0]}>
              <mesh position={[0, 0.02 * h, 0]} material={mats.skin}><cylinderGeometry args={[0.032 * h * b, 0.036 * h * b, 0.05 * h, 10]} /></mesh>
              <group ref={set('head')} position={[0, 0.095 * h, 0]}>
                <mesh material={mats.skin} castShadow={shadows} scale={[0.92, 1.1, 1]}><sphereGeometry args={[0.062 * h, 20, 16]} /></mesh>
                <mesh position={[0, -0.005 * h, 0.062 * h]} material={mats.skin}><boxGeometry args={[0.014 * h, 0.03 * h, 0.02 * h]} /></mesh>
                {look.hairStyle !== 'Łysy' && (
                  <mesh position={[0, 0.012 * h, -0.004 * h]} material={mats.hair} scale={look.hairStyle === 'Zaczes' ? [0.96, 1.15, 1.08] : [0.95, 1.08, 1.03]}>
                    <sphereGeometry args={[0.065 * h, 18, 12, 0, Math.PI * 2, 0, look.hairStyle === 'Dłuższe' ? Math.PI * 0.62 : Math.PI * 0.46]} />
                  </mesh>
                )}
                {look.hairStyle === 'Irokez' && <mesh position={[0, 0.07 * h, 0]} material={mats.hair}><boxGeometry args={[0.012 * h, 0.035 * h, 0.1 * h]} /></mesh>}
                {look.beard && (
                  <mesh position={[0, -0.032 * h, 0.03 * h]} material={mats.hair} scale={[0.88, 0.6, 0.85]}>
                    <sphereGeometry args={[0.058 * h, 14, 10, 0, Math.PI * 2, Math.PI * 0.45, Math.PI * 0.55]} />
                  </mesh>
                )}
              </group>
            </group>
          </group>
        </group>
      </group>
    </group>
  );
}
