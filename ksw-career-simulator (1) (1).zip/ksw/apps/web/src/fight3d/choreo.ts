import type { FightAction, FightFrame } from '@ksw/engine';

export type V3 = [number, number, number];
export const JOINTS = ['spine', 'chest', 'neck', 'head', 'shL', 'elL', 'shR', 'elR', 'hipL', 'knL', 'hipR', 'knR'] as const;
export type JointName = (typeof JOINTS)[number];
export type Pose = Record<JointName, V3>;
export type Role = 'stand' | 'top' | 'bottom';
export type Ended = null | 'win' | 'ko' | 'tap' | 'lose' | 'draw';

/** Stan odtwarzania, współdzielony przez ref (bez rerenderów Reacta co klatkę). */
export interface Sim {
  t: number; speed: number; playing: boolean; frames: FightFrame[]; time: number;
}

export interface Layout { x: number; yaw: number; role: Role; rootY: number; lay: number }
export interface Motion { pose: Pose; lunge: number }

const clamp01 = (v: number) => Math.min(1, Math.max(0, v));
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
const arc = (x: number) => Math.sin(Math.PI * clamp01(x));
const STRIKE = new Set(['punch', 'kick', 'knee']);

export function frameInfo(sim: Sim): { idx: number; phase: number; done: boolean } {
  const n = sim.frames.length;
  if (n === 0) return { idx: 0, phase: 0, done: false };
  if (sim.t >= n) return { idx: n - 1, phase: 1, done: true };
  const idx = Math.max(0, Math.floor(sim.t));
  return { idx, phase: sim.t - idx, done: false };
}

export function endedFor(frame: FightFrame, i: 0 | 1): Ended {
  if (!frame.end) return null;
  if (frame.winner === null || frame.winner === undefined) return 'draw';
  if (frame.winner === i) return 'win';
  return frame.end === 'SUB' ? 'tap' : frame.end === 'KO' || frame.end === 'TKO' ? 'ko' : 'lose';
}

function separation(frame: FightFrame, phase: number): number {
  let sep = 1.7;
  const e = arc(((phase * 2) % 1) / 0.6);
  for (const a of frame.actions) {
    if (a.kind === 'punch') sep = Math.min(sep, lerp(1.7, 1.2, e));
    else if (a.kind === 'kick' || a.kind === 'knee') sep = Math.min(sep, lerp(1.7, 1.45, e));
    else if (a.kind === 'takedown') sep = Math.min(sep, lerp(1.7, 0.6, clamp01(phase * 1.5)));
  }
  return sep;
}

/** Gdzie stoi zawodnik i jaką rolę ma w tej klatce. h = wzrost w metrach. */
export function layoutFor(frame: FightFrame, i: 0 | 1, phase: number, time: number, h: number, ended: Ended): Layout {
  const k = h / 1.8;
  if (frame.ground && frame.top !== null) {
    return frame.top === i
      ? { x: 0.05, yaw: -Math.PI / 2, role: 'top', rootY: 0.47 * k, lay: 0 }
      : { x: 0, yaw: Math.PI / 2, role: 'bottom', rootY: 0.2 * k, lay: -Math.PI / 2 };
  }
  const dir = i === 0 ? -1 : 1;
  const sway = Math.sin(time * 0.9) * 0.08;
  const x = dir * (separation(frame, phase) / 2) + sway;
  const yaw = i === 0 ? Math.PI / 2 : -Math.PI / 2;
  if (ended === 'ko') return { x: x + dir * 0.5, yaw, role: 'stand', rootY: 0.2 * k, lay: -Math.PI / 2 };
  return { x, yaw, role: 'stand', rootY: 0.46 * h, lay: 0 };
}

const base = (): Pose => ({
  spine: [-0.08, 0, 0], chest: [0, 0, 0], neck: [0.1, 0, 0], head: [0, 0, 0],
  shL: [-0.9, 0, 0.25], elL: [-1.8, 0, 0], shR: [-0.9, 0, -0.25], elR: [-1.8, 0, 0],
  hipL: [-0.3, 0, 0.12], knL: [0.35, 0, 0], hipR: [0.3, 0, -0.12], knR: [0.45, 0, 0],
});

export function poseFor(role: Role, me: FightAction, opp: FightAction, phase: number, time: number, ended: Ended): Motion {
  const p = base();
  let lunge = 0;
  const cyc = (phase * 2) % 1;
  const s = arc(cyc / 0.6);
  const second = Math.floor(phase * 2) % 2 === 1;
  const incoming = STRIKE.has(opp.kind);
  const hitW = arc(((cyc - 0.3) / 0.3));

  if (ended === 'win') {
    p.shL = [-2.8, 0, 0.3]; p.shR = [-2.8, 0, -0.3]; p.elL = [-0.3, 0, 0]; p.elR = [-0.3, 0, 0];
    return { pose: p, lunge };
  }
  if (ended === 'ko' || ended === 'lose' || ended === 'draw') {
    if (ended === 'ko') {
      p.shL = [0.1, 0, 0.4]; p.shR = [0.1, 0, -0.4]; p.elL = [-0.3, 0, 0]; p.elR = [-0.3, 0, 0];
      p.hipL = [-0.1, 0, 0.15]; p.hipR = [-0.1, 0, -0.15]; p.knL = [0.1, 0, 0]; p.knR = [0.1, 0, 0]; p.head = [0.2, 0.3, 0];
      return { pose: p, lunge };
    }
    p.shL = [-0.2, 0, 0.2]; p.shR = [-0.2, 0, -0.2]; p.elL = [-0.5, 0, 0]; p.elR = [-0.5, 0, 0];
    return { pose: p, lunge };
  }

  if (role === 'bottom') {
    p.hipL = [-1.25, 0, 0.5]; p.hipR = [-1.25, 0, -0.5]; p.knL = [1.7, 0, 0]; p.knR = [1.7, 0, 0];
    p.spine = [0, 0, 0]; p.shL = [-0.7, 0, 0.3]; p.shR = [-0.7, 0, -0.3]; p.elL = [-1.5, 0, 0]; p.elR = [-1.5, 0, 0];
    if (ended === 'tap') { p.shR = [-1.1, 0, -0.5]; p.elR = [-0.3 + Math.sin(time * 20) * 0.4, 0, 0]; }
    else if (opp.kind === 'gnp' && opp.hit) { p.neck = [0.1 + 0.5 * hitW, 0, 0]; p.head = [0, 0.3 * hitW, 0]; }
    else if (opp.kind === 'sub') { p.hipL = [-1.0, 0, 0.9]; p.hipR = [-1.0, 0, -0.9]; p.shL = [-1.4, 0, 0.1]; p.shR = [-1.4, 0, -0.1]; }
    else if (me.kind === 'escape') { p.hipL = [-1.6, 0, 0.9]; }
    return { pose: p, lunge };
  }

  if (role === 'top') {
    p.hipL = [-0.6, 0, 0.35]; p.hipR = [-0.6, 0, -0.35]; p.knL = [2.17, 0, 0]; p.knR = [2.17, 0, 0];
    p.spine = [-0.55, 0, 0]; p.neck = [0.5, 0, 0];
    p.shL = [-1.0, 0, 0.2]; p.shR = [-1.0, 0, -0.2]; p.elL = [-0.5, 0, 0]; p.elR = [-0.5, 0, 0];
    if (me.kind === 'gnp') {
      const c3 = (phase * 3) % 1, a3 = arc(c3 / 0.6), right = Math.floor(phase * 3) % 2 === 1;
      const key = right ? 'shR' : 'shL', ek = right ? 'elR' : 'elL';
      p[key] = [lerp(-0.7, -1.7, a3), 0, right ? -0.2 : 0.2]; p[ek] = [lerp(-1.6, -0.2, a3), 0, 0];
      p.spine = [-0.55 - 0.25 * a3, 0, 0];
    } else if (me.kind === 'sub') {
      p.shL = [-1.3, 0, 0.1]; p.shR = [-1.3, 0, -0.1]; p.elL = [-2.0, 0, 0]; p.elR = [-2.0, 0, 0]; p.spine = [-0.85, 0, 0];
    }
    return { pose: p, lunge };
  }

  // stojąc: oddech i pracujące nogi
  p.hipL[0] += Math.sin(time * 3) * 0.03; p.hipR[0] -= Math.sin(time * 3) * 0.03;

  if (me.kind === 'punch') {
    if (!second) { p.shL = [lerp(-0.9, -1.5, s), 0, 0.1]; p.elL = [lerp(-1.8, -0.1, s), 0, 0]; p.spine = [-0.08, -0.2 * s, 0]; }
    else { p.shR = [lerp(-0.9, -1.55, s), 0, -0.05]; p.elR = [lerp(-1.8, -0.05, s), 0, 0]; p.spine = [-0.08, 0.5 * s, 0]; p.hipR = [0.3, -0.4 * s, -0.12]; }
  } else if (me.kind === 'kick') {
    p.hipR = [lerp(0.3, -1.5, s), 0, lerp(-0.12, -0.45, s)]; p.knR = [lerp(0.45, 0.1, s), 0, 0]; p.spine = [-0.08 + 0.3 * s, 0, 0];
  } else if (me.kind === 'knee') {
    p.hipR = [lerp(0.3, -1.45, s), 0, -0.12]; p.knR = [lerp(0.45, 1.7, s), 0, 0]; p.spine = [-0.08 - 0.2 * s, 0, 0];
  } else if (me.kind === 'takedown') {
    const t = clamp01(phase * 1.5);
    p.spine = [lerp(-0.08, -0.95, t), 0, 0]; p.hipL = [lerp(-0.3, -0.9, t), 0, 0.12]; p.hipR = [lerp(0.3, -0.6, t), 0, -0.12];
    p.knL = [lerp(0.35, 1.1, t), 0, 0]; p.knR = [lerp(0.45, 1.0, t), 0, 0]; p.shL = [-1.5, 0, 0.1]; p.shR = [-1.5, 0, -0.1];
    p.elL = [-0.3, 0, 0]; p.elR = [-0.3, 0, 0]; p.neck = [0.6, 0, 0];
    lunge = 0.0;
  } else if (opp.kind === 'takedown') {
    const t = clamp01(phase * 1.5);
    p.spine = [lerp(-0.08, -0.6, t), 0, 0]; p.shL = [-0.3, 0, 0.5]; p.shR = [-0.3, 0, -0.5]; p.elL = [-0.6, 0, 0]; p.elR = [-0.6, 0, 0];
    p.hipL = [lerp(-0.3, 0.3, t), 0, 0.3]; p.hipR = [lerp(0.3, 0.5, t), 0, -0.3];
  }

  if (incoming && me.kind === 'idle') {
    if (opp.hit) { p.neck = [0.1 + 0.55 * hitW, 0, 0.2 * hitW]; p.spine[0] += 0.25 * hitW; lunge = -0.12 * hitW; }
    else { p.shL = [-1.2, 0, 0.2]; p.shR = [-1.2, 0, -0.2]; p.elL = [-2.1, 0, 0]; p.elR = [-2.1, 0, 0]; p.head = [0, 0, 0.3 * s]; }
  }
  return { pose: p, lunge };
}

/** Krótki opis tego, co dzieje się w klatce (do paska komentarza). */
export function commentary(frame: FightFrame, names: [string, string]): string {
  if (frame.end) return '';
  const order: Record<string, number> = { sub: 5, takedown: 4, gnp: 3, punch: 2, kick: 2, knee: 2, escape: 1, control: 0, idle: -1 };
  let best: { i: 0 | 1; a: FightAction } | null = null;
  for (const i of [0, 1] as const) {
    const a = frame.actions[i];
    if (!best || (order[a.kind] ?? -1) > (order[best.a.kind] ?? -1)) best = { i, a };
  }
  if (!best || best.a.kind === 'idle') return 'Wymiana w klinczu i na dystansie';
  const n = names[best.i], a = best.a;
  switch (a.kind) {
    case 'takedown': return a.ok ? `${n}: obalenie` : `${n}: nieudane obalenie`;
    case 'sub': return `${n}: próba poddania`;
    case 'gnp': return `${n}: ciosy w parterze`;
    case 'escape': return `${n}: ucieczka z parteru`;
    case 'control': return `${n}: kontrola w parterze`;
    case 'kick': return a.hit ? `${n}: celne kopnięcie` : `${n}: kopnięcie, rywal unika`;
    case 'knee': return a.hit ? `${n}: celne kolano` : `${n}: kolano, rywal unika`;
    default: return a.hit ? `${n}: celny cios` : `${n}: cios w gardę`;
  }
}
