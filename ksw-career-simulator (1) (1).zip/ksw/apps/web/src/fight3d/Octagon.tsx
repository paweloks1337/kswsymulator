const R = 4.6;
const APOTHEM = R * Math.cos(Math.PI / 8);

export default function Octagon() {
  const panels = Array.from({ length: 8 }, (_, k) => Math.PI / 8 + (k * Math.PI) / 4);
  const posts = Array.from({ length: 8 }, (_, k) => (k * Math.PI) / 4);
  return (
    <group>
      <mesh position={[0, -0.075, 0]} receiveShadow>
        <cylinderGeometry args={[R, R, 0.15, 8]} />
        <meshStandardMaterial color="#1b1c20" roughness={0.9} />
      </mesh>
      <mesh rotation-x={-Math.PI / 2} position={[0, 0.004, 0]}>
        <ringGeometry args={[1.7, 1.85, 64]} />
        <meshStandardMaterial color="#d6202a" roughness={0.8} />
      </mesh>
      <mesh rotation-x={-Math.PI / 2} position={[0, 0.003, 0]}>
        <circleGeometry args={[1.7, 64]} />
        <meshStandardMaterial color="#141518" roughness={0.9} />
      </mesh>
      {panels.map((a, k) => (
        <group key={k} position={[Math.sin(a) * APOTHEM, 0, Math.cos(a) * APOTHEM]} rotation-y={a}>
          <mesh position={[0, 0.75, 0]}>
            <boxGeometry args={[R * 0.77, 1.5, 0.03]} />
            <meshStandardMaterial color="#9aa0aa" transparent opacity={0.16} />
          </mesh>
          <mesh position={[0, 1.5, 0]}><boxGeometry args={[R * 0.77, 0.07, 0.09]} /><meshStandardMaterial color="#d6202a" /></mesh>
          <mesh position={[0, 0.9, 0]}><boxGeometry args={[R * 0.77, 0.03, 0.05]} /><meshStandardMaterial color="#2a2c32" /></mesh>
        </group>
      ))}
      {posts.map((a, k) => (
        <mesh key={k} position={[Math.sin(a) * R, 0.78, Math.cos(a) * R]}>
          <cylinderGeometry args={[0.06, 0.06, 1.56, 10]} />
          <meshStandardMaterial color="#26282e" metalness={0.5} roughness={0.5} />
        </mesh>
      ))}
      <mesh rotation-x={-Math.PI / 2} position={[0, -0.16, 0]}>
        <ringGeometry args={[R, 16, 48]} />
        <meshStandardMaterial color="#0b0b0d" roughness={1} />
      </mesh>
    </group>
  );
}
