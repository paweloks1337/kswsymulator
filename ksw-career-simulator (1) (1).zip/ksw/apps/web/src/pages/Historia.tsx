import { FEDERATIONS, START_DATE, daysBetween } from '@ksw/engine';
import { Empty, Panel } from '../components/ui';
import { useCareer } from '../store';

const RESULT = { W: 'Wygrana', L: 'Porażka', D: 'Remis' } as const;

export default function Historia() {
  const f = useCareer((s) => s.fighter)!;
  const h = f.history;
  const wins = h.filter((x) => x.result === 'W');
  const finishes = wins.filter((x) => ['KO', 'TKO', 'SUB'].includes(x.method)).length;
  let streak = 0;
  for (let i = h.length - 1; i >= 0 && h[i]!.result === 'W'; i--) streak++;
  const fed = (id: string) => FEDERATIONS.find((x) => x.id === id)?.name ?? id;
  const stats: [string, string][] = [
    ['Walki', String(h.length)], ['Wygrane', String(wins.length)], ['Wygrane przez finisz', String(finishes)],
    ['Obecna seria wygranych', String(streak)], ['Dni kariery', String(daysBetween(START_DATE, f.gameDate))],
  ];
  return (
    <div className="max-w-3xl space-y-4">
      <h1 className="font-display text-4xl font-extrabold">Historia</h1>
      <Panel title="Kariera w liczbach">
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-4">{stats.map(([k, v]) => (
          <div key={k}><div className="font-display text-3xl font-bold tabular-nums">{v}</div><div className="text-mute text-xs">{k}</div></div>))}
        </div>
      </Panel>
      <Panel title="Walki">
        {h.length === 0 ? <Empty>Brak walk. Pierwsza gala czeka po podpisaniu kontraktu.</Empty> : (
          <ul className="text-sm divide-y divide-line">{[...h].reverse().map((x, i) => (
            <li key={i} className="py-2 flex justify-between gap-3 flex-wrap">
              <span><span className={x.result === 'W' ? 'font-semibold' : 'text-mute'}>{RESULT[x.result]}</span> z {x.opponent}</span>
              <span className="text-mute">{x.method}, runda {x.round}, {fed(x.federationId)}, {x.date}</span></li>))}
          </ul>
        )}
      </Panel>
      <Panel title="Wydarzenia">
        {(f.log ?? []).length === 0 ? <Empty>Na razie brak wydarzeń.</Empty> : (
          <ul className="text-sm divide-y divide-line">{[...(f.log ?? [])].reverse().map((l, i) => (
            <li key={i} className="py-2 flex justify-between gap-3"><span>{l.text}</span><span className="text-mute shrink-0">{l.date}</span></li>))}
          </ul>
        )}
      </Panel>
    </div>
  );
}
