import { useState } from 'react';
import { ROLE_EFFECT, ROLE_LABELS, STAFF_ROLES, effectiveness, staffMarket, staffOf } from '@ksw/engine';
import { Empty, Meter, Panel } from '../components/ui';
import { useCareer } from '../store';

const zl = (n: number) => `${n.toLocaleString('pl-PL')} zł`;

export default function Sztab() {
  const f = useCareer((s) => s.fighter)!;
  const { hireStaff, fireStaff } = useCareer();
  const [err, setErr] = useState('');
  const staff = staffOf(f);
  const market = staffMarket(f);
  const run = async (p: Promise<string | null>) => setErr((await p) ?? '');
  return (
    <div className="max-w-4xl space-y-4">
      <h1 className="font-display text-4xl font-extrabold">Sztab</h1>
      <p className="text-mute text-sm">Pensje są pobierane pierwszego dnia miesiąca. Przy zatrudnieniu płacisz równowartość jednej pensji. Współpraca rośnie z każdym przepracowanym miesiącem i zwiększa skuteczność pracownika.</p>
      {err && <p className="text-red-soft text-sm" role="alert">{err}</p>}
      <Panel title="Twój sztab">
        {staff.length === 0 ? <Empty>Nikogo nie zatrudniasz. Poniżej jest rynek pracy.</Empty> : (
          <div className="space-y-3">{staff.map((m) => (
            <div key={m.id} className="border border-line rounded p-3">
              <div className="flex justify-between gap-3 flex-wrap">
                <div><div className="font-display text-xl font-bold">{m.name}</div><div className="text-sm text-mute">{ROLE_LABELS[m.role]}, pensja {zl(m.salary)}</div></div>
                <button className="px-3 py-1.5 rounded border border-line bg-raised text-sm self-start" onClick={() => run(fireStaff(m.id))}>Zwolnij</button>
              </div>
              <div className="grid sm:grid-cols-3 gap-3 mt-3">
                <Meter label="Umiejętności" value={m.skill} /><Meter label="Reputacja" value={m.reputation} /><Meter label="Współpraca" value={m.cooperation} />
              </div>
              <p className="text-xs text-mute mt-2">Skuteczność teraz: {Math.round(effectiveness(m) * 100)}%. {ROLE_EFFECT[m.role]}.</p>
            </div>))}
          </div>
        )}
      </Panel>
      {STAFF_ROLES.map((role) => {
        const cands = market.filter((c) => c.role === role);
        const filled = staff.some((m) => m.role === role);
        return (
          <Panel key={role} title={ROLE_LABELS[role]}>
            <p className="text-xs text-mute mb-3">{ROLE_EFFECT[role]}.{filled ? ' Stanowisko obsadzone.' : ''}</p>
            <div className="grid sm:grid-cols-3 gap-3">{cands.map((c) => (
              <div key={c.id} className="border border-line rounded p-3 text-sm">
                <div className="font-semibold">{c.name}</div>
                <div className="text-mute">Umiejętności {c.skill}, doświadczenie {c.experience} lat, reputacja {c.reputation}</div>
                <div className="text-mute">Pensja {zl(c.salary)}</div>
                <button disabled={filled || f.money < c.salary} className="mt-2 px-3 py-1.5 rounded bg-red font-medium disabled:opacity-40" onClick={() => run(hireStaff(c.id))}>Zatrudnij</button>
              </div>))}
            </div>
          </Panel>
        );
      })}
    </div>
  );
}
