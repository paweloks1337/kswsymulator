import type { NavItem } from '../nav';
import { Panel } from '../components/ui';

export default function StagePlaceholder({ item }: { item: NavItem }) {
  return (
    <div className="max-w-2xl">
      <h1 className="font-display text-4xl font-extrabold mb-4">{item.label}</h1>
      <Panel>
        <p className="mb-2">Ten moduł nie jest jeszcze zaimplementowany. Zaplanowano go na etap {item.stage}.</p>
        <p className="text-mute">{item.blurb}</p>
      </Panel>
    </div>
  );
}
