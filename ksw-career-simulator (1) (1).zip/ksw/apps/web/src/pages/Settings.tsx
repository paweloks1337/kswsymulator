import { useState } from 'react';
import { Panel } from '../components/ui';
import { useCareer } from '../store';
import { useInstall } from '../pwa';

export default function Settings() {
  const reset = useCareer((s) => s.resetCareer);
  const logout = useCareer((s) => s.logout);
  const install = useInstall();
  const [confirm, setConfirm] = useState(false);
  return (
    <div className="max-w-2xl">
      <h1 className="font-display text-4xl font-extrabold mb-4">Ustawienia</h1>
      <Panel title="Aplikacja na telefonie">
        {install.kind === 'installed' && <p className="text-sm">Aplikacja jest zainstalowana.</p>}
        {install.kind === 'prompt' && (<><p className="text-mute text-sm mb-3">Zainstaluj grę, aby uruchamiać ją z ekranu głównego, na pełnym ekranie.</p>
          <button className="px-4 py-2 rounded bg-red font-medium" onClick={() => void install.install()}>Zainstaluj</button></>)}
        {install.kind === 'ios' && <p className="text-sm">Na iPhonie otwórz tę stronę w Safari, dotknij przycisku Udostępnij, a potem „Dodaj do ekranu początkowego".</p>}
        {install.kind === 'unavailable' && <p className="text-mute text-sm">Ta przeglądarka nie oferuje instalacji. W menu przeglądarki poszukaj opcji „Zainstaluj aplikację" lub „Dodaj do ekranu głównego".</p>}
        <p className="text-mute text-xs mt-3">Po pierwszym uruchomieniu ekrany otwierają się także bez internetu, ale dane kariery zawsze pochodzą z serwera.</p>
      </Panel>
      <Panel title="Konto"><button className="px-4 py-2 rounded bg-raised border border-line" onClick={logout}>Wyloguj</button></Panel>
      <Panel title="Kariera">
        <p className="text-mute text-sm mb-3">Kariera jest zapisana na Twoim koncie na serwerze.</p>
        {!confirm ? (
          <button className="px-4 py-2 border border-red text-red-soft rounded font-medium" onClick={() => setConfirm(true)}>Usuń karierę</button>
        ) : (
          <div className="flex gap-2 items-center flex-wrap">
            <span className="text-sm">Usunąć zawodnika bezpowrotnie?</span>
            <button className="px-4 py-2 bg-red rounded font-medium" onClick={reset}>Usuń</button>
            <button className="px-4 py-2 bg-raised rounded" onClick={() => setConfirm(false)}>Anuluj</button>
          </div>
        )}
      </Panel>
    </div>
  );
}
