import { useState } from 'react';
import { FEDERATIONS, WEIGHT_CLASSES, rankings } from '@ksw/engine';
import { Panel } from '../components/ui';
import { useCareer } from '../store';

export default function Rankingi() {
  const { fighter: f, world } = useCareer();
  const [fed, setFed] = useState(f!.contract?.federationId ?? 'arena');
  const [cls, setCls] = useState(f!.weightClass.id);
  const rows = rankings(world!, f!, fed, cls);
  const sel = 'bg-raised border border-line rounded px-3 py-2';
  return (
    <div className="max-w-3xl space-y-4">
      <h1 className="font-display text-4xl font-extrabold">Rankingi</h1>
      <div className="flex gap-2 flex-wrap">
        <select className={sel} value={fed} onChange={(e) => setFed(e.target.value)} aria-label="Federacja">{FEDERATIONS.map((x) => <option key={x.id} value={x.id}>{x.name}</option>)}</select>
        <select className={sel} value={cls} onChange={(e) => setCls(e.target.value)} aria-label="Kategoria">{WEIGHT_CLASSES.map((x) => <option key={x.id} value={x.id}>{x.name}</option>)}</select>
      </div>
      <Panel>
        <table className="w-full text-sm"><thead><tr className="text-mute text-left"><th className="w-10">#</th><th>Zawodnik</th><th>Rekord</th></tr></thead><tbody>
          {rows.map((r) => (
            <tr key={r.id} className={`border-t border-line ${r.isPlayer ? 'text-red-soft font-semibold' : ''}`}>
              <td className="py-1.5 tabular-nums">{r.rank}</td><td>{r.name}{r.champion && <span className="ml-2 text-xs px-1.5 py-0.5 rounded bg-red text-white">Mistrz</span>}</td><td className="tabular-nums">{r.wins}-{r.losses}-{r.draws}</td></tr>))}
        </tbody></table>
        <p className="text-mute text-sm mt-3">Zawodnicy starzeją się, rozwijają, awansują między federacjami i kończą kariery także beze mnie. Mistrzowie bronią tytułów co miesiąc. Ty trafiasz do rankingu federacji po pierwszej walce lub podpisaniu kontraktu.</p>
      </Panel>
      <Panel title="Wydarzenia w świecie MMA">
        {(world!.news ?? []).length === 0 ? <p className="text-mute text-sm">Na razie spokojnie. Pierwsze wieści pojawią się wraz z upływem czasu.</p> : (
          <ul className="text-sm divide-y divide-line">{[...(world!.news ?? [])].reverse().slice(0, 15).map((n, i) => (
            <li key={i} className="flex justify-between gap-3 py-1.5"><span>{n.text}</span><span className="text-mute shrink-0">{n.date}</span></li>))}</ul>
        )}
      </Panel>
    </div>
  );
}
