import { useState } from 'react';
import { daysToFight } from '@ksw/engine';
import { Panel } from '../components/ui';
import { useCareer } from '../store';

export default function Kalendarz() {
  const f = useCareer((s) => s.fighter)!;
  const rest = useCareer((s) => s.rest);
  const [err, setErr] = useState('');
  const date = new Date(`${f.gameDate}T00:00:00Z`).toLocaleDateString('pl-PL', { dateStyle: 'full', timeZone: 'UTC' });
  return (
    <div className="max-w-2xl space-y-4">
      <h1 className="font-display text-4xl font-extrabold">Kalendarz</h1>
      <Panel><p className="font-display text-3xl font-bold">{date}</p>
        <p className="text-mute text-sm mt-1">{f.nextFight ? `Najbliższa walka: ${f.nextFight.date} (za ${daysToFight(f)} dni). Czas zatrzyma się w dniu walki.` : 'Brak zaplanowanej walki. Podpisz kontrakt w zakładce Federacje.'}</p></Panel>
      <Panel title="Przewiń czas">
        <div className="flex gap-2 flex-wrap">
          {[1, 7, 30].map((d) => <button key={d} className="px-4 py-2 rounded bg-raised border border-line font-medium" onClick={async () => setErr((await rest(d)) ?? '')}>+{d} {d === 1 ? 'dzień' : 'dni'}</button>)}
        </div>
        {err && <p className="text-red-soft text-sm mt-2" role="alert">{err}</p>}
        <p className="text-mute text-sm mt-3">Przewijanie to dni odpoczynku: spada zmęczenie, goją się kontuzje.</p>
      </Panel>
    </div>
  );
}
