import { useMemo, useState, type ReactNode } from 'react';
import {
  APPEARANCE_OPTIONS, ATTRIBUTES, ATTRIBUTE_LABELS, STYLES, STYLE_LABELS,
  computeStartingStats, validateProfile, weightClassFor, type FighterProfile,
} from '@ksw/engine';
import { Meter, Panel } from '../components/ui';
import { useCareer } from '../store';

const initial: FighterProfile = {
  firstName: '', lastName: '', nickname: '', age: 24, nationality: 'Polska',
  heightCm: 180, weightKg: 77, reachCm: 183, dominantHand: 'right', style: 'mma', experienceYears: 4,
  appearance: { face: 'Kanciasta', hair: 'Krótkie', beard: 'Brak', build: 'Atletyczna', tattoos: 'Brak', kit: 'Czerwony' },
};
const APP_LABELS = { face: 'Twarz', hair: 'Fryzura', beard: 'Zarost', build: 'Budowa', tattoos: 'Tatuaże', kit: 'Strój' };
const input = 'w-full bg-raised border border-line rounded px-3 py-2 focus:border-red';

export default function Creator() {
  const start = useCareer((s) => s.startCareer);
  const [p, setP] = useState<FighterProfile>(initial);
  const [serverError, setServerError] = useState('');
  const errors = useMemo(() => validateProfile(p), [p]);
  const stats = useMemo(() => (errors.length ? null : computeStartingStats(p)), [p, errors]);
  const wc = weightClassFor(p.weightKg);
  const set = <K extends keyof FighterProfile>(k: K, v: FighterProfile[K]) => setP((o) => ({ ...o, [k]: v }));
  const num = (k: 'age' | 'heightCm' | 'weightKg' | 'reachCm' | 'experienceYears') => (
    <input type="number" className={input} value={Number.isNaN(p[k]) ? '' : p[k]} onChange={(e) => set(k, e.target.valueAsNumber)} />
  );

  return (
    <div className="min-h-full p-4 md:p-8 max-w-6xl mx-auto">
      <h1 className="font-display text-5xl md:text-6xl font-extrabold leading-none mb-1">Nowy zawodnik</h1>
      <p className="text-mute mb-6">Styl, wiek i doświadczenie wyznaczają statystyki startowe. Potencjał jest ukryty.</p>
      <div className="grid lg:grid-cols-[1fr_340px] gap-4">
        <div className="space-y-4">
          <Panel title="Dane">
            <div className="grid sm:grid-cols-2 gap-3">
              <L t="Imię"><input className={input} value={p.firstName} onChange={(e) => set('firstName', e.target.value)} /></L>
              <L t="Nazwisko"><input className={input} value={p.lastName} onChange={(e) => set('lastName', e.target.value)} /></L>
              <L t="Pseudonim"><input className={input} value={p.nickname} onChange={(e) => set('nickname', e.target.value)} /></L>
              <L t="Narodowość"><input className={input} value={p.nationality} onChange={(e) => set('nationality', e.target.value)} /></L>
              <L t="Wiek">{num('age')}</L>
              <L t="Doświadczenie (lata)">{num('experienceYears')}</L>
              <L t="Wzrost (cm)">{num('heightCm')}</L>
              <L t="Zasięg ramion (cm)">{num('reachCm')}</L>
              <L t={`Waga (kg)${wc ? `, kategoria ${wc.name}` : ''}`}>{num('weightKg')}</L>
              <L t="Dominująca ręka">
                <select className={input} value={p.dominantHand} onChange={(e) => set('dominantHand', e.target.value as FighterProfile['dominantHand'])}>
                  <option value="right">Prawa</option><option value="left">Lewa</option><option value="switch">Obustronny</option>
                </select>
              </L>
            </div>
          </Panel>
          <Panel title="Styl walki">
            <div className="flex flex-wrap gap-2">
              {STYLES.map((s) => (
                <button key={s} type="button" aria-pressed={p.style === s} onClick={() => set('style', s)}
                  className={`px-4 py-2 rounded border font-medium ${p.style === s ? 'bg-red border-red text-white' : 'border-line hover:bg-raised'}`}>
                  {STYLE_LABELS[s]}
                </button>
              ))}
            </div>
          </Panel>
          <Panel title="Wygląd">
            <div className="grid sm:grid-cols-3 gap-3">
              {(Object.keys(APPEARANCE_OPTIONS) as (keyof typeof APPEARANCE_OPTIONS)[]).map((k) => (
                <L key={k} t={APP_LABELS[k]}>
                  <select className={input} value={p.appearance[k]} onChange={(e) => set('appearance', { ...p.appearance, [k]: e.target.value })}>
                    {APPEARANCE_OPTIONS[k].map((o) => <option key={o}>{o}</option>)}
                  </select>
                </L>
              ))}
            </div>
            <p className="text-mute text-sm mt-3">Wygląd zapisuje się w profilu. Model 3D pojawi się w etapie 4.</p>
          </Panel>
        </div>
        <div className="space-y-4 lg:sticky lg:top-4 self-start">
          <Panel title="Statystyki startowe">
            {stats ? (
              <div className="space-y-2.5">{ATTRIBUTES.map((a) => <Meter key={a} label={ATTRIBUTE_LABELS[a]} value={stats[a]} />)}</div>
            ) : (
              <ul className="text-sm text-red-soft list-disc pl-5 space-y-1">{errors.map((e) => <li key={e}>{e}</li>)}</ul>
            )}
          </Panel>
          <button type="button" disabled={errors.length > 0} onClick={async () => setServerError((await start(p)) ?? '')}
            className="w-full py-3 rounded bg-red font-display text-xl font-bold disabled:opacity-40 disabled:cursor-not-allowed">
            Rozpocznij karierę
          </button>
          {serverError && <p className="text-red-soft text-sm" role="alert">{serverError}</p>}
        </div>
      </div>
    </div>
  );
}

function L({ t, children }: { t: string; children: ReactNode }) {
  return <label className="block text-sm"><span className="text-mute block mb-1">{t}</span>{children}</label>;
}
