import { useState } from 'react';
import { FEDERATIONS, daysToFight, generateOffers } from '@ksw/engine';
import { Empty, Panel } from '../components/ui';
import { useCareer } from '../store';

const zl = (n: number) => `${n.toLocaleString('pl-PL')} zł`;

export default function Federacje() {
  const f = useCareer((s) => s.fighter)!;
  const accept = useCareer((s) => s.acceptOffer);
  const [err, setErr] = useState('');
  const offers = generateOffers(f);
  const name = (id: string) => FEDERATIONS.find((x) => x.id === id)?.name ?? id;
  return (
    <div className="max-w-3xl space-y-4">
      <h1 className="font-display text-4xl font-extrabold">Federacje</h1>
      {f.contract && (
        <Panel title="Aktywny kontrakt">
          <p>{name(f.contract.federationId)}, pozostało walk: {f.contract.fightsLeft}</p>
          <p className="text-mute text-sm">Gaża {zl(f.contract.purse)}, premia za wygraną {zl(f.contract.winBonus)}, za KO {zl(f.contract.koBonus)}, za poddanie {zl(f.contract.subBonus)}.</p>
          {f.nextFight && <p className="text-sm mt-2">Najbliższa walka: {f.nextFight.date} (za {daysToFight(f)} dni)</p>}
        </Panel>
      )}
      {!f.contract && (
        <Panel title="Oferty kontraktów">
          {offers.length === 0 ? <Empty>Brak ofert. Federacje szukają zawodników z lepszym rekordem i oceną.</Empty> : (
            <div className="space-y-3">{offers.map((o) => (
              <div key={o.federationId} className="border border-line rounded p-3">
                <h3 className="font-display text-xl font-bold">{name(o.federationId)}</h3>
                <p className="text-sm text-mute">{o.fights} walki, gaża {zl(o.purse)}, premia za wygraną {zl(o.winBonus)}, KO {zl(o.koBonus)}, poddanie {zl(o.subBonus)}</p>
                <button className="mt-2 px-4 py-2 rounded bg-red font-medium" onClick={async () => setErr((await accept(o.federationId)) ?? '')}>Podpisz kontrakt</button>
              </div>))}
            </div>
          )}
          <p className="text-mute text-sm mt-3">Nie podpisujesz? Oferta zostaje, dopóki spełniasz warunki.</p>
          {err && <p className="text-red-soft text-sm mt-2" role="alert">{err}</p>}
        </Panel>
      )}
      <Panel title="Organizacje">
        <ul className="space-y-2 text-sm">{FEDERATIONS.map((x) => (
          <li key={x.id} className="flex justify-between"><span>{x.name}</span><span className="text-mute">wymaga: {x.minWins} wygranych, ocena {x.minRating}+</span></li>))}
        </ul>
      </Panel>
    </div>
  );
}
