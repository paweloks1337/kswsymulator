import { ATTRIBUTES, ATTRIBUTE_LABELS, STYLE_LABELS, overallRating } from '@ksw/engine';
import { Meter, Panel } from '../components/ui';
import { useCareer } from '../store';

export default function Profile() {
  const f = useCareer((s) => s.fighter)!;
  const p = f.profile;
  const hand = { right: 'Prawa', left: 'Lewa', switch: 'Obustronny' }[p.dominantHand];
  const rows: [string, string][] = [
    ['Wiek', `${p.age} lat`], ['Narodowość', p.nationality], ['Wzrost', `${p.heightCm} cm`],
    ['Waga', `${p.weightKg} kg`], ['Zasięg ramion', `${p.reachCm} cm`],
    ['Kategoria', f.weightClass.name], ['Dominująca ręka', hand],
    ['Styl', STYLE_LABELS[p.style]], ['Doświadczenie', `${p.experienceYears} lat`],
  ];
  return (
    <div className="max-w-4xl">
      <h1 className="font-display text-4xl font-extrabold">{p.firstName} {p.nickname && <span className="text-red">„{p.nickname}”</span>} {p.lastName}</h1>
      <p className="text-mute mb-6">Ocena ogólna {overallRating(f.stats)}</p>
      <div className="grid md:grid-cols-2 gap-4">
        <Panel title="Dane">
          <dl className="grid grid-cols-2 gap-y-2 text-sm">
            {rows.map(([k, v]) => (<div key={k} className="contents"><dt className="text-mute">{k}</dt><dd>{v}</dd></div>))}
          </dl>
        </Panel>
        <Panel title="Atrybuty">
          <div className="space-y-3">{ATTRIBUTES.map((a) => <Meter key={a} label={ATTRIBUTE_LABELS[a]} value={f.stats[a]} />)}</div>
        </Panel>
      </div>
    </div>
  );
}
