import { useState, type FormEvent } from 'react';
import { Panel } from '../components/ui';
import { useCareer } from '../store';

export default function Login() {
  const authenticate = useCareer((s) => s.authenticate);
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const submit = async (e: FormEvent) => {
    e.preventDefault(); setBusy(true); setError('');
    try { await authenticate(mode, email, password); } catch (err) { setError((err as Error).message); }
    setBusy(false);
  };
  const cls = 'w-full bg-raised border border-line rounded px-3 py-2 focus:border-red';
  return (
    <div className="min-h-full grid place-items-center p-4">
      <form onSubmit={submit} className="w-full max-w-sm">
        <h1 className="font-display text-5xl font-extrabold leading-none mb-1">KSW <span className="text-red">Career</span></h1>
        <p className="text-mute mb-6">{mode === 'login' ? 'Zaloguj się, aby wrócić do kariery.' : 'Załóż konto, aby zapisywać karierę.'}</p>
        <Panel>
          <div className="space-y-3">
            <label className="block text-sm"><span className="text-mute block mb-1">E-mail</span><input className={cls} type="email" autoComplete="email" required value={email} onChange={(e) => setEmail(e.target.value)} /></label>
            <label className="block text-sm"><span className="text-mute block mb-1">Hasło (min. 8 znaków)</span><input className={cls} type="password" autoComplete={mode === 'login' ? 'current-password' : 'new-password'} required minLength={8} value={password} onChange={(e) => setPassword(e.target.value)} /></label>
            {error && <p className="text-red-soft text-sm" role="alert">{error}</p>}
            <button disabled={busy} className="w-full py-2.5 rounded bg-red font-display text-xl font-bold disabled:opacity-40">{mode === 'login' ? 'Zaloguj się' : 'Załóż konto'}</button>
          </div>
        </Panel>
        <button type="button" className="text-sm text-mute mt-4 underline" onClick={() => setMode(mode === 'login' ? 'register' : 'login')}>
          {mode === 'login' ? 'Nie masz konta? Załóż je' : 'Masz konto? Zaloguj się'}
        </button>
      </form>
    </div>
  );
}
