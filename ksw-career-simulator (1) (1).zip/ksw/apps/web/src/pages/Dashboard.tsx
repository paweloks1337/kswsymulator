import { ATTRIBUTES, ATTRIBUTE_LABELS, STYLE_LABELS, mediaOf, overallRating } from '@ksw/engine';
import { Empty, Meter, Panel } from '../components/ui';
import { useCareer } from '../store';

export default function Dashboard() {
  const f = useCareer((s) => s.fighter)!;
  const world = useCareer((s) => s.world);
  const opp = world?.npcs.find((n) => n.id === f.nextFight?.opponentId);
  const p = f.profile;
  const { wins, losses, draws } = f.record;
  const top = [...ATTRIBUTES].sort((a, b) => f.stats[b] - f.stats[a]).slice(0, 4);
  const c = f.condition;
  return (
    <div className="max-w-5xl space-y-4">
      <section className="bg-panel border border-line rounded-md overflow-hidden">
        <div className="border-l-4 border-red p-5 md:p-8 flex flex-wrap items-end justify-between gap-6">
          <div>
            <p className="text-mute">{f.gameDate} &middot; {STYLE_LABELS[p.style]}, {f.weightClass.name} (do {f.weightClass.maxKg} kg)</p>
            <h1 className="font-display text-5xl md:text-7xl font-extrabold leading-[0.95]">
              {p.firstName}<br />{p.nickname && <span className="text-red">„{p.nickname}” </span>}{p.lastName}
            </h1>
          </div>
          <div className="flex flex-wrap gap-x-8 gap-y-4">
            <Stat label="Rekord" value={`${wins}-${losses}-${draws}`} />
            <Stat label="Wiek" value={String(p.age)} />
            <Stat label="Ocena" value={String(overallRating(f.stats))} />
            <Stat label="Popularność" value={String(Math.round(mediaOf(f).popularity))} />
            <Stat label="Saldo (zł)" value={f.money.toLocaleString('pl-PL')} />
          </div>
        </div>
      </section>
      <div className="grid md:grid-cols-3 gap-4">
        <Panel title="Forma">
          <div className="space-y-3">
            <Meter label="Zdrowie" value={c.health} />
            <Meter label="Forma" value={c.form} />
            <Meter label="Zmęczenie" value={c.fatigue} invert />
            <Meter label="Pewność siebie" value={c.confidence} />
            <Meter label="Stres" value={c.stress} invert />
          </div>
        </Panel>
        <Panel title="Najmocniejsze strony">
          <div className="space-y-3">{top.map((a) => <Meter key={a} label={ATTRIBUTE_LABELS[a]} value={f.stats[a]} />)}</div>
        </Panel>
        <div className="space-y-4">
          <Panel title="Nadchodzące walki">{f.nextFight ? <p className="text-sm">{f.nextFight.date}, rywal: {opp?.name ?? '?'}</p> : <Empty>Brak walk. Podpisz kontrakt w zakładce Federacje.</Empty>}</Panel>
          <Panel title="Ostatnie wydarzenia">{f.log?.length ? <p className="text-sm">{f.log[f.log.length - 1]!.text}</p> : f.history.length ? <p className="text-sm">{f.history[f.history.length - 1]!.result === 'W' ? 'Wygrana' : 'Porażka lub remis'} z {f.history[f.history.length - 1]!.opponent}</p> : <Empty>Kariera dopiero się zaczyna.</Empty>}</Panel>
        </div>
      </div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div className="font-display text-4xl font-bold tabular-nums leading-none whitespace-nowrap">{value}</div>
      <div className="text-mute text-sm mt-1">{label}</div>
    </div>
  );
}
