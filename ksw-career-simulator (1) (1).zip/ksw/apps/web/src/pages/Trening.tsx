import { useState } from 'react';
import { ACTIVITIES, ATTRIBUTE_LABELS, INJURY_LABELS, MAX_TRAINING_FATIGUE, diminishing, type Attribute } from '@ksw/engine';
import { Meter, Panel } from '../components/ui';
import { useCareer } from '../store';

export default function Trening() {
  const f = useCareer((s) => s.fighter)!;
  const train = useCareer((s) => s.train);
  const [msg, setMsg] = useState('');
  const run = async (id: string) => {
    const r = await train(id);
    if (!r.ok) return setMsg(r.reason);
    const g = Object.entries(r.gains).map(([a, v]) => `${ATTRIBUTE_LABELS[a as Attribute]} +${v}`).join(', ');
    setMsg([g || 'Regeneracja zakończona.', r.injury ? `Kontuzja: ${INJURY_LABELS[r.injury.area]} (stopień ${r.injury.severity}, ${r.injury.daysLeft} dni).` : ''].filter(Boolean).join(' '));
  };
  const tired = f.condition.fatigue >= MAX_TRAINING_FATIGUE;
  return (
    <div className="max-w-4xl space-y-4">
      <h1 className="font-display text-4xl font-extrabold">Trening</h1>
      <Panel><Meter label="Zmęczenie" value={f.condition.fatigue} invert />
        <p className="text-sm mt-3 min-h-5" role="status">{msg || 'Każda sesja zajmuje jeden dzień.'}</p></Panel>
      <div className="grid sm:grid-cols-2 gap-3">
        {ACTIVITIES.map((a) => {
          const rec = a.id === 'recovery';
          const eff = Object.entries(a.gains).map(([k, v]) => `${ATTRIBUTE_LABELS[k as Attribute]} (${Math.round(v * diminishing(f.trained[k as Attribute] ?? 0) * 100) / 100}/sesję)`).join(', ');
          return (
            <Panel key={a.id}>
              <h2 className="font-display text-xl font-bold">{a.label}</h2>
              <p className="text-sm text-mute mt-1">{rec ? `Zmęczenie −${10 + (a.restBonus ?? 0)}, szybsze gojenie.` : `Zyski: ${eff}`}</p>
              {!rec && <p className="text-sm text-mute">Zmęczenie +{a.fatigue}, ryzyko kontuzji {Math.round(a.injuryRisk * 100)}%</p>}
              <button className="mt-3 px-4 py-2 rounded bg-red font-medium disabled:opacity-40" disabled={!rec && tired} onClick={() => run(a.id)}>
                {rec ? 'Zregeneruj się' : 'Trenuj'}
              </button>
            </Panel>
          );
        })}
      </div>
    </div>
  );
}
