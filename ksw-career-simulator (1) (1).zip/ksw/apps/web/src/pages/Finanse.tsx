import { useState } from 'react';
import { CARS, FOOD, GYMS, HOUSING, TAX_RATE, TRANSPORT, lifestyleOf, netWorth, type CarId, type HousingId } from '@ksw/engine';
import { Empty, Panel } from '../components/ui';
import { useCareer } from '../store';

const zl = (n: number) => `${n.toLocaleString('pl-PL')} zł`;

export default function Finanse() {
  const f = useCareer((s) => s.fighter)!;
  const change = useCareer((s) => s.changeLifestyle);
  const [err, setErr] = useState('');
  const l = lifestyleOf(f);
  const run = async (p: Promise<string | null>) => setErr((await p) ?? '');
  const btn = 'mt-2 px-3 py-1.5 rounded bg-red font-medium disabled:opacity-40';
  return (
    <div className="max-w-3xl space-y-4">
      <h1 className="font-display text-4xl font-extrabold">Finanse</h1>
      <Panel>
        <p className="text-mute text-sm">Saldo</p>
        <p className={`font-display text-5xl font-bold tabular-nums ${f.money < 0 ? 'text-red-soft' : ''}`}>{zl(f.money)}</p>
        <p className="text-mute text-sm mt-2">Majątek (gotówka i wartość rzeczy po odsprzedaży): {zl(netWorth(f))}. Mieszkanie, jedzenie ({zl(FOOD)}) i transport pobierane są pierwszego dnia miesiąca, każdy trening kosztuje, a z wypłat z gal potrącany jest podatek {Math.round(TAX_RATE * 100)}%.</p>
      </Panel>
      {err && <p className="text-red-soft text-sm" role="alert">{err}</p>}
      <Panel title="Mieszkanie">
        <div className="grid sm:grid-cols-2 gap-3">{(Object.keys(HOUSING) as HousingId[]).map((id) => {
          const h = HOUSING[id], cur = l.housing === id;
          return (<div key={id} className={`border rounded p-3 text-sm ${cur ? 'border-red' : 'border-line'}`}>
            <div className="font-semibold">{h.label}</div><div className="text-mute">{h.desc}</div>
            <div className="text-mute">{h.price ? `Cena ${zl(h.price)}, utrzymanie ${zl(h.monthly)}/mies.` : `${zl(h.monthly)}/mies.`}, regeneracja {h.recovery >= 0 ? '+' : ''}{h.recovery}/dzień</div>
            {cur ? <p className="mt-2 text-red-soft">Tu mieszkasz</p> : <button className={btn} disabled={f.money < h.price + 300} onClick={() => run(change('housing', id))}>{h.price ? 'Kup' : 'Przeprowadź się'}</button>}
          </div>);
        })}</div>
        <p className="text-mute text-xs mt-2">Przeprowadzka kosztuje 300 zł. Dom odsprzedasz za 80% ceny.</p>
      </Panel>
      <Panel title="Samochód">
        <div className="grid sm:grid-cols-3 gap-3">{(Object.keys(CARS) as CarId[]).map((id) => {
          const c = CARS[id], cur = l.car === id;
          return (<div key={id} className={`border rounded p-3 text-sm ${cur ? 'border-red' : 'border-line'}`}>
            <div className="font-semibold">{c.label}</div><div className="text-mute">{c.desc}</div>
            <div className="text-mute">{id === 'none' ? `${zl(TRANSPORT)}/mies.` : `Cena ${zl(c.price)}, utrzymanie ${zl(c.upkeep)}/mies.`}</div>
            {cur ? <p className="mt-2 text-red-soft">Masz</p> : <button className={btn} disabled={f.money < c.price} onClick={() => run(change('car', id))}>{id === 'none' ? 'Sprzedaj auto' : 'Kup'}</button>}
          </div>);
        })}</div>
        <p className="text-mute text-xs mt-2">Auto odsprzedasz za 60% ceny.</p>
      </Panel>
      <Panel title="Domowa siłownia">
        <p className="text-sm">{GYMS[l.gym].label}. {GYMS[l.gym].desc}</p>
        {l.gym < 2 ? (<><p className="text-mute text-sm mt-1">Następny poziom: {GYMS[l.gym + 1]!.label}, {zl(GYMS[l.gym + 1]!.price)}. {GYMS[l.gym + 1]!.desc}</p>
          <button className={btn} disabled={f.money < GYMS[l.gym + 1]!.price} onClick={() => run(change('gym'))}>Rozbuduj</button></>) : <p className="text-mute text-sm">Maksymalny poziom.</p>}
      </Panel>
      <Panel title="Ostatnie operacje">
        {f.ledger.length === 0 ? <Empty>Brak operacji.</Empty> : (
          <ul className="divide-y divide-line text-sm">{[...f.ledger].reverse().map((e, i) => (
            <li key={i} className="flex justify-between py-1.5"><span>{e.label} <span className="text-mute">{e.date}</span></span>
              <span className={`tabular-nums ${e.amount < 0 ? 'text-mute' : ''}`}>{e.amount > 0 ? '+' : ''}{zl(e.amount)}</span></li>
          ))}</ul>
        )}
      </Panel>
    </div>
  );
}
