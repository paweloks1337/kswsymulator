import { INJURY_LABELS } from '@ksw/engine';
import { Empty, Meter, Panel } from '../components/ui';
import { useCareer } from '../store';

export default function Zdrowie() {
  const f = useCareer((s) => s.fighter)!;
  const c = f.condition;
  return (
    <div className="max-w-3xl space-y-4">
      <h1 className="font-display text-4xl font-extrabold">Zdrowie</h1>
      <Panel title="Stan"><div className="space-y-3">
        <Meter label="Zdrowie" value={c.health} /><Meter label="Zmęczenie" value={c.fatigue} invert /><Meter label="Forma" value={c.form} />
      </div></Panel>
      <Panel title="Kontuzje">
        {f.injuries.length === 0 ? <Empty>Brak kontuzji.</Empty> : (
          <ul className="space-y-2">{f.injuries.map((i, n) => (
            <li key={n} className="flex justify-between text-sm"><span>{INJURY_LABELS[i.area]}, stopień {i.severity}</span><span className="text-mute">{i.daysLeft} dni do końca leczenia</span></li>
          ))}</ul>
        )}
        <p className="text-mute text-sm mt-3">Kontuzja zmniejsza o połowę zyski z treningu i obniża limit zdrowia. Koszty rehabilitacji i fizjoterapia dojdą z finansami.</p>
      </Panel>
    </div>
  );
}
