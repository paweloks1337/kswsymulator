import { lazy, Suspense, useState } from 'react';
import {
  FEDERATIONS, FOCUS_HINT, FOCUS_LABELS, ROUNDS, adviseTactics, daysToFight, overallRating, staffOf,
  type FightResult, type Focus, type Tactics,
} from '@ksw/engine';
import { Empty, Panel } from '../components/ui';
import { useCareer, type RoundOutcome } from '../store';
import { lookFromFighter, lookFromNpc, type Look } from '../fight3d/looks';

// Silnik 3D ładowany dopiero przy oglądaniu walki (mniejszy start na telefonie).
const FightViewer = lazy(() => import('../fight3d/FightViewer'));
const M = { KO: 'KO', TKO: 'TKO', SUB: 'poddanie', DEC: 'decyzja sędziów', DRAW: 'remis' } as const;
type Ok = Extract<RoundOutcome, { ok: true }>;
const FINAL_ROWS: [string, (s: FightResult['stats'][0]) => string][] = [
  ['Ciosy celne/rzucone', (s) => `${s.strikesLanded}/${s.strikesThrown}`],
  ['Obalenia', (s) => `${s.takedowns}/${s.takedownsTried}`],
  ['Kontrola (s)', (s) => String(s.controlSec)],
  ['Obrażenia', (s) => String(Math.round(s.damage))],
];

function TacticsPicker({ t, onChange }: { t: Tactics; onChange: (t: Tactics) => void }) {
  return (
    <div className="space-y-3">
      <label className="block text-sm">Agresja: {Math.round(t.aggression * 100)}%
        <input type="range" min={0} max={1} step={0.1} value={t.aggression} onChange={(e) => onChange({ ...t, aggression: +e.target.value })} className="w-full" /></label>
      <div className="flex flex-wrap gap-2">
        {(Object.keys(FOCUS_LABELS) as Focus[]).map((k) => (
          <button key={k} type="button" aria-pressed={t.focus === k} onClick={() => onChange({ ...t, focus: k })}
            className={`px-3 py-1.5 rounded border text-sm ${t.focus === k ? 'bg-red border-red text-white' : 'border-line hover:bg-raised'}`}>{FOCUS_LABELS[k]}</button>))}
      </div>
      <p className="text-mute text-sm">{FOCUS_HINT[t.focus]}</p>
    </div>
  );
}

function RoundTable({ o }: { o: Ok }) {
  const s = o.summary;
  const rows: [string, (i: 0 | 1) => string][] = [
    ['Ciosy celne/rzucone', (i) => `${s.stats[i].landed}/${s.stats[i].thrown}`], ['Obalenia', (i) => `${s.stats[i].tdOk}/${s.stats[i].tdTried}`],
    ['Kontrola (s)', (i) => String(s.stats[i].control)], ['Obrażenia', (i) => String(Math.round(s.stats[i].damage))],
    ['Zdrowie', (i) => `${s.hpPct[i]}%`], ['Kondycja', (i) => `${s.staminaPct[i]}%`],
  ];
  return (
    <table className="w-full text-sm"><thead><tr className="text-mute text-left"><th></th><th>Ty</th><th>Rywal</th></tr></thead><tbody>
      {rows.map(([l, fn]) => <tr key={l} className="border-t border-line"><td className="py-1.5 text-mute">{l}</td><td>{fn(0)}</td><td>{fn(1)}</td></tr>)}
    </tbody></table>
  );
}

export default function Walki() {
  const { fighter: f, world, fightStart, fightNext } = useCareer();
  const [tactics, setTactics] = useState<Tactics>({ aggression: 0.5, focus: 'balanced' });
  const [out, setOut] = useState<Ok | null>(null);
  const [looks, setLooks] = useState<[Look, Look] | null>(null);
  const [watching, setWatching] = useState(false);
  const [err, setErr] = useState('');
  const af = f!.activeFight ?? null;
  const nf = f!.nextFight;
  const opp = world!.npcs.find((n) => n.id === (af?.opponentId ?? nf?.opponentId));
  const days = daysToFight(f!);
  const hasCoach = staffOf(f!).some((s) => s.role === 'head');
  const headSkill = staffOf(f!).find((s) => s.role === 'head')?.skill ?? 0;
  const advice = af ? adviseTactics(af.state, 0) : null;
  const names: [string, string] = [`${f!.profile.firstName} ${f!.profile.lastName}`, out?.opponent ?? opp?.name ?? 'Rywal'];
  const lastRound = af ? af.state.rounds[af.state.rounds.length - 1] : null;

  const play = async (start: boolean) => {
    setErr('');
    const lk: [Look, Look] = !start && looks ? looks : [lookFromFighter(f!), opp ? lookFromNpc(opp) : lookFromFighter(f!)];
    const r = await (start ? fightStart(tactics) : fightNext(tactics));
    if (!r.ok) return setErr(r.reason);
    setLooks(lk); setOut(r); setWatching(true);
  };
  const result: FightResult | undefined = out?.result;

  return (
    <div className="max-w-3xl space-y-4">
      <h1 className="font-display text-4xl font-extrabold">Walki</h1>

      {!af && nf && opp && !result && (
        <Panel title="Najbliższa walka">
          <p className="font-display text-3xl font-bold">{opp.name}</p>
          <p className="text-mute text-sm mb-3">{FEDERATIONS.find((x) => x.id === nf.federationId)?.name}, {nf.date}, rekord rywala {opp.record.wins}-{opp.record.losses}-{opp.record.draws}, ocena {overallRating(opp.stats)} (Twoja {overallRating(f!.stats)})</p>
          <p className="text-sm font-semibold mb-2">Plan na pierwszą rundę</p>
          <TacticsPicker t={tactics} onChange={setTactics} />
          <button className="mt-4 px-4 py-2 rounded bg-red font-medium disabled:opacity-40" disabled={days !== 0} onClick={() => play(true)}>
            {days === 0 ? 'Walcz' : `Walka za ${days} dni`}
          </button>
          {days !== 0 && <p className="text-mute text-sm mt-2">Do tego czasu trenuj i regeneruj się w kalendarzu. Czas zatrzyma się w dniu walki.</p>}
        </Panel>
      )}
      {!af && !nf && !result && <Panel title="Najbliższa walka"><Empty>Brak walki. Podpisz kontrakt w zakładce Federacje.</Empty></Panel>}

      {af && lastRound && !watching && (
        <Panel title={`Przerwa po rundzie ${lastRound.round} z ${ROUNDS}`}>
          <p className="text-mute text-sm mb-3">Punkty: {af.state.scores[0]}-{af.state.scores[1]}. Rywal: {names[1]}.</p>
          {out && <RoundTable o={out} />}
          <div className="border border-line rounded p-3 my-4 text-sm">
            <p className="font-semibold mb-1">Narożnik</p>
            {!hasCoach ? <p className="text-mute">Nie masz trenera głównego, więc decydujesz sam. Zatrudnij go w zakładce Sztab.</p>
              : headSkill < 50 ? <p className="text-mute">Trener nie jest pewien. {advice!.text}</p>
              : <><p>{advice!.text}</p><button className="mt-2 px-3 py-1.5 rounded bg-raised border border-line" onClick={() => setTactics({ aggression: advice!.aggression, focus: advice!.focus })}>Zastosuj radę: {FOCUS_LABELS[advice!.focus]}</button></>}
          </div>
          <p className="text-sm font-semibold mb-2">Plan na rundę {af.state.nextRound}</p>
          <TacticsPicker t={tactics} onChange={setTactics} />
          <div className="flex gap-2 mt-4 flex-wrap">
            <button className="px-4 py-2 rounded bg-red font-medium" onClick={() => play(false)}>Następna runda</button>
            {out && <button className="px-4 py-2 rounded bg-raised border border-line" onClick={() => setWatching(true)}>Powtórka rundy</button>}
          </div>
        </Panel>
      )}
      {err && <p className="text-red-soft text-sm" role="alert">{err}</p>}

      {result && !watching && out && (
        <Panel title="Wynik">
          <p className="font-display text-3xl font-bold">{result.winner === null ? 'Remis' : result.winner === 0 ? 'Wygrywasz' : `Wygrywa ${out.opponent}`}, {M[result.method]}</p>
          <p className="text-mute text-sm mb-3">Runda {result.round}, punkty {result.scores[0]}-{result.scores[1]}.{out.injury ? ' Kontuzja po walce.' : ''}</p>
          <table className="w-full text-sm"><thead><tr className="text-mute text-left"><th></th><th>Ty</th><th>Rywal</th></tr></thead><tbody>
            {FINAL_ROWS.map(([l, fn]) => (
              <tr key={l} className="border-t border-line"><td className="py-1.5 text-mute">{l}</td><td>{fn(result.stats[0])}</td><td>{fn(result.stats[1])}</td></tr>))}
          </tbody></table>
          <div className="flex gap-2 mt-3 flex-wrap">
            <button className="px-4 py-2 rounded bg-raised border border-line" onClick={() => setWatching(true)}>Obejrzyj ostatnią rundę</button>
            <button className="px-4 py-2 rounded bg-red font-medium" onClick={() => { setOut(null); setLooks(null); }}>Dalej</button>
          </div>
        </Panel>
      )}

      {out && looks && watching && (
        <Suspense fallback={<div className="fixed inset-0 z-50 bg-base grid place-items-center text-mute">Ładowanie areny...</div>}>
          <FightViewer
            frames={out.frames} maxHp={out.maxHp} names={names} looks={looks} roundLabel={`${out.summary.round}`}
            final={result ? { winner: result.winner, method: result.method, round: result.round } : null}
            onClose={() => setWatching(false)} />
        </Suspense>
      )}

      <Panel title="Historia walk">
        {f!.history.length === 0 ? <Empty>Brak walk.</Empty> : (
          <ul className="text-sm divide-y divide-line">{[...f!.history].reverse().map((h, i) => (
            <li key={i} className="flex justify-between py-1.5"><span>{h.result === 'W' ? 'Wygrana' : h.result === 'L' ? 'Porażka' : 'Remis'} z {h.opponent}</span><span className="text-mute">{h.method}, runda {h.round}, {h.date}</span></li>))}
          </ul>
        )}
      </Panel>
    </div>
  );
}
