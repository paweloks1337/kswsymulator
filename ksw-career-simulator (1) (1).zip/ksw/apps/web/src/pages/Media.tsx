import { useState } from 'react';
import { MEDIA_ACTIONS, SPONSOR_MONTHS, mediaBlocked, mediaOf, sponsorOffers, sponsorsOf } from '@ksw/engine';
import { Empty, Meter, Panel } from '../components/ui';
import { useCareer } from '../store';

const zl = (n: number) => `${n.toLocaleString('pl-PL')} zł`;

export default function Media() {
  const f = useCareer((s) => s.fighter)!;
  const { mediaAction, signSponsor } = useCareer();
  const [msg, setMsg] = useState<{ text: string; good: boolean } | null>(null);
  const m = mediaOf(f);
  const offers = sponsorOffers(f), deals = sponsorsOf(f);
  const run = async (id: string) => {
    const r = await mediaAction(id);
    setMsg(r.ok ? { text: r.text, good: r.good } : { text: r.reason, good: false });
  };
  return (
    <div className="max-w-4xl space-y-4">
      <h1 className="font-display text-4xl font-extrabold">Media</h1>
      <Panel title="Wizerunek">
        <div className="grid sm:grid-cols-2 gap-3">
          <Meter label="Popularność" value={m.popularity} /><Meter label="Reputacja sportowa" value={m.reputation} />
          <Meter label="Charyzma" value={m.charisma} /><Meter label="Kontrowersyjność" value={m.controversy} invert />
        </div>
        <p className="text-mute text-sm mt-3">Popularność podnosi gaże i otwiera sponsorów, ale z czasem słabnie. Wysokie kontrowersje odstraszają sponsorów, a jeden skandal może zerwać umowę.</p>
        {msg && <p className={`text-sm mt-3 ${msg.good ? '' : 'text-red-soft'}`} role="status">{msg.text}</p>}
      </Panel>
      <Panel title="Akcje">
        <p className="text-mute text-sm mb-3">Jedna akcja medialna dziennie.</p>
        <div className="grid sm:grid-cols-2 gap-3">{MEDIA_ACTIONS.map((a) => {
          const why = mediaBlocked(f, a.id);
          return (
            <div key={a.id} className="border border-line rounded p-3">
              <h3 className="font-display text-xl font-bold">{a.label}</h3>
              <p className="text-sm text-mute">{a.description}</p>
              {why && <p className="text-xs text-mute mt-1">{why}</p>}
              <button disabled={!!why} className="mt-2 px-3 py-1.5 rounded bg-red font-medium disabled:opacity-40" onClick={() => run(a.id)}>Wykonaj</button>
            </div>);
        })}</div>
      </Panel>
      <Panel title="Sponsorzy">
        {deals.length > 0 && (
          <ul className="text-sm divide-y divide-line mb-3">{deals.map((s) => (
            <li key={s.id} className="flex justify-between py-1.5"><span>{s.name}</span>
              <span className="text-mute">{zl(s.monthly)}/mies., premia za wygraną {zl(s.winBonus)}, zostało {s.monthsLeft} mies.</span></li>))}
          </ul>
        )}
        {offers.length === 0 ? <Empty>Brak nowych ofert. Zwiększ popularność i unikaj skandali.</Empty> : (
          <div className="space-y-3">{offers.map((o) => (
            <div key={o.id} className="border border-line rounded p-3">
              <h3 className="font-display text-xl font-bold">{o.name}</h3>
              <p className="text-sm text-mute">{zl(o.monthly)} miesięcznie przez {SPONSOR_MONTHS} mies., premia za wygraną {zl(o.winBonus)}. Zrywa umowę przy kontrowersjach powyżej {o.maxControversy}.</p>
              <button className="mt-2 px-3 py-1.5 rounded bg-red font-medium" onClick={async () => setMsg({ text: (await signSponsor(o.id)) ?? 'Podpisano umowę sponsorską.', good: true })}>Podpisz umowę</button>
            </div>))}
          </div>
        )}
      </Panel>
      <Panel title="Ostatnie wydarzenia medialne">
        {(f.log ?? []).length === 0 ? <Empty>Na razie cisza.</Empty> : (
          <ul className="text-sm divide-y divide-line">{[...(f.log ?? [])].reverse().map((l, i) => <li key={i} className="flex justify-between gap-3 py-1.5"><span>{l.text}</span><span className="text-mute shrink-0">{l.date}</span></li>)}</ul>
        )}
      </Panel>
    </div>
  );
}
