// Test service workera bez przeglądarki: uruchamia sw.js na atrapach caches/fetch.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { readFileSync } from 'node:fs';

const code = readFileSync(new URL('../public/sw.js', import.meta.url), 'utf8') + '\n;globalThis.__strategyFor = strategyFor;';

function makeEnv(fetchImpl) {
  const stores = new Map();
  const keyOf = (r) => (typeof r === 'string' ? new URL(r, 'https://game.test').href : r.url);
  const cacheApi = (map) => ({
    async match(r) { return map.get(keyOf(r))?.clone(); },
    async put(r, res) { map.set(keyOf(r), res); },
    async addAll(urls) { for (const u of urls) map.set(keyOf(u), await fetchImpl(new Request(keyOf(u)))); },
  });
  const caches = {
    async open(name) { if (!stores.has(name)) stores.set(name, new Map()); return cacheApi(stores.get(name)); },
    async keys() { return [...stores.keys()]; },
    async delete(name) { return stores.delete(name); },
    async match(r) { for (const m of stores.values()) { const h = m.get(keyOf(r)); if (h) return h.clone(); } return undefined; },
  };
  const listeners = {};
  const self = { location: { origin: 'https://game.test' }, addEventListener: (t, fn) => { listeners[t] = fn; }, skipWaiting: async () => { self.skipped = true; }, clients: { claim: async () => { self.claimed = true; } } };
  const ctx = vm.createContext({ self, caches, fetch: (...a) => fetchImpl(...a), Request, Response, URL, Promise, console });
  vm.runInContext(code, ctx);
  const dispatch = async (type, request) => {
    let waited, responded;
    listeners[type]({ request, waitUntil: (p) => { waited = p; }, respondWith: (p) => { responded = p; } });
    if (waited) await waited;
    return responded ? await responded : undefined;
  };
  return { self, stores, ctx, dispatch, caches };
}

const req = (path, init = {}, mode) => { const r = new Request(`https://game.test${path}`, init); return mode ? Object.defineProperty(r, 'mode', { value: mode }) : r; };

test('strategie zależne od adresu i metody', () => {
  const { ctx } = makeEnv(async () => new Response('x'));
  const s = (path, init, mode) => ctx.__strategyFor(`https://game.test${path}`, req(path, init, mode));
  assert.equal(s('/api/career'), 'network-only');
  assert.equal(s('/api/career/train', { method: 'POST', body: '{}' }), 'network-only');
  assert.equal(s('/assets/index-abc.js'), 'cache-first');
  assert.equal(s('/icons/icon-192.png'), 'cache-first');
  assert.equal(s('/', {}, 'navigate'), 'navigation');
  assert.equal(s('/trening', {}, 'navigate'), 'navigation');
  assert.equal(ctx.__strategyFor('https://fonts.gstatic.com/s/x.woff2', new Request('https://fonts.gstatic.com/s/x.woff2')), 'stale-while-revalidate');
  assert.equal(ctx.__strategyFor('https://evil.test/x.js', new Request('https://evil.test/x.js')), 'network-only');
});

test('zapytania do API nie są przechwytywane ani zapisywane', async () => {
  const { dispatch, stores } = makeEnv(async () => new Response('x'));
  assert.equal(await dispatch('fetch', req('/api/career')), undefined);
  assert.equal(await dispatch('fetch', req('/api/career/train', { method: 'POST', body: '{}' })), undefined);
  assert.equal([...stores.values()].reduce((n, m) => n + m.size, 0), 0);
});

test('instalacja zapisuje powłokę aplikacji i przejmuje kontrolę', async () => {
  const { dispatch, stores, self } = makeEnv(async () => new Response('x'));
  await dispatch('install');
  assert.ok(stores.get('ksw-shell-v1').size >= 4);
  assert.equal(self.skipped, true);
});

test('zasoby statyczne: pierwszy raz z sieci, potem z pamięci podręcznej', async () => {
  let calls = 0;
  const { dispatch } = makeEnv(async () => { calls++; return new Response('bundle'); });
  const r1 = await dispatch('fetch', req('/assets/app-1.js'));
  assert.equal(await r1.text(), 'bundle');
  const before = calls;
  const r2 = await dispatch('fetch', req('/assets/app-1.js'));
  assert.equal(await r2.text(), 'bundle');
  assert.equal(calls, before);
});

test('offline: nawigacja dostaje zapisaną powłokę, a API nadal zwraca błąd sieci', async () => {
  let online = true;
  const { dispatch } = makeEnv(async () => { if (!online) throw new TypeError('offline'); return new Response('<html>shell</html>'); });
  await dispatch('install');
  await dispatch('fetch', req('/', {}, 'navigate'));
  online = false;
  const res = await dispatch('fetch', req('/trening', {}, 'navigate'));
  assert.equal(await res.text(), '<html>shell</html>');
  assert.equal(await dispatch('fetch', req('/api/career')), undefined);
});

test('nowa wersja usuwa stare pamięci podręczne', async () => {
  const { dispatch, stores, caches } = makeEnv(async () => new Response('x'));
  await caches.open('ksw-shell-v0'); await caches.open('inny-sklep');
  await dispatch('activate');
  assert.deepEqual([...stores.keys()], []);
  await dispatch('install');
  await dispatch('activate');
  assert.deepEqual([...stores.keys()], ['ksw-shell-v1']);
});
