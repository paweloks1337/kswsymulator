// Service worker KSW Career: aplikacja działa offline po pierwszej wizycie (powłoka i zasoby),
// ale dane kariery zawsze idą przez sieć (/api nigdy nie jest cache'owane).
const VERSION = 'v1';
const SHELL = `ksw-shell-${VERSION}`;
const RUNTIME = `ksw-runtime-${VERSION}`;
const FONTS = `ksw-fonts-${VERSION}`;
const SHELL_URLS = ['/', '/manifest.webmanifest', '/icons/icon-192.png', '/icons/icon-512.png'];

function strategyFor(url, request) {
  const u = new URL(url);
  if (request.method !== 'GET') return 'network-only';
  if (u.hostname === 'fonts.googleapis.com' || u.hostname === 'fonts.gstatic.com') return 'stale-while-revalidate';
  if (u.origin !== self.location.origin) return 'network-only';
  if (u.pathname.startsWith('/api/')) return 'network-only';
  if (request.mode === 'navigate') return 'navigation';
  if (u.pathname.startsWith('/assets/') || u.pathname.startsWith('/icons/') || u.pathname === '/manifest.webmanifest') return 'cache-first';
  return 'network-first';
}

async function cacheFirst(request) {
  const hit = await caches.match(request);
  if (hit) return hit;
  const res = await fetch(request);
  if (res && res.ok) (await caches.open(RUNTIME)).put(request, res.clone());
  return res;
}

async function networkFirst(request) {
  try {
    const res = await fetch(request);
    if (res && res.ok) (await caches.open(RUNTIME)).put(request, res.clone());
    return res;
  } catch (e) {
    const hit = await caches.match(request);
    if (hit) return hit;
    throw e;
  }
}

async function navigation(request) {
  try {
    const res = await fetch(request);
    if (res && res.ok) (await caches.open(SHELL)).put('/', res.clone());
    return res;
  } catch (e) {
    const shell = await caches.match('/');
    if (shell) return shell;
    throw e;
  }
}

async function staleWhileRevalidate(request) {
  const cache = await caches.open(FONTS);
  const hit = await cache.match(request);
  const refresh = fetch(request).then((res) => { if (res && (res.ok || res.type === 'opaque')) cache.put(request, res.clone()); return res; }).catch(() => hit);
  return hit || refresh;
}

self.addEventListener('install', (event) => {
  event.waitUntil((async () => {
    const cache = await caches.open(SHELL);
    await cache.addAll(SHELL_URLS);
    await self.skipWaiting();
  })());
});

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    const keep = new Set([SHELL, RUNTIME, FONTS]);
    for (const name of await caches.keys()) if (!keep.has(name)) await caches.delete(name);
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', (event) => {
  const request = event.request;
  const strategy = strategyFor(request.url, request);
  if (strategy === 'network-only') return; // przeglądarka obsłuży sama
  const run = { 'cache-first': cacheFirst, 'network-first': networkFirst, navigation, 'stale-while-revalidate': staleWhileRevalidate }[strategy];
  event.respondWith(run(request));
});
