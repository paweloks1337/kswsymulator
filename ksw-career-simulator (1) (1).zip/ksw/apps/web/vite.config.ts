import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { fileURLToPath } from 'node:url';

export default defineConfig({
  plugins: [react()],
  build: {
    chunkSizeWarningLimit: 900,
    rollupOptions: {
      output: {
        manualChunks(id) {
          if (id.includes('node_modules/three') || id.includes('@react-three')) return 'three';
          if (id.includes('node_modules/react') || id.includes('node_modules/zustand') || id.includes('react-router')) return 'vendor';
        },
      },
    },
  },
  resolve: { alias: { '@ksw/engine': fileURLToPath(new URL('../../packages/engine/src/index.ts', import.meta.url)) } },
  server: {
    fs: { allow: ['../..'] },
    proxy: { '/api': { target: 'http://localhost:3001', rewrite: (p) => p.replace(/^\/api/, '') } },
  },
});
