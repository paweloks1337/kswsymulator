/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        base: '#000000', panel: '#141518', raised: '#1e2024', line: '#2c2e34',
        red: { DEFAULT: '#d6202a', soft: '#ef4650' },
        ink: '#ececee', mute: '#8c8f97',
      },
      fontFamily: {
        display: ['"Barlow Condensed"', 'Impact', 'sans-serif'],
        body: ['Barlow', 'system-ui', 'sans-serif'],
      },
    },
  },
  plugins: [],
};
