import Fastify from 'fastify';
import cors from '@fastify/cors';
import jwt from '@fastify/jwt';
import bcrypt from 'bcryptjs';
import { z } from 'zod';
import { PrismaClient } from '@prisma/client';
import {
  acceptOffer, advanceDays, changeLifestyle, doMedia, signSponsor, beginFight, fightRound, fireStaff, hireStaff, createFighter, daysToFight, generateWorld, resolveFight, simulateWorld, trainDay, validateProfile, STYLES,
  type Fighter, type FighterProfile, type World,
} from '@ksw/engine';

const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET || JWT_SECRET.length < 16) throw new Error('Ustaw JWT_SECRET (min. 16 znaków) w .env');

const prisma = new PrismaClient();
const app = Fastify({ logger: true });
await app.register(cors, { origin: (process.env.CORS_ORIGIN ?? 'http://localhost:5173').split(',') });
await app.register(jwt, { secret: JWT_SECRET, sign: { expiresIn: '7d' } });

const credentials = z.object({ email: z.string().email().max(120).toLowerCase(), password: z.string().min(8).max(100) });
const profileSchema = z.object({
  firstName: z.string().max(30), lastName: z.string().max(30), nickname: z.string().max(30),
  age: z.number(), nationality: z.string().max(40), heightCm: z.number(), weightKg: z.number(), reachCm: z.number(),
  dominantHand: z.enum(['right', 'left', 'switch']), style: z.enum(STYLES), experienceYears: z.number(),
  appearance: z.object({ face: z.string(), hair: z.string(), beard: z.string(), build: z.string(), tattoos: z.string(), kit: z.string() }),
});

const tacticsSchema = z.object({ aggression: z.number().min(0).max(1), focus: z.enum(['balanced', 'pressure', 'distance', 'takedown', 'counter', 'conserve', 'body']) });
const simOpts = (c: { fighter: Fighter }) => ({
  fromDate: c.fighter.gameDate,
  protect: [c.fighter.nextFight?.opponentId, c.fighter.activeFight?.opponentId].filter((x): x is string => !!x),
});
const seed = () => (Math.random() * 2 ** 32) >>> 0;
const auth = async (req: any, reply: any) => { try { await req.jwtVerify(); } catch { return reply.code(401).send({ error: 'Zaloguj się ponownie.' }); } };
const uid = (req: any): string => req.user.sub;

async function loadCareer(userId: string) {
  const c = await prisma.career.findUnique({ where: { userId } });
  return c ? { id: c.id, fighter: c.fighter as unknown as Fighter, world: c.world as unknown as World } : null;
}
const save = (userId: string, fighter: Fighter, world: World) =>
  prisma.career.update({ where: { userId }, data: { fighter: fighter as any, world: world as any, gameDate: fighter.gameDate } });
const bad = (reply: any, msg = 'Brak kariery lub nieprawidłowe dane.') => reply.code(400).send({ error: msg });

app.post('/auth/register', async (req, reply) => {
  const p = credentials.safeParse(req.body);
  if (!p.success) return reply.code(400).send({ error: 'Podaj poprawny e-mail i hasło (min. 8 znaków).' });
  if (await prisma.user.findUnique({ where: { email: p.data.email } })) return reply.code(409).send({ error: 'Ten e-mail jest już zajęty.' });
  const user = await prisma.user.create({ data: { email: p.data.email, passwordHash: await bcrypt.hash(p.data.password, 12) } });
  return { token: app.jwt.sign({ sub: user.id }) };
});

app.post('/auth/login', async (req, reply) => {
  const p = credentials.safeParse(req.body);
  const user = p.success ? await prisma.user.findUnique({ where: { email: p.data.email } }) : null;
  if (!p.success || !user || !(await bcrypt.compare(p.data.password, user.passwordHash)))
    return reply.code(401).send({ error: 'Nieprawidłowy e-mail lub hasło.' });
  return { token: app.jwt.sign({ sub: user.id }) };
});

app.get('/career', { preHandler: auth }, async (req) => {
  const c = await loadCareer(uid(req));
  return { fighter: c?.fighter ?? null, world: c?.world ?? null };
});

app.post('/career', { preHandler: auth }, async (req, reply) => {
  const p = profileSchema.safeParse(req.body);
  if (!p.success) return reply.code(400).send({ error: 'Nieprawidłowe dane zawodnika.' });
  const errors = validateProfile(p.data as FighterProfile);
  if (errors.length) return reply.code(400).send({ error: errors.join(' ') });
  if (await loadCareer(uid(req))) return reply.code(409).send({ error: 'Kariera już istnieje. Usuń ją, aby zacząć nową.' });
  const fighter = createFighter(p.data as FighterProfile, seed());
  const world = generateWorld(seed());
  await prisma.career.create({ data: { userId: uid(req), fighter: fighter as any, world: world as any, gameDate: fighter.gameDate } });
  return { fighter, world };
});

app.delete('/career', { preHandler: auth }, async (req) => {
  await prisma.career.deleteMany({ where: { userId: uid(req) } });
  return { ok: true };
});

// Akcje liczy serwer (silnik), klient nie wysyła stanu zawodnika.
app.post('/career/train', { preHandler: auth }, async (req, reply) => {
  const b = z.object({ activityId: z.string().max(30) }).safeParse(req.body);
  const c = await loadCareer(uid(req));
  if (!b.success || !c) return bad(reply);
  if (c.fighter.activeFight) return reply.code(409).send({ error: 'Trwa walka. Dokończ ją w zakładce Walki.' });
  if (daysToFight(c.fighter) === 0) return reply.code(409).send({ error: 'Dziś walka. Idź do zakładki Walki.' });
  const r = trainDay(c.fighter, b.data.activityId, seed());
  if (!r.ok) return reply.code(409).send({ error: r.reason });
  const world = simulateWorld(c.world, 1, seed(), simOpts(c));
  await save(uid(req), r.fighter, world);
  return { ...r, world };
});

app.post('/career/rest', { preHandler: auth }, async (req, reply) => {
  const b = z.object({ days: z.number().int().min(1).max(30) }).safeParse(req.body);
  const c = await loadCareer(uid(req));
  if (!b.success || !c) return bad(reply);
  if (c.fighter.activeFight) return reply.code(409).send({ error: 'Trwa walka. Dokończ ją w zakładce Walki.' });
  const limit = daysToFight(c.fighter);
  if (limit === 0) return reply.code(409).send({ error: 'Dziś walka. Idź do zakładki Walki.' });
  const days = limit === null ? b.data.days : Math.min(b.data.days, limit);
  const fighter = advanceDays(c.fighter, days);
  const world = simulateWorld(c.world, days, seed(), simOpts(c));
  await save(uid(req), fighter, world);
  return { fighter, world, days };
});

app.post('/career/offers/accept', { preHandler: auth }, async (req, reply) => {
  const b = z.object({ federationId: z.string().max(30) }).safeParse(req.body);
  const c = await loadCareer(uid(req));
  if (!b.success || !c) return bad(reply);
  try {
    const fighter = acceptOffer(c.fighter, c.world, b.data.federationId, seed());
    await save(uid(req), fighter, c.world);
    return { fighter, world: c.world };
  } catch (e) { return reply.code(409).send({ error: (e as Error).message }); }
});

app.post('/career/fight', { preHandler: auth }, async (req, reply) => {
  const b = z.object({ aggression: z.number().min(0).max(1) }).safeParse(req.body);
  const c = await loadCareer(uid(req));
  if (!b.success || !c) return bad(reply);
  try {
    const r = resolveFight(c.fighter, c.world, b.data.aggression, seed());
    await save(uid(req), r.fighter, r.world);
    return r;
  } catch (e) { return reply.code(409).send({ error: (e as Error).message }); }
});

const fightAction = (start: boolean) => async (req: any, reply: any) => {
  const b = tacticsSchema.safeParse(req.body);
  const c = await loadCareer(uid(req));
  if (!b.success || !c) return bad(reply);
  try {
    const r = start ? beginFight(c.fighter, c.world, b.data, seed()) : fightRound(c.fighter, c.world, b.data, seed());
    await save(uid(req), r.fighter, r.world);
    return r;
  } catch (e) { return reply.code(409).send({ error: (e as Error).message }); }
};
app.post('/career/fight/start', { preHandler: auth }, fightAction(true));
app.post('/career/fight/round', { preHandler: auth }, fightAction(false));

app.post('/career/media', { preHandler: auth }, async (req, reply) => {
  const b = z.object({ id: z.string().max(40) }).safeParse(req.body);
  const c = await loadCareer(uid(req));
  if (!b.success || !c) return bad(reply);
  try {
    const r = doMedia(c.fighter, b.data.id, seed());
    await save(uid(req), r.fighter, c.world);
    return { fighter: r.fighter, world: c.world, text: r.text, good: r.good };
  } catch (e) { return reply.code(409).send({ error: (e as Error).message }); }
});

app.post('/career/lifestyle', { preHandler: auth }, async (req, reply) => {
  const b = z.object({ kind: z.enum(['housing', 'car', 'gym']), id: z.string().max(20).optional() }).safeParse(req.body);
  const c = await loadCareer(uid(req));
  if (!b.success || !c) return bad(reply);
  try {
    const fighter = changeLifestyle(c.fighter, b.data.kind, b.data.id);
    await save(uid(req), fighter, c.world);
    return { fighter, world: c.world };
  } catch (e) { return reply.code(409).send({ error: (e as Error).message }); }
});

const staffAction = (fn: (f: Fighter, id: string) => Fighter) => async (req: any, reply: any) => {
  const b = z.object({ id: z.string().max(40) }).safeParse(req.body);
  const c = await loadCareer(uid(req));
  if (!b.success || !c) return bad(reply);
  if (c.fighter.activeFight) return reply.code(409).send({ error: 'Trwa walka. Dokończ ją w zakładce Walki.' });
  try {
    const fighter = fn(c.fighter, b.data.id);
    await save(uid(req), fighter, c.world);
    return { fighter, world: c.world };
  } catch (e) { return reply.code(409).send({ error: (e as Error).message }); }
};
app.post('/career/staff/hire', { preHandler: auth }, staffAction(hireStaff));
app.post('/career/sponsor/sign', { preHandler: auth }, staffAction(signSponsor));
app.post('/career/staff/fire', { preHandler: auth }, staffAction(fireStaff));

app.setErrorHandler((err, _req, reply) => {
  app.log.error(err);
  reply.code(500).send({ error: 'Błąd serwera.' });
});

await app.listen({ port: Number(process.env.PORT ?? 3001), host: '0.0.0.0' });
