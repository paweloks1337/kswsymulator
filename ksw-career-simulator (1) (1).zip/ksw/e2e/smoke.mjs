// Test dymny całej gry. Wymaga uruchomionych: PostgreSQL, API (npm run dev:api) i web (npm run dev).
// Uruchom: npx playwright install chromium && npm run e2e   (BASE_URL, domyślnie http://localhost:5173)
// Uwaga: odtwarzacz 3D renderuje się naprawdę (WebGL), test sprawdza tylko, że się otwiera i zamyka.
import { chromium } from 'playwright';
const URL = process.env.BASE_URL ?? 'http://localhost:5173';
const EMAIL = `gracz+${Date.now()}@test.pl`;
const browser = await chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 1280, height: 800 } });
const page = await ctx.newPage();
const problems = [];
page.on('pageerror', (e) => problems.push('pageerror: ' + e.message));
page.on('console', (m) => { if (m.type() === 'error') problems.push('console: ' + m.text()); });
page.on('response', (r) => { if (r.url().includes('/api/') && r.status() >= 400 && r.status() !== 409) problems.push(`API ${r.status()} ${r.url()}`); });
const steps = [];
const step = async (name, fn) => { try { await fn(); steps.push('OK   ' + name); } catch (e) { steps.push('FAIL ' + name + ' :: ' + String(e.message).split('\n')[0]); } };
const nav = (label) => page.locator('aside nav a', { hasText: new RegExp(`^${label}`) }).first().click();
const text = (t, o = {}) => page.getByText(t, o).first().waitFor({ timeout: 8000 });

await page.goto(URL);
await step('ekran logowania', () => text('Zaloguj się'));
await step('rejestracja', async () => {
  await page.getByText('Nie masz konta?').click();
  await page.getByLabel('E-mail').fill(EMAIL); await page.getByLabel(/Hasło/).fill('haslo12345');
  await page.getByRole('button', { name: 'Załóż konto' }).click(); await text('Nowy zawodnik');
});
await step('kreator: walidacja blokuje start bez imienia', async () => {
  const b = page.getByRole('button', { name: 'Rozpocznij karierę' }); if (!(await b.isDisabled())) throw new Error('przycisk aktywny');
});
await step('kreator: utworzenie zawodnika', async () => {
  await page.getByLabel('Imię').fill('Jan'); await page.getByLabel('Nazwisko').fill('Testowy'); await page.getByLabel('Pseudonim').fill('Młot');
  await page.getByRole('button', { name: 'Rozpocznij karierę' }).click(); await text('Rekord');
});
await page.screenshot({ path: '/tmp/e2e/shot-dashboard.png' });
await step('trening: sesja zmienia stan', async () => { await nav('Trening'); await page.getByRole('button', { name: 'Trenuj' }).first().click(); await page.locator('[role=status]').filter({ hasText: /\+/ }).waitFor({ timeout: 8000 }); });
await step('sztab: rynek pracy widoczny', async () => { await nav('Sztab'); await text('Trener główny'); });
await step('media: akcja', async () => { await nav('Media'); await page.getByRole('button', { name: 'Wykonaj' }).first().click(); await page.locator('[role=status]').filter({ hasText: /\w+/ }).first().waitFor({ timeout: 8000 }); });
await step('federacje: podpisanie kontraktu', async () => { await nav('Federacje'); await page.getByRole('button', { name: 'Podpisz kontrakt' }).first().click(); await text('Aktywny kontrakt'); });
await step('kalendarz: przewijanie do dnia walki', async () => {
  await nav('Kalendarz');
  for (let i = 0; i < 3; i++) { await page.getByRole('button', { name: '+30 dni' }).click(); await page.waitForTimeout(250); }
});
await step('walki: dzień walki, przycisk Walcz aktywny', async () => { await nav('Walki'); const b = page.getByRole('button', { name: 'Walcz', exact: true }); await b.waitFor({ timeout: 8000 }); if (await b.isDisabled()) throw new Error('Walcz nieaktywny'); });
await step('walki: wybór taktyki', async () => { await page.getByRole('button', { name: 'Szukaj obalenia' }).click(); });
await page.screenshot({ path: '/tmp/e2e/shot-walki.png' });
let rounds = 0;
await step('walka: rundy z przerwami do wyniku', async () => {
  await page.getByRole('button', { name: 'Walcz', exact: true }).click();
  for (let i = 0; i < 4; i++) {
    await page.getByRole('button', { name: 'Pomiń' }).waitFor({ timeout: 15000 }); rounds++;
    await page.getByRole('button', { name: 'Pomiń' }).click(); await page.waitForTimeout(500);
    await page.getByRole('button', { name: /^(Przerwa|Zamknij)$/ }).click();
    if (await page.getByText('Wynik', { exact: true }).first().isVisible().catch(() => false)) return;
    const next = page.getByRole('button', { name: 'Następna runda' });
    await next.waitFor({ timeout: 3000 });
    await page.getByRole('button', { name: 'Zastosuj radę' }).first().click({ timeout: 500 }).catch(() => {});
    await next.click();
  }
  await text('Wynik');
});
console.log('rund rozegranych:', rounds);
await page.screenshot({ path: '/tmp/e2e/shot-wynik.png' });
await step('po walce: historia i nowy rekord', async () => { await text('Historia walk'); await nav('Walki'); await page.getByText(/Wygrana z|Porażka z|Remis z/).first().waitFor({ timeout: 3000 }); });
for (const [label, probe] of [['Dashboard', 'Rekord'], ['Historia', 'Kariera w liczbach'], ['Profil zawodnika', 'Atrybuty'], ['Zdrowie', 'Kontuzje'], ['Finanse', 'Mieszkanie'], ['Rankingi', 'Wydarzenia w świecie'], ['Sztab', 'Twój sztab'], ['Media', 'Sponsorzy'], ['Kalendarz', 'Przewiń czas'], ['Ustawienia', 'Aplikacja na telefonie']])
  await step(`ekran: ${label}`, async () => { await nav(label); await text(probe); });
await step('finanse: zakup domowej siłowni zablokowany bez środków lub udany', async () => { await nav('Finanse'); await text('Domowa siłownia'); });
await step('przeładowanie strony zachowuje sesję i karierę', async () => { await page.reload(); await text('Mieszkanie'); await nav('Dashboard'); await text('Rekord'); });
await step('wylogowanie', async () => { await nav('Ustawienia'); await page.getByRole('button', { name: 'Wyloguj' }).click(); await text('Zaloguj się'); });
await step('ponowne logowanie', async () => {
  await page.getByLabel('E-mail').fill(EMAIL); await page.getByLabel(/Hasło/).fill('haslo12345');
  await page.getByRole('button', { name: 'Zaloguj się' }).click(); await nav('Dashboard'); await text('Rekord');
});
// widok mobilny
const m = await browser.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true });
const mp = await m.newPage();
mp.on('pageerror', (e) => problems.push('mobile pageerror: ' + e.message));
await mp.goto(URL);
await step('mobile: logowanie i dolna nawigacja', async () => {
  await mp.getByLabel('E-mail').fill(EMAIL); await mp.getByLabel(/Hasło/).fill('haslo12345');
  await mp.getByRole('button', { name: 'Zaloguj się' }).click(); await mp.getByText('Rekord').first().waitFor({ timeout: 8000 });
  const box = await mp.locator('aside').boundingBox();
  if (!box || box.y < 600) throw new Error('nawigacja nie jest na dole: ' + JSON.stringify(box));
  const overflow = await mp.evaluate(() => document.documentElement.scrollWidth > window.innerWidth + 1);
  if (overflow) throw new Error('poziome przewijanie strony');
});
await mp.screenshot({ path: '/tmp/e2e/shot-mobile.png' });
for (const label of ['Dashboard', 'Profil zawodnika', 'Trening', 'Sztab', 'Zdrowie', 'Federacje', 'Walki', 'Rankingi', 'Media', 'Finanse', 'Kalendarz', 'Historia', 'Ustawienia'])
  await step(`mobile bez poziomego przewijania: ${label}`, async () => {
    await mp.locator('aside nav a', { hasText: new RegExp(`^${label}`) }).first().click(); await mp.waitForTimeout(150);
    const w = await mp.evaluate(() => ({ s: document.documentElement.scrollWidth, i: window.innerWidth, m: Math.max(...[...document.querySelectorAll('main *')].map((e) => e.getBoundingClientRect().right)) }));
    if (w.s > w.i + 1 || w.m > w.i + 1) throw new Error(`szerokość ${JSON.stringify(w)}`);
  });
await mp.locator('aside nav a', { hasText: /^Walki/ }).first().click(); await mp.screenshot({ path: '/tmp/e2e/shot-mobile-walki.png' });
await mp.locator('aside nav a', { hasText: /^Dashboard/ }).first().click(); await mp.waitForTimeout(150); await mp.screenshot({ path: '/tmp/e2e/shot-mobile.png' });
console.log(steps.join('\n'));
console.log('\nPROBLEMY:', problems.length ? '\n' + [...new Set(problems)].join('\n') : 'brak');
await browser.close();
