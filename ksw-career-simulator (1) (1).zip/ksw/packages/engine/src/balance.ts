import { advanceDays } from './calendar';
import { createFighter, overallRating } from './fighter';
import { daysToFight } from './calendar';
import { doMedia, mediaBlocked, mediaOf, signSponsor, sponsorOffers } from './media';
import { hireStaff, staffMarket, staffOf } from './staff';
import { changeCar, changeHousing, lifestyleOf, upgradeGym } from './lifestyle';
import { ACTIVITIES, trainDay } from './training';
import { acceptOffer, generateOffers, generateWorld, resolveFight, simulateWorld } from './world';
import type { Fighter, FighterProfile, StaffRole, World } from './types';

/** Prosta polityka gracza (bot) do badania balansu: trenuje, regeneruje się, walczy, zatrudnia sztab, dba o media. */
export interface Policy { name: string; focus: string[]; hireStaff: boolean; media: boolean; restAt: number; lifestyle?: boolean }

export const POLICIES: Policy[] = [
  { name: 'pełen', focus: ['main', 'gym', 'cardio', 'main', 'sparring'], hireStaff: true, media: true, restAt: 60 },
  { name: 'pełen+styl', focus: ['main', 'gym', 'cardio', 'main', 'sparring'], hireStaff: true, media: true, restAt: 60, lifestyle: true },
  { name: 'tylko trening', focus: ['main', 'gym', 'cardio', 'main', 'sparring'], hireStaff: false, media: false, restAt: 60 },
  { name: 'leń', focus: ['recovery'], hireStaff: false, media: false, restAt: 60 },
  { name: 'przetrenowany', focus: ['sparring', 'wrestling', 'gym'], hireStaff: false, media: false, restAt: 95 },
];

const MAIN: Record<string, string> = { boxing: 'boxing', kickboxing: 'kickboxing', muaythai: 'muaythai', wrestling: 'wrestling', bjj: 'bjj', mma: 'bjj' };

export interface Snapshot { day: number; money: number; rating: number; wins: number; losses: number; draws: number; popularity: number; injuries: number; fed: string | null }
export interface CareerLog { snapshots: Snapshot[]; fights: number; trainingDays: number; injuriesTotal: number; trainingInjuries: number; bankruptDay: number | null; finalFighter: Fighter; firstContractDay: number | null; ironCageDay: number | null; apexDay: number | null }

export function playCareer(profile: FighterProfile, policy: Policy, days: number, seed: number): CareerLog {
  let f = createFighter(profile, seed);
  let world: World = generateWorld(seed + 1);
  let s = seed * 7919;
  const nextSeed = () => (s = (s * 1664525 + 1013904223) >>> 0);
  const log: CareerLog = { snapshots: [], fights: 0, trainingDays: 0, injuriesTotal: 0, trainingInjuries: 0, bankruptDay: null, finalFighter: f, firstContractDay: null, ironCageDay: null, apexDay: null };
  let step = 0;
  const pass = (n: number) => { f = advanceDays(f, n); world = simulateWorld(world, n, nextSeed(), { fromDate: f.gameDate, protect: [f.nextFight?.opponentId].filter((x): x is string => !!x) }); };

  for (let day = 0; day < days; day++) {
    if (daysToFight(f) === 0) {
      const r = resolveFight(f, world, 0.5, nextSeed());
      log.fights++; if (r.injury) log.injuriesTotal++;
      f = r.fighter; world = r.world;
      continue;
    }
    if (!f.contract) {
      const offers = generateOffers(f).sort((a, b) => b.purse - a.purse);
      if (offers[0]) { f = acceptOffer(f, world, offers[0].federationId, nextSeed()); log.firstContractDay ??= day; if (offers[0].federationId !== 'arena') log.ironCageDay ??= day; }
    } else if (f.contract.federationId !== 'arena') log.ironCageDay ??= day;
    if (f.contract?.federationId === 'apex') log.apexDay ??= day;

    if (policy.hireStaff && f.money > 6000) {
      for (const role of ['head', 'fitness', 'physio', 'manager'] as StaffRole[]) {
        if (staffOf(f).some((m) => m.role === role)) continue;
        const best = staffMarket(f).filter((c) => c.role === role && c.salary * 3 < f.money / 2).sort((a, b) => b.skill - a.skill)[0];
        if (best) { try { f = hireStaff(f, best.id); } catch { /* brak środków */ } break; }
      }
    }
    if (policy.lifestyle) {
      const l = lifestyleOf(f);
      try {
        if (l.gym < 1 && f.money > 12000) f = upgradeGym(f);
        else if (l.car === 'none' && f.money > 40000) f = changeCar(f, 'used');
        else if (l.housing === 'flat' && f.money > 50000) f = changeHousing(f, 'penthouse');
        else if (l.gym < 2 && f.money > 70000) f = upgradeGym(f);
        else if (l.housing === 'penthouse' && f.money > 350000) f = changeHousing(f, 'house');
      } catch { /* za mało środków */ }
    }
    if (policy.media) {
      for (const o of sponsorOffers(f)) { try { f = signSponsor(f, o.id); } catch { /* */ } }
      const pick = f.nextFight && mediaBlocked(f, 'press') === null ? 'press' : mediaBlocked(f, 'interview_calm') === null ? 'interview_calm' : null;
      if (pick) f = doMedia(f, pick, nextSeed()).fighter;
    }

    const fatigued = f.condition.fatigue >= policy.restAt;
    const dtf = daysToFight(f);
    let act = policy.focus[step++ % policy.focus.length]!;
    if (act === 'main') act = MAIN[f.profile.style]!;
    if (fatigued) act = 'recovery';
    // dzień przed walką: odpoczynek
    if (dtf !== null && dtf <= 2) act = 'recovery';
    if (dtf !== null && dtf === 0) continue;
    const a = ACTIVITIES.find((x) => x.id === act)!;
    if (f.money < a.cost || (dtf !== null && dtf <= 0)) { pass(1); }
    else {
      const r = trainDay(f, a.id, nextSeed());
      if (r.ok) { f = r.fighter; if (a.id !== 'recovery') log.trainingDays++; if (r.injury) log.trainingInjuries++; world = simulateWorld(world, 1, nextSeed(), { fromDate: f.gameDate, protect: [f.nextFight?.opponentId].filter((x): x is string => !!x) }); }
      else pass(1);
    }
    if (f.money < -3000 && log.bankruptDay === null) log.bankruptDay = day;
    if (day % 30 === 29) log.snapshots.push({ day: day + 1, money: f.money, rating: overallRating(f.stats), wins: f.record.wins, losses: f.record.losses, draws: f.record.draws, popularity: Math.round(mediaOf(f).popularity), injuries: f.injuries.length, fed: f.contract?.federationId ?? null });
  }
  log.finalFighter = f;
  return log;
}
