import { describe, expect, it } from 'vitest';
import {
  acceptOffer, advanceDays, applyFightMedia, createFighter, doMedia, generateOffers, generateWorld, mediaBlocked, mediaOf,
  signSponsor, sponsorOffers, resolveFight, type Fighter, type FighterProfile,
} from './index';

const prof: FighterProfile = {
  firstName: 'Jan', lastName: 'K', nickname: '', age: 25, nationality: 'Polska', heightCm: 180, weightKg: 77, reachCm: 183,
  dominantHand: 'right', style: 'mma', experienceYears: 5,
  appearance: { face: 'Kanciasta', hair: 'Krótkie', beard: 'Brak', build: 'Atletyczna', tattoos: 'Brak', kit: 'Czerwony' },
};
const w = generateWorld(2);
const mk = (): Fighter => createFighter(prof, 42);
const withFight = (): Fighter => acceptOffer(mk(), w, 'arena', 1);

describe('media actions', () => {
  it('a calm interview raises popularity and is limited to one action per day', () => {
    const f = mk(); const r = doMedia(f, 'interview_calm', 1);
    expect(mediaOf(r.fighter).popularity).toBeGreaterThan(mediaOf(f).popularity);
    expect(() => doMedia(r.fighter, 'social', 2)).toThrow();
    expect(() => doMedia(advanceDays(r.fighter, 1), 'social', 2)).not.toThrow();
  });
  it('fight-related actions need a close enough fight', () => {
    const f = mk();
    expect(mediaBlocked(f, 'trash_talk')).not.toBeNull();
    const g = withFight(); // walka za 56 dni
    expect(mediaBlocked(g, 'trash_talk')).not.toBeNull();
    expect(mediaBlocked(advanceDays(g, 40), 'trash_talk')).toBeNull();
    expect(mediaBlocked(advanceDays(g, 40), 'press')).not.toBeNull();
    expect(mediaBlocked(advanceDays(g, 45), 'press')).toBeNull();
    expect(mediaBlocked(advanceDays(g, 55), 'face_off')).toBeNull();
  });
  it('trash talk raises hype (max 2) and controversy on success', () => {
    let f = advanceDays(withFight(), 40);
    f = { ...f, media: { ...mediaOf(f), charisma: 100 } };
    const r = doMedia(f, 'trash_talk', 1);
    expect(r.fighter.nextFight!.hype).toBe(1);
    expect(mediaOf(r.fighter).controversy).toBeGreaterThan(0);
    const r2 = doMedia(advanceDays(r.fighter, 1), 'trash_talk', 2);
    expect(() => doMedia(advanceDays(r2.fighter, 1), 'trash_talk', 3)).toThrow();
  });
  it('bold interviews are riskier for low-charisma fighters', () => {
    const rate = (charisma: number) => { let ok = 0; for (let s = 1; s <= 200; s++) { const f = { ...mk(), media: { ...mediaOf(mk()), charisma } }; if (doMedia(f, 'interview_bold', s).good) ok++; } return ok; };
    expect(rate(80)).toBeGreaterThan(rate(25));
  });
});

describe('media fatigue', () => {
  it('repeating actions gives diminishing returns, and rest restores them', () => {
    let f = mk(); const first = doMedia(f, 'interview_calm', 1).fighter;
    const gain1 = mediaOf(first).popularity - mediaOf(f).popularity;
    let g = first; for (let i = 0; i < 6; i++) g = doMedia(advanceDays(g, 1), 'interview_calm', 2 + i).fighter;
    const before = mediaOf(g).popularity;
    const next = doMedia(advanceDays(g, 1), 'interview_calm', 99).fighter;
    expect(mediaOf(next).popularity - before).toBeLessThan(gain1);
    const rested = doMedia(advanceDays(g, 15), 'interview_calm', 99).fighter;
    expect(mediaOf(rested).popularity - mediaOf(advanceDays(g, 15)).popularity).toBeGreaterThan(mediaOf(next).popularity - before);
  });
});

describe('consequences of a fight', () => {
  const m0 = (f: Fighter) => mediaOf(f).popularity;
  it('winning builds popularity, losing after hype hurts more', () => {
    const f = { ...mk(), media: { ...mediaOf(mk()), popularity: 30 } };
    const win = applyFightMedia(f, { won: true, lost: false, finish: false }, 0);
    const lossQuiet = applyFightMedia(f, { won: false, lost: true, finish: false }, 0);
    const lossHype = applyFightMedia(f, { won: false, lost: true, finish: false }, 2);
    expect(m0(win)).toBeGreaterThan(m0(f));
    expect(m0(lossHype)).toBeLessThan(m0(lossQuiet));
    expect(mediaOf(lossHype).controversy).toBeGreaterThan(0);
  });
  it('a real fight settles media effects', () => {
    let f = advanceDays(withFight(), 56);
    const before = m0(f);
    let changed = false;
    for (let seed = 1; seed <= 20 && !changed; seed++) {
      const r = resolveFight(f, w, 0.5, seed);
      if (r.result.winner !== null) changed = m0(r.fighter) !== before;
    }
    expect(changed).toBe(true);
  });
});

describe('sponsors and popularity', () => {
  const pop = (f: Fighter, popularity: number, controversy = 0): Fighter => ({ ...f, media: { ...mediaOf(f), popularity, controversy } });
  it('offers depend on popularity and controversy', () => {
    expect(sponsorOffers(mk()).length).toBe(0);
    expect(sponsorOffers(pop(mk(), 35)).map((t) => t.id)).toEqual(['local', 'brand']);
    expect(sponsorOffers(pop(mk(), 70, 60)).map((t) => t.id)).toEqual(['local', 'brand']);
    expect(sponsorOffers(pop(mk(), 70, 10)).map((t) => t.id)).toEqual(['local', 'brand', 'global']);
  });
  it('a signed sponsor pays monthly, expires, and walks away after a scandal', () => {
    let f = signSponsor(pop(mk(), 35), 'brand');
    const m1 = advanceDays(f, 28);
    expect(m1.money).toBeGreaterThan(f.money - 2100 - 1);
    expect(m1.sponsors![0]!.monthsLeft).toBe(5);
    const scandal = advanceDays({ ...f, media: { ...mediaOf(f), controversy: 95 } }, 28);
    expect(scandal.sponsors!.length).toBe(0);
    expect(scandal.log!.some((l) => l.text.includes('zrywa'))).toBe(true);
  });
  it('popularity and controversy fade each month', () => {
    const n = advanceDays(pop(mk(), 30, 20), 28);
    expect(mediaOf(n).popularity).toBe(28.2);
    expect(mediaOf(n).controversy).toBe(16);
  });
  it('popular fighters get better purses', () => {
    expect(generateOffers(pop(mk(), 80))[0]!.purse).toBeGreaterThan(generateOffers(mk())[0]!.purse);
  });
});
