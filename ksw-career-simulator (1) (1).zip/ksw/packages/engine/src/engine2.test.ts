import { describe, expect, it } from 'vitest';
import { ACTIVITIES, advanceDay, advanceDays, combatantFrom, createFighter, diminishing, simulateFight, trainDay, type Combatant, type FighterProfile } from './index';
import { computeStartingStats } from './index';

const prof: FighterProfile = {
  firstName: 'Jan', lastName: 'K', nickname: '', age: 25, nationality: 'Polska', heightCm: 180, weightKg: 77, reachCm: 183,
  dominantHand: 'right', style: 'boxing', experienceYears: 5,
  appearance: { face: 'Kanciasta', hair: 'Krótkie', beard: 'Brak', build: 'Atletyczna', tattoos: 'Brak', kit: 'Czerwony' },
};
const mk = () => createFighter(prof, 42);

describe('training', () => {
  it('raises the trained attribute, adds fatigue and advances the day', () => {
    const f = mk(); const r = trainDay(f, 'boxing', 1);
    if (!r.ok) throw new Error(r.reason);
    expect(r.fighter.stats.boxing).toBeGreaterThan(f.stats.boxing);
    expect(r.fighter.condition.fatigue).toBeGreaterThan(f.condition.fatigue);
    expect(r.fighter.gameDate > f.gameDate).toBe(true);
  });
  it('has diminishing returns', () => expect(diminishing(60)).toBeLessThan(diminishing(5)));
  it('blocks training when exhausted, allows recovery', () => {
    const f = mk(); f.condition.fatigue = 95;
    expect(trainDay(f, 'gym', 1).ok).toBe(false);
    const r = trainDay(f, 'recovery', 1);
    if (!r.ok) throw new Error('recovery blocked');
    expect(r.fighter.condition.fatigue).toBeLessThan(95);
  });
  it('sparring causes injuries more often than cardio', () => {
    const n = (id: string) => { let c = 0; for (let s = 1; s <= 400; s++) { const r = trainDay(mk(), id, s); if (r.ok && r.injury) c++; } return c; };
    expect(n('sparring')).toBeGreaterThan(n('cardio'));
  });
  it('injuries heal over time and limit health meanwhile', () => {
    const f = { ...mk(), injuries: [{ area: 'knee' as const, severity: 1 as const, daysLeft: 3 }] };
    expect(advanceDays(f, 2).injuries.length).toBe(1);
    expect(advanceDays(f, 3).injuries.length).toBe(0);
  });
  it('all activities reference valid data', () => expect(ACTIVITIES.length).toBe(9));
  it('advanceDay never goes below zero fatigue', () => expect(advanceDay(mk()).condition.fatigue).toBe(0));
});

describe('fight simulation', () => {
  const cb = (over: Partial<Record<string, number>>, name = 'X'): Combatant => {
    const stats = computeStartingStats(prof);
    for (const k of Object.keys(over)) (stats as Record<string, number>)[k] = over[k]!;
    return { name, stats, fatigue: 0, health: 100, aggression: 0.5 };
  };
  const strong = cb({ boxing: 75, kickboxing: 70, muaythai: 60, wrestling: 70, bjj: 70, defense: 70, reflex: 65, precision: 70, durability: 70, strength: 65 }, 'S');
  const weak = cb({ boxing: 40, kickboxing: 35, muaythai: 30, wrestling: 35, bjj: 35, defense: 35, reflex: 35, precision: 35, durability: 40, strength: 40 }, 'W');
  it('is deterministic per seed', () => expect(simulateFight(strong, weak, 5)).toEqual(simulateFight(strong, weak, 5)));
  it('the stronger fighter wins most fights', () => {
    let w = 0; for (let s = 1; s <= 200; s++) if (simulateFight(strong, weak, s).winner === 0) w++;
    expect(w).toBeGreaterThan(140);
  });
  it('equal fighters split roughly evenly and fights have varied endings', () => {
    let w = 0; const m = new Set<string>();
    for (let s = 1; s <= 300; s++) { const r = simulateFight(strong, { ...strong, name: 'T' }, s); if (r.winner === 0) w++; m.add(r.method); }
    expect(w).toBeGreaterThan(90); expect(w).toBeLessThan(150);
    expect(m.size).toBeGreaterThanOrEqual(2);
  });
  it('exhausted fighter loses more often', () => {
    let w = 0; for (let s = 1; s <= 200; s++) if (simulateFight({ ...strong, fatigue: 90 }, strong, s).winner === 0) w++;
    expect(w).toBeLessThan(90);
  });
  it('combatantFrom works', () => expect(combatantFrom(mk()).health).toBe(100));
});

describe('fight timeline (dla odtwarzacza 3D)', () => {
  const stats = computeStartingStats(prof);
  const c: Combatant = { name: 'A', stats, fatigue: 0, health: 100, aggression: 0.5 };
  it('ends with a frame that matches the result', () => {
    for (let s = 1; s <= 60; s++) {
      const r = simulateFight(c, { ...c, name: 'B' }, s);
      const last = r.timeline[r.timeline.length - 1]!;
      expect(last.end).toBe(r.method);
      expect(last.winner === undefined ? null : last.winner).toBe(r.winner);
      expect(r.timeline.length).toBeGreaterThan(0);
    }
  });
  it('hp never rises and ground frames name the top fighter', () => {
    const r = simulateFight(c, { ...c, name: 'B' }, 11);
    for (let i = 1; i < r.timeline.length; i++) {
      expect(r.timeline[i]!.hp[0]).toBeLessThanOrEqual(r.timeline[i - 1]!.hp[0]);
      expect(r.timeline[i]!.hp[1]).toBeLessThanOrEqual(r.timeline[i - 1]!.hp[1]);
    }
    for (const f of r.timeline) expect(f.ground === (f.top !== null)).toBe(true);
  });
  it('records varied action kinds', () => {
    const kinds = new Set<string>();
    for (let s = 1; s <= 30; s++) for (const f of simulateFight(c, { ...c, name: 'B' }, s).timeline) f.actions.forEach((a) => kinds.add(a.kind));
    expect(kinds.has('punch') && kinds.has('takedown')).toBe(true);
    expect(kinds.size).toBeGreaterThanOrEqual(5);
  });
});
