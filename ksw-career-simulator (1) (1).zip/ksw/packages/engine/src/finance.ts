import type { Fighter } from './types';

export const START_MONEY = 3000;
export const RENT = 700;
export const FOOD = 200;
export const TAX_RATE = 0.19;

export function charge(f: Fighter, label: string, amount: number): Fighter {
  return { ...f, money: f.money + amount, ledger: [...f.ledger, { date: f.gameDate, label, amount }].slice(-60) };
}

/** Pierwszego dnia miesiąca: jedzenie i pensje sztabu (mieszkanie i transport: lifestyle.ts). Saldo może zejść poniżej zera (dług). */
export function monthlyExpenses(f: Fighter): Fighter {
  let n = charge(f, 'Jedzenie', -FOOD);
  const staff = n.staff ?? [];
  for (const m of staff) n = charge(n, `Pensja: ${m.name}`, -m.salary);
  return { ...n, staff: staff.map((m) => ({ ...m, cooperation: Math.min(100, m.cooperation + 3) })) };
}
