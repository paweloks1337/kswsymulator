import { charge, RENT } from './finance';
import type { Attribute, CarId, Fighter, HousingId, Lifestyle } from './types';

export const TRANSPORT = 150;
export const DEFAULT_LIFESTYLE: Lifestyle = { housing: 'flat', car: 'none', gym: 0 };
export const lifestyleOf = (f: Fighter): Lifestyle => f.lifestyle ?? DEFAULT_LIFESTYLE;

export interface HousingInfo { label: string; monthly: number; price: number; recovery: number; desc: string }
/** `recovery`: dodatkowa dzienna regeneracja zmęczenia (może być ujemna). `price` > 0 = zakup na własność. */
export const HOUSING: Record<HousingId, HousingInfo> = {
  room: { label: 'Pokój w wynajmowanym mieszkaniu', monthly: 450, price: 0, recovery: -2, desc: 'Tanio, ale słaby sen. Zmęczenie spada wolniej.' },
  flat: { label: 'Wynajęte mieszkanie', monthly: RENT, price: 0, recovery: 0, desc: 'Standard.' },
  penthouse: { label: 'Apartament', monthly: 2400, price: 0, recovery: 3, desc: 'Spokój i komfort. Szybsza regeneracja.' },
  house: { label: 'Dom na własność', monthly: 700, price: 220000, recovery: 4, desc: 'Najlepsza regeneracja i niskie miesięczne koszty. Wysoka cena zakupu.' },
};
export interface CarInfo { label: string; price: number; upkeep: number; desc: string }
export const CARS: Record<CarId, CarInfo> = {
  none: { label: 'Brak auta', price: 0, upkeep: 0, desc: `Komunikacja miejska: ${TRANSPORT} zł miesięcznie i +2 zmęczenia po każdym treningu.` },
  used: { label: 'Używane auto', price: 22000, upkeep: 350, desc: 'Brak dojazdowego zmęczenia po treningach.' },
  sport: { label: 'Sportowe auto', price: 110000, upkeep: 1400, desc: 'Brak dojazdowego zmęczenia i +1 popularności miesięcznie (status).' },
};
export const GYMS = [
  { label: 'Brak domowej siłowni', price: 0, mult: 1, desc: '' },
  { label: 'Domowa siłownia', price: 7000, mult: 1.1, desc: 'Darmowe sesje siłowni, +10% do siły i wytrzymałości z tych sesji.' },
  { label: 'Profesjonalna siłownia domowa', price: 30000, mult: 1.25, desc: 'Darmowe sesje siłowni, +25% do siły i wytrzymałości z tych sesji.' },
] as const;

const SELL_HOUSE = 0.8, SELL_CAR = 0.6, MOVE_FEE = 300;

export const housingRecovery = (f: Fighter) => HOUSING[lifestyleOf(f).housing].recovery;
export const commuteFatigue = (f: Fighter) => (lifestyleOf(f).car === 'none' ? 2 : 0);
export const hasHomeGym = (f: Fighter) => lifestyleOf(f).gym > 0;
export function gymMultiplier(f: Fighter, a: Attribute): number {
  const g = lifestyleOf(f).gym;
  if (g === 0) return 1;
  return a === 'strength' || a === 'durability' ? GYMS[g].mult : 1;
}
export const carIsStatus = (f: Fighter) => lifestyleOf(f).car === 'sport';

export function netWorth(f: Fighter): number {
  const l = lifestyleOf(f);
  return Math.round(f.money + (l.housing === 'house' ? HOUSING.house.price * SELL_HOUSE : 0) + CARS[l.car].price * SELL_CAR + GYMS[l.gym].price * 0.5);
}

/** Zmiana miejsca zamieszkania. Dom kupuje się za gotówkę, przy wyprowadzce sprzedaje z 20% stratą. */
export function changeHousing(f: Fighter, id: HousingId): Fighter {
  const l = lifestyleOf(f);
  if (!HOUSING[id]) throw new Error('Nieznane mieszkanie.');
  if (l.housing === id) throw new Error('Już tu mieszkasz.');
  let next = f;
  if (l.housing === 'house') next = charge(next, 'Sprzedaż domu', Math.round(HOUSING.house.price * SELL_HOUSE));
  const cost = HOUSING[id].price + MOVE_FEE;
  if (next.money < cost) throw new Error('Brak środków na tę zmianę.');
  next = charge(next, id === 'house' ? 'Zakup domu' : 'Przeprowadzka', -cost);
  return { ...next, lifestyle: { ...l, housing: id } };
}

export function changeCar(f: Fighter, id: CarId): Fighter {
  const l = lifestyleOf(f);
  if (!CARS[id]) throw new Error('Nieznane auto.');
  if (l.car === id) throw new Error('Masz już to auto.');
  let next = f;
  if (l.car !== 'none') next = charge(next, 'Sprzedaż auta', Math.round(CARS[l.car].price * SELL_CAR));
  if (next.money < CARS[id].price) throw new Error('Brak środków na zakup auta.');
  if (CARS[id].price > 0) next = charge(next, 'Zakup auta', -CARS[id].price);
  return { ...next, lifestyle: { ...l, car: id } };
}

export function upgradeGym(f: Fighter): Fighter {
  const l = lifestyleOf(f);
  if (l.gym >= 2) throw new Error('Masz już najlepszą siłownię.');
  const next = (l.gym + 1) as 1 | 2;
  const price = GYMS[next].price;
  if (f.money < price) throw new Error('Brak środków na siłownię.');
  return { ...charge(f, GYMS[next].label, -price), lifestyle: { ...l, gym: next } };
}

export function changeLifestyle(f: Fighter, kind: string, id?: string): Fighter {
  if (f.activeFight) throw new Error('Trwa walka.');
  if (kind === 'housing') return changeHousing(f, id as HousingId);
  if (kind === 'car') return changeCar(f, id as CarId);
  if (kind === 'gym') return upgradeGym(f);
  throw new Error('Nieznany wybór.');
}

/** Miesięczne koszty: mieszkanie oraz auto albo komunikacja. */
export function monthlyLifestyle(f: Fighter): Fighter {
  const l = lifestyleOf(f);
  const h = HOUSING[l.housing];
  let n = charge(f, l.housing === 'house' ? 'Utrzymanie domu' : 'Czynsz', -h.monthly);
  n = l.car === 'none' ? charge(n, 'Komunikacja', -TRANSPORT) : charge(n, 'Utrzymanie auta', -CARS[l.car].upkeep);
  return n;
}
