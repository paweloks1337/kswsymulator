import { describe, expect, it } from 'vitest';
import {
  advanceDays, createFighter, effectiveness, fireStaff, generateOffers, generateWorld, hireStaff, staffMarket, trainDay, STAFF_ROLES,
  RENT, FOOD, TRANSPORT, START_MONEY, type Fighter, type FighterProfile, type StaffMember,
} from './index';

const prof: FighterProfile = {
  firstName: 'Jan', lastName: 'K', nickname: '', age: 25, nationality: 'Polska', heightCm: 180, weightKg: 77, reachCm: 183,
  dominantHand: 'right', style: 'boxing', experienceYears: 5,
  appearance: { face: 'Kanciasta', hair: 'Krótkie', beard: 'Brak', build: 'Atletyczna', tattoos: 'Brak', kit: 'Czerwony' },
};
const mk = (): Fighter => ({ ...createFighter(prof, 42), money: 20000 });
const member = (role: StaffMember['role'], skill = 80, cooperation = 100): StaffMember =>
  ({ id: `${role}-x`, name: 'T', role, skill, experience: 5, reputation: 60, salary: 900, cooperation });

describe('staff market and hiring', () => {
  it('is deterministic with 3 candidates per role', () => {
    const f = mk();
    expect(staffMarket(f)).toEqual(staffMarket(f));
    expect(staffMarket(f).length).toBe(STAFF_ROLES.length * 3);
  });
  it('hiring pays a signing fee, adds the member and removes them from the market', () => {
    const f = mk(); const c = staffMarket(f).find((x) => x.role === 'boxing')!;
    const n = hireStaff(f, c.id);
    expect(n.money).toBe(f.money - c.salary);
    expect(n.staff.length).toBe(1);
    expect(staffMarket(n).some((x) => x.id === c.id)).toBe(false);
  });
  it('allows one person per role and requires funds', () => {
    const f = mk(); const [a, b] = staffMarket(f).filter((x) => x.role === 'bjj');
    const n = hireStaff(f, a!.id);
    expect(() => hireStaff(n, b!.id)).toThrow();
    expect(() => hireStaff({ ...f, money: 1 }, a!.id)).toThrow();
  });
  it('firing removes the member', () => {
    const f = mk(); const n = hireStaff(f, staffMarket(f)[0]!.id);
    expect(fireStaff(n, n.staff[0]!.id).staff.length).toBe(0);
  });
});

describe('staff effects', () => {
  const gain = (f: Fighter, id: string, a: 'boxing' | 'wrestling') => { const r = trainDay(f, id, 1); if (!r.ok) throw new Error(r.reason); return r.fighter.stats[a] - f.stats[a]; };
  it('a matching coach speeds up development, a non-matching one does not', () => {
    const f = mk();
    const withCoach = { ...f, staff: [member('boxing')] };
    expect(gain(withCoach, 'boxing', 'boxing')).toBeGreaterThan(gain(f, 'boxing', 'boxing'));
    expect(gain({ ...f, staff: [member('wrestling')] }, 'boxing', 'boxing')).toBeCloseTo(gain(f, 'boxing', 'boxing'), 5);
  });
  it('weak cooperation lowers effectiveness', () => expect(effectiveness(member('boxing', 80, 0))).toBeLessThan(effectiveness(member('boxing', 80, 100))));
  it('a fitness coach reduces training fatigue', () => {
    const f = mk(); const a = trainDay(f, 'gym', 1), b = trainDay({ ...f, staff: [member('fitness')] }, 'gym', 1);
    if (!a.ok || !b.ok) throw new Error('x');
    expect(b.fighter.condition.fatigue).toBeLessThan(a.fighter.condition.fatigue);
  });
  it('a physio heals injuries faster', () => {
    const f = { ...mk(), injuries: [{ area: 'knee' as const, severity: 2 as const, daysLeft: 21 }] };
    const slow = advanceDays(f, 10).injuries[0]!.daysLeft;
    const fast = advanceDays({ ...f, staff: [member("physio")] }, 10).injuries[0]!.daysLeft;
    expect(fast).toBeLessThan(slow);
  });
  it('a manager raises offered purses', () => {
    const f = mk(); const w = generateWorld(1); void w;
    const plain = generateOffers(f)[0]!.purse, boosted = generateOffers({ ...f, staff: [member('manager')] })[0]!.purse;
    expect(boosted).toBeGreaterThan(plain);
  });
  it('salaries are paid monthly and cooperation grows', () => {
    const f = { ...mk(), money: START_MONEY, staff: [member('boxing', 80, 20)] };
    const n = advanceDays(f, 28); // -> 1 lutego
    expect(n.money).toBe(START_MONEY - RENT - FOOD - TRANSPORT - 900);
    expect(n.staff[0]!.cooperation).toBe(23);
  });
});
