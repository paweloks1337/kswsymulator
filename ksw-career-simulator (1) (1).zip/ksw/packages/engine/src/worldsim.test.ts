import { describe, expect, it } from 'vitest';
import { FEDERATIONS, WEIGHT_CLASSES, generateWorld, overallRating, rankings, simulateWorld, START_DATE, createFighter, type FighterProfile } from './index';

const prof: FighterProfile = {
  firstName: 'Jan', lastName: 'K', nickname: '', age: 25, nationality: 'Polska', heightCm: 180, weightKg: 77, reachCm: 183,
  dominantHand: 'right', style: 'mma', experienceYears: 5,
  appearance: { face: 'Kanciasta', hair: 'Krótkie', beard: 'Brak', build: 'Atletyczna', tattoos: 'Brak', kit: 'Czerwony' },
};
const w0 = generateWorld(21);
const avgRating = (w: typeof w0, pick: (n: typeof w0.npcs[0]) => boolean) => {
  const l = w.npcs.filter(pick); return l.reduce((s, n) => s + overallRating(n.stats), 0) / l.length;
};

describe('living world', () => {
  const w1 = simulateWorld(w0, 366, 5);
  it('is deterministic and tracks the date', () => {
    expect(simulateWorld(w0, 366, 5)).toEqual(w1);
    expect(w0.date).toBe(START_DATE);
    expect(w1.date).toBe('2028-01-05');
  });
  it('keeps every division full with unique ids', () => {
    for (const fed of FEDERATIONS) for (const wc of WEIGHT_CLASSES)
      expect(w1.npcs.filter((n) => n.federationId === fed.id && n.weightClassId === wc.id).length).toBe(8);
    expect(new Set(w1.npcs.map((n) => n.id)).size).toBe(w1.npcs.length);
  });
  it('ages fighters and retires veterans, replacing them with newcomers', () => {
    const ids = new Set(w0.npcs.map((n) => n.id));
    expect(w1.npcs.some((n) => !ids.has(n.id))).toBe(true);
    expect((w1.news ?? []).some((x) => x.text.includes('kończy karierę'))).toBe(true);
    const survivor = w1.npcs.find((n) => ids.has(n.id))!;
    expect(survivor.age).toBe(w0.npcs.find((n) => n.id === survivor.id)!.age + 1);
  });
  it('young fighters improve and old ones decline', () => {
    const w = simulateWorld({ ...w0, npcs: w0.npcs.map((n) => ({ ...n, age: n.age <= 24 ? n.age : n.age })) }, 90, 3);
    const young = (n: { age: number }) => n.age <= 24, old = (n: { age: number }) => n.age >= 33;
    const keep = new Set(w0.npcs.map((n) => n.id));
    const sub = (ws: typeof w0, f: (n: typeof w0.npcs[0]) => boolean) => ws.npcs.filter((n) => keep.has(n.id) && f(n));
    const before = (f: (n: { age: number }) => boolean) => w0.npcs.filter((n) => f(n) && sub(w, (x) => x.id === n.id).length);
    const yb = before(young), ob = before(old);
    const yAfter = yb.map((n) => overallRating(w.npcs.find((x) => x.id === n.id)!.stats));
    const oAfter = ob.map((n) => overallRating(w.npcs.find((x) => x.id === n.id)!.stats));
    const mean = (a: number[]) => a.reduce((s, v) => s + v, 0) / a.length;
    expect(mean(yAfter)).toBeGreaterThan(mean(yb.map((n) => overallRating(n.stats))) - 0.0001);
    expect(mean(oAfter)).toBeLessThan(mean(ob.map((n) => overallRating(n.stats))));
  });
  it('crowns champions from their own division and reports title changes', () => {
    const titles = w1.titles ?? {};
    expect(Object.keys(titles).length).toBeGreaterThan(0);
    for (const [key, t] of Object.entries(titles)) {
      const [fed, cls] = key.split(':');
      const n = w1.npcs.find((x) => x.id === t.holderId)!;
      expect(n.federationId).toBe(fed); expect(n.weightClassId).toBe(cls);
    }
    expect((w1.news ?? []).some((x) => x.text.includes('mistrzem'))).toBe(true);
  });
  it('moves fighters between federations over the years', () => {
    const w3 = simulateWorld(w0, 366 * 3, 8);
    const moved = w3.npcs.filter((n) => { const o = w0.npcs.find((x) => x.id === n.id); return o && o.federationId !== n.federationId; });
    expect(moved.length).toBeGreaterThan(0);
  });
  it('never removes or moves protected fighters', () => {
    const protectedIds = w0.npcs.filter((n) => n.age >= 33).slice(0, 6).map((n) => n.id);
    const w3 = simulateWorld(w0, 366 * 3, 8, { protect: protectedIds });
    for (const id of protectedIds) {
      const o = w0.npcs.find((n) => n.id === id)!, n = w3.npcs.find((x) => x.id === id);
      expect(n).toBeTruthy(); expect(n!.federationId).toBe(o.federationId);
    }
  });
  it('works on old saves without a world date', () => {
    const old = { ...w0, date: undefined, news: undefined, titles: undefined };
    expect(simulateWorld(old, 40, 1, { fromDate: '2027-03-01' }).date).toBe('2027-04-10');
  });
  it('rankings flag the champion', () => {
    const f = createFighter(prof, 1);
    const key = Object.keys(w1.titles ?? {})[0]!; const [fed, cls] = key.split(':');
    expect(rankings(w1, f, fed!, cls!).some((r) => r.champion)).toBe(true);
  });
});
