import { charge } from './finance';
import { mulberry32 } from './fighter';
import type { Attribute, Fighter, StaffMember, StaffRole } from './types';

export const STAFF_ROLES: StaffRole[] = ['head', 'boxing', 'wrestling', 'bjj', 'fitness', 'physio', 'manager'];
export const ROLE_LABELS: Record<StaffRole, string> = {
  head: 'Trener główny', boxing: 'Trener boksu', wrestling: 'Trener zapasów', bjj: 'Trener BJJ',
  fitness: 'Trener przygotowania fizycznego', physio: 'Fizjoterapeuta', manager: 'Menedżer',
};
export const ROLE_EFFECT: Record<StaffRole, string> = {
  head: 'Przyspiesza rozwój wszystkich umiejętności walki i inteligencji walki',
  boxing: 'Przyspiesza rozwój boksu, kickboxingu, Muay Thai i precyzji',
  wrestling: 'Przyspiesza rozwój zapasów, siły i obrony',
  bjj: 'Przyspiesza rozwój BJJ i inteligencji walki',
  fitness: 'Przyspiesza siłę, kondycję, szybkość i wytrzymałość oraz zmniejsza zmęczenie po treningu',
  physio: 'Skraca leczenie kontuzji i zmniejsza ryzyko kontuzji treningowych',
  manager: 'Podnosi gaże w ofertach kontraktów',
};
const FOCUS: Partial<Record<StaffRole, Attribute[]>> = {
  boxing: ['boxing', 'kickboxing', 'muaythai', 'precision'],
  wrestling: ['wrestling', 'strength', 'defense'],
  bjj: ['bjj', 'fightIQ'],
  fitness: ['strength', 'cardio', 'speed', 'durability'],
};
const HEAD_FOCUS: Attribute[] = ['boxing', 'kickboxing', 'muaythai', 'wrestling', 'bjj', 'fightIQ'];

const FIRST = ['Andrzej', 'Wojciech', 'Krzysztof', 'Marcin', 'Jacek', 'Paweł', 'Michał', 'Robert', 'Łukasz', 'Grzegorz', 'Anna', 'Ewa'];
const LAST = ['Lis', 'Gołąb', 'Kamiński', 'Jabłoński', 'Sowa', 'Malinowski', 'Dąbrowski', 'Pawlak', 'Zawisza', 'Kozioł', 'Rudy', 'Szymański'];

export type StaffCandidate = Omit<StaffMember, 'cooperation'>;

export const staffOf = (f: Fighter): StaffMember[] => f.staff ?? [];
export const salaryFor = (skill: number) => Math.round((150 + skill * skill * 0.12) / 10) * 10;
/** Skuteczność: umiejętność, zmniejszona gdy współpraca jest jeszcze słaba. */
export const effectiveness = (m: StaffMember) => (m.skill / 100) * (0.6 + 0.4 * m.cooperation / 100);
const eff = (f: Fighter, role: StaffRole) => { const m = staffOf(f).find((s) => s.role === role); return m ? effectiveness(m) : 0; };

export function gainMultiplier(f: Fighter, a: Attribute): number {
  let bonus = 0;
  for (const m of staffOf(f)) {
    if (m.role === 'head') { if (HEAD_FOCUS.includes(a)) bonus += effectiveness(m) * 0.15; }
    else if (FOCUS[m.role]?.includes(a)) bonus += effectiveness(m) * 0.35;
  }
  return 1 + Math.min(0.6, bonus);
}
export const fatigueMultiplier = (f: Fighter) => 1 - 0.2 * eff(f, 'fitness');
export const injuryRiskMultiplier = (f: Fighter) => 1 - 0.35 * eff(f, 'physio');
export const purseMultiplier = (f: Fighter) => 1 + 0.2 * eff(f, 'manager');

/** Dodatkowe dni leczenia kontuzji w danym dniu (fizjoterapeuta). */
export function healBonusDay(f: Fighter, isoDate: string): number {
  const e = eff(f, 'physio');
  const period = e >= 0.7 ? 2 : e >= 0.35 ? 3 : 0;
  const day = Math.floor(Date.parse(`${isoDate}T00:00:00Z`) / 86400000);
  return period && day % period === 0 ? 1 : 0;
}

/** Rynek pracy: stała pula 3 kandydatów na każde stanowisko, zależna od zawodnika. */
export function staffMarket(f: Fighter): StaffCandidate[] {
  let h = 2166136261;
  for (const c of f.id) { h ^= c.charCodeAt(0); h = Math.imul(h, 16777619); }
  const rng = mulberry32(h >>> 0);
  const hired = new Set(staffOf(f).map((s) => s.id));
  const out: StaffCandidate[] = [];
  for (const role of STAFF_ROLES) for (let k = 0; k < 3; k++) {
    const skill = Math.round(35 + rng() * 50);
    out.push({
      id: `${role}-${k}`, role, skill, experience: Math.floor(skill / 8 + rng() * 5),
      reputation: Math.min(100, Math.max(1, Math.round(skill + rng() * 20 - 10))),
      salary: salaryFor(skill),
      name: `${FIRST[Math.floor(rng() * FIRST.length)]} ${LAST[Math.floor(rng() * LAST.length)]}`,
    });
  }
  return out.filter((c) => !hired.has(c.id));
}

export function hireStaff(f: Fighter, candidateId: string): Fighter {
  const c = staffMarket(f).find((x) => x.id === candidateId);
  if (!c) throw new Error('Ten kandydat jest niedostępny.');
  if (staffOf(f).some((s) => s.role === c.role)) throw new Error(`Masz już: ${ROLE_LABELS[c.role].toLowerCase()}. Najpierw go zwolnij.`);
  if (f.money < c.salary) throw new Error('Brak środków na opłatę za podpisanie (równowartość miesięcznej pensji).');
  const next = charge(f, `Zatrudnienie: ${c.name}`, -c.salary);
  return { ...next, staff: [...staffOf(f), { ...c, cooperation: 20 }] };
}

export function fireStaff(f: Fighter, staffId: string): Fighter {
  if (!staffOf(f).some((s) => s.id === staffId)) throw new Error('Nie ma takiego pracownika.');
  return { ...f, staff: staffOf(f).filter((s) => s.id !== staffId) };
}
