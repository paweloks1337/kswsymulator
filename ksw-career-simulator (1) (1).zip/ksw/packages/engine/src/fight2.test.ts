import { describe, expect, it } from 'vitest';
import {
  acceptOffer, adviseTactics, beginFight, computeStartingStats, createFighter, defaultTactics, fightRound, generateWorld,
  simulateFight, simulateRound, startFight, type Combatant, type FighterProfile, type Tactics,
} from './index';

const prof: FighterProfile = {
  firstName: 'Jan', lastName: 'K', nickname: '', age: 25, nationality: 'Polska', heightCm: 180, weightKg: 77, reachCm: 183,
  dominantHand: 'right', style: 'mma', experienceYears: 5,
  appearance: { face: 'Kanciasta', hair: 'Krótkie', beard: 'Brak', build: 'Atletyczna', tattoos: 'Brak', kit: 'Czerwony' },
};
const stats = computeStartingStats(prof);
const c = (name: string): Combatant => ({ name, stats, fatigue: 0, health: 100, aggression: 0.5 });
const bal: Tactics = { aggression: 0.5, focus: 'balanced' };

describe('round-by-round fight', () => {
  it('stepwise play with default tactics equals simulateFight', () => {
    for (let seed = 1; seed <= 20; seed++) {
      let s = startFight(c('A'), c('B'), seed);
      while (!s.result) s = simulateRound(s, [defaultTactics(c('A')), defaultTactics(c('B'))]);
      expect(s.result).toEqual(simulateFight(c('A'), c('B'), seed));
    }
  });
  it('does not mutate the previous state and survives JSON round-trip', () => {
    const s0 = startFight(c('A'), c('B'), 3);
    const s1 = simulateRound(s0, [bal, bal]);
    expect(s0.nextRound).toBe(1);
    if (s1.result) return;
    const revived = JSON.parse(JSON.stringify(s1));
    expect(simulateRound(revived, [bal, bal])).toEqual(simulateRound(s1, [bal, bal]));
  });
  it('records a summary per round', () => {
    let s = startFight(c('A'), c('B'), 5);
    s = simulateRound(s, [bal, bal]);
    expect(s.rounds.length).toBe(1);
    expect(s.rounds[0]!.round).toBe(1);
  });
});

describe('tactics have real effects', () => {
  const avg = (focus: Tactics['focus'], pick: (s: ReturnType<typeof simulateRound>) => number) => {
    let sum = 0, n = 0;
    for (let seed = 1; seed <= 150; seed++) {
      const s = simulateRound(startFight(c('A'), c('B'), seed), [{ aggression: 0.5, focus }, bal]);
      sum += pick(s); n++;
    }
    return sum / n;
  };
  it('takedown focus produces more takedown attempts', () => {
    const f = (s: ReturnType<typeof simulateRound>) => s.stats[0].takedownsTried;
    expect(avg('takedown', f)).toBeGreaterThan(avg('balanced', f));
  });
  it('distance focus produces fewer takedown attempts', () => {
    const f = (s: ReturnType<typeof simulateRound>) => s.stats[0].takedownsTried;
    expect(avg('distance', f)).toBeLessThan(avg('balanced', f));
  });
  it('conserve focus keeps more stamina, pressure burns more', () => {
    const f = (s: ReturnType<typeof simulateRound>) => s.stamina[0];
    expect(avg('conserve', f)).toBeGreaterThan(avg('balanced', f));
    expect(avg('pressure', f)).toBeLessThan(avg('balanced', f));
  });
  it('pressure focus throws more strikes', () => {
    const f = (s: ReturnType<typeof simulateRound>) => s.stats[0].strikesThrown;
    expect(avg('pressure', f)).toBeGreaterThan(avg('conserve', f));
  });
});

describe('corner advice', () => {
  it('tells an exhausted fighter to conserve energy', () => {
    let s = startFight(c('A'), c('B'), 2);
    s = simulateRound(s, [bal, bal]);
    s.rounds[0]!.staminaPct = [20, 70];
    expect(adviseTactics(s, 0).focus).toBe('conserve');
  });
  it('tells a fighter who is being taken down to keep distance', () => {
    let s = startFight(c('A'), c('B'), 2);
    s = simulateRound(s, [bal, bal]);
    s.rounds[0]!.staminaPct = [80, 80]; s.rounds[0]!.stats[1].tdOk = 3;
    expect(adviseTactics(s, 0).focus).toBe('distance');
  });
});

describe('interactive fight flow on the career', () => {
  const w = generateWorld(4);
  const ready = () => { let f = acceptOffer(createFighter(prof, 42), w, 'arena', 1); f = { ...f, gameDate: f.nextFight!.date }; return f; };
  it('plays round by round and settles once at the end', () => {
    let f = ready(); let r = beginFight(f, w, bal, 11);
    expect(r.frames.every((x) => x.round === 1)).toBe(true);
    let guard = 0;
    while (!r.result && guard++ < 5) {
      expect(r.fighter.activeFight).toBeTruthy();
      expect(r.fighter.record.wins + r.fighter.record.losses + r.fighter.record.draws).toBe(0);
      r = fightRound(r.fighter, r.world, { aggression: 0.6, focus: 'pressure' }, 12 + guard);
    }
    expect(r.result).toBeTruthy();
    const n = r.fighter;
    expect(n.activeFight).toBeNull();
    expect(n.record.wins + n.record.losses + n.record.draws).toBe(1);
    expect(n.history.length).toBe(1);
    expect(n.history[0]!.round).toBe(r.result!.round);
    expect(n.contract?.fightsLeft).toBe(2);
  });
  it('refuses to start a second fight and to fight early', () => {
    const f = ready(); const r = beginFight(f, w, bal, 3);
    if (!r.result) expect(() => beginFight(r.fighter, r.world, bal, 3)).toThrow();
    expect(() => beginFight(acceptOffer(createFighter(prof, 42), w, 'arena', 1), w, bal, 3)).toThrow();
  });
});
