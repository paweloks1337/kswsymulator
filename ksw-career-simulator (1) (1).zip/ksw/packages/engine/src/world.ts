import { addDays, advanceDay, daysToFight } from './calendar';
import { charge, TAX_RATE } from './finance';
import {
  combatantFrom, opponentTactics, simulateFight, simulateRound, startFight,
  type Combatant, type FightFrame, type FightResult, type RoundSummary, type Tactics,
} from './fight';
import { purseMultiplier } from './staff';
import { applyFightMedia, mediaOf } from './media';
import { computeStartingStats, mulberry32, overallRating, START_DATE, WEIGHT_CLASSES } from './fighter';
import { STYLES, type Attribute, type Contract, type Federation, type Fighter, type Injury, type InjuryArea, type Npc, type WeightClass, type World } from './types';

export const FEDERATIONS: Federation[] = [
  { id: 'arena', name: 'Arena Fight Series', prestige: 1, purseBase: 2200, minWins: 0, minRating: 0 },
  { id: 'ironcage', name: 'Iron Cage MMA', prestige: 2, purseBase: 4500, minWins: 2, minRating: 40 },
  { id: 'apex', name: 'Apex Championship', prestige: 3, purseBase: 11000, minWins: 6, minRating: 47 },
];
const FIRST = ['Marek', 'Tomasz', 'Kamil', 'Damian', 'Piotr', 'Adrian', 'Bartek', 'Oskar', 'Igor', 'Rafał', 'Dawid', 'Szymon'];
const LAST = ['Wrona', 'Kruk', 'Stal', 'Burza', 'Wilk', 'Nowicki', 'Zając', 'Kowal', 'Bielak', 'Orzeł', 'Sokół', 'Mazur'];
const NPC_PER_CLASS = 8;
/** Obóz przygotowawczy: im wyższa federacja, tym rzadsze i lepiej przygotowane gale (ok. 4-6 walk rocznie). */
export const FIGHT_LEAD_DAYS: Record<string, number> = { arena: 56, ironcage: 70, apex: 84 };

export const rankScore = (r: { wins: number; losses: number; draws: number }, rating: number) =>
  r.wins * 3 - r.losses * 2 + r.draws + rating * 0.2;

function makeNpc(rng: () => number, id: string, fed: Federation, wc: WeightClass, young = false): Npc {
  const age = young ? 20 + Math.floor(rng() * 4) : 21 + Math.floor(rng() * 14);
  const style = STYLES[Math.floor(rng() * STYLES.length)]!;
  const stats = computeStartingStats({
    firstName: '', lastName: '', nickname: '', age, nationality: 'Polska', heightCm: 180, weightKg: wc.maxKg - 2, reachCm: 182,
    dominantHand: 'right', style, experienceYears: Math.min(age - 14, young ? 2 + Math.floor(rng() * 3) : 3 + fed.prestige * 3 + Math.floor(rng() * 4)),
    appearance: { face: 'Kanciasta', hair: 'Krótkie', beard: 'Brak', build: 'Atletyczna', tattoos: 'Brak', kit: 'Czarny' },
  });
  const boost = (young ? 2 : fed.prestige * 4) + Math.floor(rng() * 8) - 4;
  for (const k of Object.keys(stats) as (keyof typeof stats)[]) stats[k] = Math.min(100, Math.max(1, stats[k] + boost));
  const rating = Math.round(Object.values(stats).reduce((s, v) => s + v, 0) / Object.values(stats).length);
  return {
    id, name: `${FIRST[Math.floor(rng() * FIRST.length)]} ${LAST[Math.floor(rng() * LAST.length)]}`,
    age, weightClassId: wc.id, federationId: fed.id, stats,
    record: young ? { wins: 0, losses: 0, draws: 0 } : { wins: Math.floor(rng() * (fed.prestige * 4 + 3)), losses: Math.floor(rng() * 6), draws: 0 },
    potential: Math.min(99, rating + 4 + Math.floor(rng() * (young ? 22 : 10))),
  };
}

export function generateWorld(seed: number): World {
  const rng = mulberry32(seed);
  const npcs: Npc[] = [];
  let n = 0;
  for (const fed of FEDERATIONS) for (const wc of WEIGHT_CLASSES) for (let i = 0; i < NPC_PER_CLASS; i++) npcs.push(makeNpc(rng, `npc-${n++}`, fed, wc));
  return { federations: FEDERATIONS, npcs, date: START_DATE, news: [], titles: {} };
}

export interface RankEntry { id: string; name: string; wins: number; losses: number; draws: number; score: number; isPlayer: boolean; rank: number; champion: boolean }

export function rankings(world: World, f: Fighter, federationId: string, classId: string): RankEntry[] {
  const rows = world.npcs.filter((n) => n.federationId === federationId && n.weightClassId === classId)
    .map((n) => ({ id: n.id, name: n.name, ...n.record, score: rankScore(n.record, overallRating(n.stats)), isPlayer: false, champion: world.titles?.[`${federationId}:${classId}`]?.holderId === n.id }));
  const fought = f.history.filter((h) => h.federationId === federationId);
  if (f.weightClass.id === classId && (f.contract?.federationId === federationId || fought.length)) {
    const rec = fought.reduce((r, h) => ({ wins: r.wins + (h.result === 'W' ? 1 : 0), losses: r.losses + (h.result === 'L' ? 1 : 0), draws: r.draws + (h.result === 'D' ? 1 : 0) }), { wins: 0, losses: 0, draws: 0 });
    rows.push({ id: f.id, name: `${f.profile.firstName} ${f.profile.lastName}`, ...rec, score: rankScore(rec, overallRating(f.stats)), isPlayer: true, champion: false });
  }
  return rows.sort((a, b) => b.score - a.score).map((r, i) => ({ ...r, rank: i + 1 }));
}

export interface Offer extends Omit<Contract, 'fightsLeft'> { fights: number }

export function generateOffers(f: Fighter): Offer[] {
  if (f.contract) return [];
  const rating = overallRating(f.stats);
  return FEDERATIONS.filter((fed) => f.record.wins >= fed.minWins && rating >= fed.minRating).map((fed) => {
    const purse = Math.round((fed.purseBase * (0.8 + rating / 100) * purseMultiplier(f) * (1 + mediaOf(f).popularity * 0.004)) / 100) * 100;
    return { federationId: fed.id, fights: 3, purse, winBonus: purse, koBonus: Math.round(purse * 0.25), subBonus: Math.round(purse * 0.25) };
  });
}

function pickOpponent(f: Fighter, world: World, federationId: string, seed: number): Npc {
  const rating = overallRating(f.stats);
  const all = world.npcs.filter((n) => n.federationId === federationId && n.weightClassId === f.weightClass.id);
  const pool = (all.some((n) => !n.injuredDays) ? all.filter((n) => !n.injuredDays) : all)
    .sort((a, b) => Math.abs(overallRating(a.stats) - rating) - Math.abs(overallRating(b.stats) - rating)).slice(0, 3);
  return pool[Math.floor(mulberry32(seed)() * pool.length)]!;
}

function schedule(f: Fighter, world: World, seed: number): Fighter {
  const c = f.contract!;
  const opp = pickOpponent(f, world, c.federationId, seed);
  return { ...f, nextFight: { date: addDays(f.gameDate, FIGHT_LEAD_DAYS[c.federationId] ?? 56), opponentId: opp.id, federationId: c.federationId } };
}

export function acceptOffer(f: Fighter, world: World, federationId: string, seed: number): Fighter {
  if (f.contract) throw new Error('Masz już aktywny kontrakt.');
  const o = generateOffers(f).find((x) => x.federationId === federationId);
  if (!o) throw new Error('Ta oferta jest niedostępna.');
  const { fights, ...terms } = o;
  return schedule({ ...f, contract: { ...terms, fightsLeft: fights } }, world, seed);
}

const npcCombatant = (n: Npc): Combatant => ({ name: n.name, stats: n.stats, fatigue: 0, health: 100, aggression: 0.5 });

function checkFightDay(f: Fighter, world: World) {
  const nf = f.nextFight, c = f.contract;
  if (!nf || !c) throw new Error('Brak zaplanowanej walki.');
  if ((daysToFight(f) ?? 1) > 0) throw new Error('To jeszcze nie dzień walki.');
  const opp = world.npcs.find((n) => n.id === nf.opponentId);
  if (!opp) throw new Error('Nie znaleziono rywala.');
  return { nf, c, opp };
}

/** Skutki walki: gaża i premie, podatek, kontuzje, rekord, historia, kontrakt, następna walka, rekord rywala. */
function finalizeFight(f: Fighter, world: World, result: FightResult, seed: number) {
  const { nf, c, opp } = checkFightDay(f, world);
  const rng = mulberry32(seed ^ 0x9e3779b9);
  const won = result.winner === 0, lost = result.winner === 1;

  let gross = c.purse;
  if (won) gross += c.winBonus + (result.method === 'KO' || result.method === 'TKO' ? c.koBonus : 0) + (result.method === 'SUB' ? c.subBonus : 0);
  const tax = Math.round(gross * TAX_RATE);
  let next = charge(charge(f, 'Gala: wynagrodzenie i premie', gross), 'Podatek', -tax);

  const ratio = result.stats[1].damage / 150;
  let injury: Injury | undefined;
  if (rng() < Math.min(0.9, ratio)) {
    const areas: InjuryArea[] = ['head', 'ribs', 'hand', 'knee'];
    const severity: Injury['severity'] = ratio > 0.7 ? 3 : ratio > 0.4 ? 2 : 1;
    injury = { area: areas[Math.floor(rng() * areas.length)]!, severity, daysLeft: [0, 7, 21, 56][severity]! };
  }
  next = applyFightMedia(next, { won, lost, finish: won && ['KO', 'TKO', 'SUB'].includes(result.method) }, nf.hype ?? 0);
  const cond = next.condition;
  next = {
    ...next,
    record: { wins: f.record.wins + (won ? 1 : 0), losses: f.record.losses + (lost ? 1 : 0), draws: f.record.draws + (result.winner === null ? 1 : 0) },
    injuries: injury ? [...next.injuries, injury] : next.injuries,
    condition: { ...cond, fatigue: 60, health: Math.max(0, cond.health - Math.round(ratio * 40)), confidence: Math.min(100, Math.max(0, cond.confidence + (won ? 8 : lost ? -8 : 0))) },
    history: [...f.history, { date: f.gameDate, opponent: opp.name, result: won ? 'W' as const : lost ? 'L' as const : 'D' as const, method: result.method, round: result.round, federationId: nf.federationId }],
    contract: c.fightsLeft > 1 ? { ...c, fightsLeft: c.fightsLeft - 1 } : null,
    nextFight: null,
    activeFight: null,
  };
  next = advanceDay(next);
  if (next.contract) next = schedule(next, world, seed + 1);
  const npcs = world.npcs.map((n) => n.id !== opp.id ? n : { ...n, record: {
    wins: n.record.wins + (lost ? 1 : 0), losses: n.record.losses + (won ? 1 : 0), draws: n.record.draws + (result.winner === null ? 1 : 0) } });
  return { fighter: next, world: { ...world, npcs }, result, injury };
}

/** Automatyczna walka od początku do końca (bez decyzji gracza). */
export function resolveFight(f: Fighter, world: World, aggression: number, seed: number) {
  const { opp } = checkFightDay(f, world);
  const result = simulateFight(combatantFrom(f, Math.min(1, Math.max(0, aggression))), npcCombatant(opp), seed);
  return finalizeFight(f, world, result, seed);
}

export interface RoundOutcome {
  fighter: Fighter; world: World; summary: RoundSummary; frames: FightFrame[];
  result?: FightResult; injury?: Injury;
}

/** Rozpoczyna walkę interaktywną i od razu rozgrywa pierwszą rundę z podanymi taktykami. */
export function beginFight(f: Fighter, world: World, tactics: Tactics, seed: number): RoundOutcome {
  if (f.activeFight) throw new Error('Walka już trwa.');
  const { nf, opp } = checkFightDay(f, world);
  const state = startFight(combatantFrom(f, tactics.aggression), npcCombatant(opp), seed);
  return fightRound({ ...f, activeFight: { state, opponentId: nf.opponentId } }, world, tactics, seed);
}

/** Kolejna runda z taktyką wybraną przez gracza. Po ostatniej rundzie (lub zakończeniu) rozlicza walkę. */
export function fightRound(f: Fighter, world: World, tactics: Tactics, seed: number): RoundOutcome {
  const af = f.activeFight;
  if (!af) throw new Error('Nie ma walki w toku.');
  const t: Tactics = { aggression: Math.min(1, Math.max(0, tactics.aggression)), focus: tactics.focus };
  const state = simulateRound(af.state, [t, opponentTactics(af.state)]);
  const summary = state.rounds[state.rounds.length - 1]!;
  const frames = state.timeline.filter((x) => x.round === summary.round);
  if (state.result) {
    const done = finalizeFight(f, world, state.result, seed);
    return { fighter: done.fighter, world: done.world, summary, frames, result: done.result, injury: done.injury };
  }
  return { fighter: { ...f, activeFight: { ...af, state } }, world, summary, frames };
}

const PHYSICAL: Attribute[] = ['strength', 'speed', 'cardio', 'durability', 'reflex'];
const ratingOf = (n: Npc) => overallRating(n.stats);
const scoreOf = (n: Npc) => rankScore(n.record, ratingOf(n));
const classOf = (id: string) => WEIGHT_CLASSES.find((c) => c.id === id)!;

export interface WorldSimOptions {
  /** Data startowa, gdy świat jeszcze jej nie zna (stare zapisy). */
  fromDate?: string;
  /** Zawodnicy, którzy nie mogą odejść ani zmienić federacji (np. zaplanowany rywal gracza). */
  protect?: string[];
}

/**
 * Świat żyje bez udziału gracza. Codziennie: walki NPC i kontuzje. Co miesiąc: rozwój/spadek formy, awanse i spadki
 * między federacjami, walki o tytuły. Co rok: starzenie, kończenie karier, nowe talenty.
 */
export function simulateWorld(world: World, days: number, seed: number, opts: WorldSimOptions = {}): World {
  const rng = mulberry32(seed);
  const protect = new Set(opts.protect ?? []);
  const npcs = world.npcs.map((n) => ({ ...n, stats: { ...n.stats }, record: { ...n.record } }));
  const news = [...(world.news ?? [])];
  const titles = { ...(world.titles ?? {}) };
  let date = world.date ?? opts.fromDate ?? START_DATE;
  let nextId = npcs.reduce((m, n) => Math.max(m, Number(n.id.replace('npc-', '')) || 0), 0) + 1;
  const say = (text: string) => news.push({ date, text });
  const fedName = (id: string) => FEDERATIONS.find((x) => x.id === id)?.name ?? id;
  const fightResult = (a: Npc, b: Npc) => {
    const r = simulateFight(npcCombatant(a), npcCombatant(b), Math.floor(rng() * 2 ** 32));
    if (r.winner === null) { a.record.draws++; b.record.draws++; return null; }
    const [w, l] = r.winner === 0 ? [a, b] : [b, a];
    w.record.wins++; l.record.losses++;
    if (rng() < 0.25) l.injuredDays = 14 + Math.floor(rng() * 30);
    return w;
  };

  function fill(fedId: string, classId: string) {
    const fed = FEDERATIONS.find((x) => x.id === fedId)!;
    const lower = FEDERATIONS.find((x) => x.prestige === fed.prestige - 1);
    const cand = lower ? npcs.filter((n) => n.federationId === lower.id && n.weightClassId === classId && !protect.has(n.id) && !n.injuredDays)
      .sort((a, b) => scoreOf(b) - scoreOf(a))[0] : undefined;
    if (!lower || !cand) { npcs.push(makeNpc(rng, `npc-${nextId++}`, fed, classOf(classId), true)); return; }
    cand.federationId = fed.id;
    say(`${cand.name} awansuje do ${fedName(fed.id)} (${classOf(classId).name}).`);
    fill(lower.id, classId);
  }

  const yearly = () => {
    for (const n of npcs) n.age++;
    for (const n of [...npcs]) {
      if (protect.has(n.id) || n.age < 34) continue;
      const p = Math.min(0.9, (n.age - 33) * 0.18 + (n.record.losses > n.record.wins + 4 ? 0.2 : 0));
      if (rng() >= p) continue;
      npcs.splice(npcs.indexOf(n), 1);
      for (const k of Object.keys(titles)) if (titles[k]!.holderId === n.id) delete titles[k];
      say(`${n.name} (${n.age}) kończy karierę. Rekord ${n.record.wins}-${n.record.losses}-${n.record.draws}.`);
      fill(n.federationId, n.weightClassId);
    }
  };

  const monthly = () => {
    for (const n of npcs) {
      const pot = n.potential ?? 70, below = ratingOf(n) < pot;
      for (const a of Object.keys(n.stats) as Attribute[]) {
        const phys = PHYSICAL.includes(a);
        const d = phys ? (n.age <= 26 ? 0.4 : n.age <= 30 ? 0.05 : n.age <= 34 ? -0.3 : -0.7) : (n.age <= 29 ? 0.25 : n.age <= 33 ? 0 : -0.15);
        if (d > 0 && !below) continue;
        n.stats[a] = Math.min(100, Math.max(1, Math.round((n.stats[a] + d) * 100) / 100));
      }
    }
    // awanse i spadki między sąsiednimi federacjami
    for (const wc of WEIGHT_CLASSES) for (const upper of FEDERATIONS.filter((x) => x.prestige > 1)) {
      const lower = FEDERATIONS.find((x) => x.prestige === upper.prestige - 1)!;
      const best = npcs.filter((n) => n.federationId === lower.id && n.weightClassId === wc.id && !protect.has(n.id)).sort((a, b) => scoreOf(b) - scoreOf(a))[0];
      const worst = npcs.filter((n) => n.federationId === upper.id && n.weightClassId === wc.id && !protect.has(n.id) && titles[`${upper.id}:${wc.id}`]?.holderId !== n.id)
        .sort((a, b) => scoreOf(a) - scoreOf(b))[0];
      if (best && worst && scoreOf(best) > scoreOf(worst) + 8) {
        best.federationId = upper.id; worst.federationId = lower.id;
        say(`${best.name} awansuje do ${fedName(upper.id)}, ${worst.name} spada do ${fedName(lower.id)}.`);
      }
    }
    // walki o tytuły
    for (const fed of FEDERATIONS) for (const wc of WEIGHT_CLASSES) {
      const key = `${fed.id}:${wc.id}`;
      const healthy = npcs.filter((n) => n.federationId === fed.id && n.weightClassId === wc.id && !n.injuredDays).sort((a, b) => scoreOf(b) - scoreOf(a));
      if (healthy.length < 2) continue;
      const holder = healthy.find((n) => n.id === titles[key]?.holderId);
      const a = holder ?? healthy[0]!, b = healthy.find((n) => n.id !== a.id)!;
      const w = fightResult(a, b);
      if (!w) continue;
      if (w.id !== titles[key]?.holderId) { titles[key] = { holderId: w.id, since: date }; say(`${w.name} zostaje mistrzem ${fedName(fed.id)} (${wc.name}).`); }
    }
  };

  for (let d = 0; d < days; d++) {
    const used = new Set<string>();
    for (const a of npcs) {
      if (a.injuredDays) { a.injuredDays--; continue; }
      if (used.has(a.id) || rng() > 1 / 45) continue;
      const pool = npcs.filter((b) => b.id !== a.id && !b.injuredDays && !used.has(b.id) && b.federationId === a.federationId && b.weightClassId === a.weightClassId);
      if (!pool.length) continue;
      const b = pool[Math.floor(rng() * pool.length)]!;
      used.add(a.id); used.add(b.id);
      fightResult(a, b);
    }
    const [y, m, day] = date.split('-').map(Number) as [number, number, number];
    const nd = new Date(Date.UTC(y, m - 1, day + 1));
    date = nd.toISOString().slice(0, 10);
    if (date.endsWith('-01')) { if (date.endsWith('-01-01')) yearly(); monthly(); }
  }
  return { ...world, npcs, news: news.slice(-40), titles, date };
}
