import { describe, expect, it } from 'vitest';
import { POLICIES, playCareer, overallRating, type FighterProfile } from './index';

const prof = (style: FighterProfile['style']): FighterProfile => ({
  firstName: 'B', lastName: 'ot', nickname: '', age: 25, nationality: 'Polska', heightCm: 180, weightKg: 77, reachCm: 183,
  dominantHand: 'right', style, experienceYears: 4,
  appearance: { face: 'Kanciasta', hair: 'Krótkie', beard: 'Brak', build: 'Atletyczna', tattoos: 'Brak', kit: 'Czerwony' },
});
const run = (name: string) => {
  const pol = POLICIES.find((p) => p.name === name)!;
  const logs = (['boxing', 'wrestling', 'mma'] as const).flatMap((s) => [1, 2, 3].map((seed) => playCareer(prof(s), pol, 365, seed * 17)));
  const mean = (f: (l: (typeof logs)[0]) => number) => logs.reduce((s, l) => s + f(l), 0) / logs.length;
  return {
    rating: mean((l) => overallRating(l.finalFighter.stats)), money: mean((l) => l.finalFighter.money),
    injuryRate: mean((l) => l.trainingInjuries / Math.max(1, l.trainingDays)), fights: mean((l) => l.fights),
    bankrupt: logs.filter((l) => l.bankruptDay !== null).length,
  };
};

// Regresja balansu: kierunki zależności, nie dokładne liczby (patrz BALANCE.md).
describe('game balance (bot simulations, 1 year)', () => {
  const full = run('pełen'), train = run('tylko trening'), idle = run('leń'), over = run('przetrenowany');
  it('training pays off: trained fighters outgrow idle ones', () => {
    expect(train.rating).toBeGreaterThan(idle.rating + 4);
    expect(full.rating).toBeGreaterThanOrEqual(train.rating - 0.5);
  });
  it('overtraining is punished with injuries and slower growth', () => {
    expect(over.injuryRate).toBeGreaterThan(train.injuryRate);
    expect(over.rating).toBeLessThan(train.rating);
  });
  it('doing nothing neither enriches nor ruins the fighter', () => {
    expect(idle.money).toBeGreaterThan(-3000);
    expect(idle.money).toBeLessThan(train.money + 1);
    expect(idle.bankrupt).toBe(0);
  });
  it('fight cadence is realistic (2 to 8 fights a year)', () => {
    for (const r of [full, train, idle]) { expect(r.fights).toBeGreaterThan(2); expect(r.fights).toBeLessThan(8); }
  });
  it('a first-year income does not explode', () => {
    expect(full.money).toBeLessThan(80000);
  });
});
