import { describe, expect, it } from 'vitest';
import {
  acceptOffer, advanceDays, createFighter, daysToFight, generateOffers, generateWorld, rankings, resolveFight,
  simulateWorld, trainDay, FEDERATIONS, WEIGHT_CLASSES, START_MONEY, RENT, FOOD, TRANSPORT, type FighterProfile,
} from './index';

const prof: FighterProfile = {
  firstName: 'Jan', lastName: 'K', nickname: '', age: 25, nationality: 'Polska', heightCm: 180, weightKg: 77, reachCm: 183,
  dominantHand: 'right', style: 'mma', experienceYears: 5,
  appearance: { face: 'Kanciasta', hair: 'Krótkie', beard: 'Brak', build: 'Atletyczna', tattoos: 'Brak', kit: 'Czerwony' },
};
const mk = () => createFighter(prof, 42);

describe('finance', () => {
  it('training costs money and is refused without funds', () => {
    const f = mk(); const r = trainDay(f, 'gym', 1);
    if (!r.ok) throw new Error(r.reason);
    expect(r.fighter.money).toBe(START_MONEY - 30);
    expect(trainDay({ ...f, money: 5 }, 'gym', 1).ok).toBe(false);
  });
  it('rent and food are charged on the first of the month', () => {
    const f = mk(); // 2027-01-04
    const n = advanceDays(f, 28); // -> 2027-02-01
    expect(n.gameDate).toBe('2027-02-01');
    expect(n.money).toBe(START_MONEY - RENT - FOOD - TRANSPORT);
  });
});

describe('world', () => {
  const w = generateWorld(7);
  it('is deterministic and complete', () => {
    expect(generateWorld(7)).toEqual(w);
    expect(w.npcs.length).toBe(FEDERATIONS.length * WEIGHT_CLASSES.length * 8);
  });
  it('npcs have valid stats and higher federations are stronger', () => {
    const avg = (id: string) => { const l = w.npcs.filter((n) => n.federationId === id); return l.reduce((s, n) => s + n.stats.boxing + n.stats.wrestling, 0) / l.length; };
    expect(avg('apex')).toBeGreaterThan(avg('arena'));
  });
  it('rankings are sorted and ranked', () => {
    const r = rankings(w, mk(), 'arena', 'welter');
    expect(r.length).toBe(8);
    for (let i = 1; i < r.length; i++) expect(r[i - 1]!.score).toBeGreaterThanOrEqual(r[i]!.score);
  });
  it('the world moves on without the player', () => {
    const w2 = simulateWorld(w, 120, 3);
    const before = w.npcs.reduce((s, n) => s + n.record.wins + n.record.losses, 0);
    expect(w2.npcs.reduce((s, n) => s + n.record.wins + n.record.losses, 0)).toBeGreaterThan(before);
  });
});

describe('contracts and fights', () => {
  const w = generateWorld(9);
  it('offers depend on standing', () => {
    const offers = generateOffers(mk());
    expect(offers.some((o) => o.federationId === 'arena')).toBe(true);
    expect(offers.some((o) => o.federationId === 'apex')).toBe(false);
  });
  it('accepting schedules a fight in the same class; second contract refused', () => {
    const f = acceptOffer(mk(), w, 'arena', 1);
    expect(f.contract?.fightsLeft).toBe(3);
    expect(daysToFight(f)).toBe(56);
    const opp = w.npcs.find((n) => n.id === f.nextFight!.opponentId)!;
    expect(opp.weightClassId).toBe(f.weightClass.id);
    expect(() => acceptOffer(f, w, 'arena', 1)).toThrow();
  });
  it('cannot fight before the date', () => {
    const f = acceptOffer(mk(), w, 'arena', 1);
    expect(() => resolveFight(f, w, 0.5, 1)).toThrow();
  });
  it('resolving a fight updates record, pays purse minus tax, uses up the contract and schedules the next', () => {
    let f = { ...acceptOffer(mk(), w, 'arena', 1), money: 0 };
    f = { ...f, gameDate: f.nextFight!.date };
    const oppId = f.nextFight!.opponentId;
    const r = resolveFight(f, w, 0.5, 5);
    const n = r.fighter;
    expect(n.record.wins + n.record.losses + n.record.draws).toBe(1);
    expect(n.money).toBeGreaterThanOrEqual(Math.round(f.contract!.purse * 0.81) - 1);
    expect(n.contract?.fightsLeft).toBe(2);
    expect(n.nextFight).not.toBeNull();
    expect(n.history.length).toBe(1);
    const a = w.npcs.find((x) => x.id === oppId)!, b = r.world.npcs.find((x) => x.id === oppId)!;
    expect(b.record.wins + b.record.losses + b.record.draws).toBe(a.record.wins + a.record.losses + a.record.draws + 1);
  });
});
