import { describe, expect, it } from 'vitest';
import {
  CARS, GYMS, HOUSING, advanceDays, changeCar, changeHousing, changeLifestyle, createFighter, lifestyleOf, mediaOf, netWorth,
  trainDay, upgradeGym, FOOD, TRANSPORT, START_MONEY, type Fighter, type FighterProfile,
} from './index';

const prof: FighterProfile = {
  firstName: 'Jan', lastName: 'K', nickname: '', age: 25, nationality: 'Polska', heightCm: 180, weightKg: 77, reachCm: 183,
  dominantHand: 'right', style: 'boxing', experienceYears: 5,
  appearance: { face: 'Kanciasta', hair: 'Krótkie', beard: 'Brak', build: 'Atletyczna', tattoos: 'Brak', kit: 'Czerwony' },
};
const rich = (): Fighter => ({ ...createFighter(prof, 42), money: 500000 });
const ok = <T,>(r: { ok: boolean } & T) => { if (!r.ok) throw new Error('train failed'); return r as any; };

describe('housing', () => {
  it('different homes recover fatigue at different speeds', () => {
    const tired = (h: 'room' | 'flat' | 'penthouse' | 'house') => {
      const f = changeHousing({ ...rich(), condition: { ...rich().condition, fatigue: 80 } }, h === 'flat' ? 'room' : h);
      return f;
    };
    const base = { ...rich(), condition: { ...rich().condition, fatigue: 80 } };
    const after = (f: Fighter) => advanceDays(f, 2).condition.fatigue;
    const room = after({ ...base, lifestyle: { housing: 'room', car: 'none', gym: 0 } });
    const flat = after(base);
    const pent = after({ ...base, lifestyle: { housing: 'penthouse', car: 'none', gym: 0 } });
    const house = after({ ...base, lifestyle: { housing: 'house', car: 'none', gym: 0 } });
    expect(room).toBeGreaterThan(flat); expect(pent).toBeLessThan(flat); expect(house).toBeLessThan(pent);
    void tired;
  });
  it('monthly cost depends on the home', () => {
    const cost = (h: 'room' | 'flat' | 'penthouse') => { const f = { ...rich(), lifestyle: { housing: h, car: 'none' as const, gym: 0 as const } }; return f.money - advanceDays(f, 28).money; };
    expect(cost('room')).toBeLessThan(cost('flat')); expect(cost('flat')).toBeLessThan(cost('penthouse'));
    expect(cost('flat')).toBe(HOUSING.flat.monthly + FOOD + TRANSPORT);
  });
  it('buying a house takes cash, selling gives back 80%, and funds are required', () => {
    const f = rich(); const h = changeHousing(f, 'house');
    expect(h.money).toBe(f.money - HOUSING.house.price - 300);
    expect(lifestyleOf(h).housing).toBe('house');
    const back = changeHousing(h, 'flat');
    expect(back.money).toBe(h.money + HOUSING.house.price * 0.8 - 300);
    expect(() => changeHousing({ ...f, money: 1000 }, 'house')).toThrow();
    expect(() => changeHousing(f, 'flat')).toThrow();
  });
});

describe('car', () => {
  it('removes commute fatigue and swaps transport cost for upkeep', () => {
    const f = rich(); const withCar = changeCar(f, 'used');
    const a = ok(trainDay(f, 'boxing', 1)).fighter.condition.fatigue, b = ok(trainDay(withCar, 'boxing', 1)).fighter.condition.fatigue;
    expect(b).toBeLessThan(a);
    const m = (x: Fighter) => x.money - advanceDays(x, 28).money;
    expect(m(withCar)).toBe(m(f) - TRANSPORT + CARS.used.upkeep);
  });
  it('selling returns 60%; a sports car adds popularity every month', () => {
    const f = changeCar(rich(), 'sport'); const sold = changeCar(f, 'none');
    expect(sold.money).toBe(f.money + CARS.sport.price * 0.6);
    const g = { ...f, media: { ...mediaOf(f), popularity: 20 } }, h = { ...rich(), media: { ...mediaOf(f), popularity: 20 } };
    expect(mediaOf(advanceDays(g, 28)).popularity).toBeGreaterThan(mediaOf(advanceDays(h, 28)).popularity);
  });
});

describe('home gym', () => {
  it('upgrades in two steps and then refuses', () => {
    const f = upgradeGym(rich()); expect(lifestyleOf(f).gym).toBe(1);
    expect(lifestyleOf(upgradeGym(f)).gym).toBe(2); expect(() => upgradeGym(upgradeGym(f))).toThrow();
    expect(() => upgradeGym({ ...rich(), money: 100 })).toThrow();
  });
  it('makes gym sessions free and stronger', () => {
    const f = rich(), g = upgradeGym(f), p = upgradeGym(g);
    const r0 = ok(trainDay(f, 'gym', 1)), r1 = ok(trainDay(g, 'gym', 1)), r2 = ok(trainDay(p, 'gym', 1));
    expect(r1.fighter.money).toBe(g.money);
    expect(r0.fighter.money).toBe(f.money - 30);
    const gain = (x: any, y: Fighter) => x.fighter.stats.strength - y.stats.strength;
    expect(gain(r1, g)).toBeGreaterThan(gain(r0, f)); expect(gain(r2, p)).toBeGreaterThan(gain(r1, g));
    expect(ok(trainDay(g, 'boxing', 1)).fighter.money).toBe(g.money - 40);
  });
});

describe('net worth and guards', () => {
  it('counts property, car and gym at resale value', () => {
    const f = rich();
    const h = changeCar(changeHousing(f, 'house'), 'used');
    expect(netWorth(h)).toBeGreaterThan(h.money + HOUSING.house.price * 0.79);
    expect(netWorth(h)).toBeLessThan(netWorth(f) + 1);
  });
  it('cannot change lifestyle during a fight', () => {
    expect(() => changeLifestyle({ ...rich(), activeFight: {} as any }, 'gym')).toThrow();
    expect(() => changeLifestyle(rich(), 'nope')).toThrow();
  });
  it('starting fighters have the default lifestyle', () => expect(createFighter(prof, 1).money).toBe(START_MONEY));
});
