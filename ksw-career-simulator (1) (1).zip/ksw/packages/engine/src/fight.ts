import type { Fighter, Stats } from './types';

export interface Combatant { name: string; stats: Stats; fatigue: number; health: number; aggression: number }
export interface FightStats { strikesThrown: number; strikesLanded: number; takedownsTried: number; takedowns: number; controlSec: number; damage: number }
export interface FightEvent { round: number; sec: number; kind: 'strike' | 'takedown' | 'sub' | 'ko'; actor: 0 | 1; text: string }

export type ActionKind = 'idle' | 'punch' | 'kick' | 'knee' | 'takedown' | 'gnp' | 'sub' | 'escape' | 'control';
export interface FightAction { kind: ActionKind; hit?: boolean; ok?: boolean }
/** Jedna klatka = jeden tick symulacji (5 s walki). Na jej podstawie działa odtwarzacz 3D. */
export interface FightFrame {
  round: number; sec: number; ground: boolean; top: 0 | 1 | null;
  actions: [FightAction, FightAction]; hp: [number, number]; stamina: [number, number];
  end?: 'KO' | 'TKO' | 'SUB' | 'DEC' | 'DRAW'; winner?: 0 | 1 | null;
}

export interface FightResult {
  winner: 0 | 1 | null; method: 'KO' | 'TKO' | 'SUB' | 'DEC' | 'DRAW';
  round: number; timeSec: number; stats: [FightStats, FightStats]; scores: [number, number];
  events: FightEvent[]; timeline: FightFrame[]; maxHp: [number, number];
}

export type Focus = 'balanced' | 'pressure' | 'distance' | 'takedown' | 'counter' | 'conserve' | 'body';
export interface Tactics { aggression: number; focus: Focus }
export const FOCUS_LABELS: Record<Focus, string> = {
  balanced: 'Zrównoważona', pressure: 'Zwiększ presję', distance: 'Walcz na dystans', takedown: 'Szukaj obalenia',
  counter: 'Skup się na kontrach', conserve: 'Oszczędzaj kondycję', body: 'Atakuj korpus',
};
export const FOCUS_HINT: Record<Focus, string> = {
  balanced: 'Bez zmian w planie.',
  pressure: 'Więcej ataków i wyższe tempo, ale szybciej się męczysz.',
  distance: 'Rzadziej próbujesz obaleń, a rywalowi trudniej obalić Ciebie.',
  takedown: 'Dużo więcej prób obalenia, mniej ciosów w stójce.',
  counter: 'Mniej ataków, lepsza obrona i skuteczność kontr.',
  conserve: 'Mniej zużywasz kondycji, ale atakujesz rzadziej.',
  body: 'Słabsze ciosy, ale rywal szybciej traci kondycję.',
};
export const defaultTactics = (c: Combatant): Tactics => ({ aggression: c.aggression, focus: 'balanced' });

export interface RoundStat { landed: number; thrown: number; tdOk: number; tdTried: number; control: number; damage: number }
export interface RoundSummary {
  round: number; score: [number, number]; stats: [RoundStat, RoundStat];
  hpPct: [number, number]; staminaPct: [number, number]; tactics: [Tactics, Tactics];
}

/** Pełny, serializowalny stan walki: pozwala wstrzymać symulację po rundzie i wznowić ją (nawet po przeładowaniu). */
export interface FightState {
  combatants: [Combatant, Combatant]; rng: number;
  hp: [number, number]; maxHp: [number, number]; stamina: [number, number];
  nextRound: number; scores: [number, number];
  stats: [FightStats, FightStats]; events: FightEvent[]; timeline: FightFrame[]; rounds: RoundSummary[];
  result: FightResult | null;
}

export const combatantFrom = (f: Fighter, aggression = 0.5): Combatant => ({
  name: `${f.profile.firstName} ${f.profile.lastName}`, stats: f.stats,
  fatigue: f.condition.fatigue, health: f.condition.health, aggression,
});

export const ROUNDS = 3;
const ROUND_SEC = 300, TICK = 5;
const sig = (x: number) => 1 / (1 + Math.exp(-x));
const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v));

function strikeKind(c: Combatant, n: number): 'punch' | 'kick' | 'knee' {
  const kicks = c.stats.kickboxing + c.stats.muaythai, punches = c.stats.boxing * 2;
  const m = n % 10;
  if (m < (punches >= kicks ? 7 : 4)) return 'punch';
  return m < 9 || c.stats.muaythai < c.stats.kickboxing ? 'kick' : 'knee';
}

function tacticParams(t: Tactics) {
  const f = t.focus;
  return {
    aggr: clamp(t.aggression + (f === 'pressure' ? 0.25 : f === 'conserve' ? -0.25 : 0), 0, 1),
    tdMult: f === 'takedown' ? 2.2 : f === 'distance' ? 0.5 : 1,
    strikeMult: f === 'takedown' ? 0.7 : f === 'counter' ? 0.65 : 1,
    hitBonus: f === 'counter' ? 0.1 : 0,
    defBonus: f === 'counter' ? 0.1 : f === 'distance' ? 0.05 : 0,
    tdDefBonus: f === 'distance' ? 0.1 : 0,
    drain: f === 'conserve' ? 0.5 : f === 'pressure' ? 1.2 : 1,
    dmgMult: f === 'body' ? 0.8 : 1,
    bodyDrain: f === 'body' ? 2 : 1,
  };
}

export function startFight(a: Combatant, b: Combatant, seed: number): FightState {
  const maxHp = [a, b].map((c) => (120 + c.stats.durability * 0.8) * (0.7 + 0.3 * c.health / 100)) as [number, number];
  const z = (): FightStats => ({ strikesThrown: 0, strikesLanded: 0, takedownsTried: 0, takedowns: 0, controlSec: 0, damage: 0 });
  return {
    combatants: [a, b], rng: seed >>> 0, hp: [...maxHp], maxHp,
    stamina: [100 - a.fatigue * 0.4, 100 - b.fatigue * 0.4], nextRound: 1, scores: [0, 0],
    stats: [z(), z()], events: [], timeline: [], rounds: [], result: null,
  };
}

/** Jedna runda przy zadanych taktykach obu stron. Zwraca nowy stan (poprzedni pozostaje bez zmian). */
export function simulateRound(prev: FightState, tactics: [Tactics, Tactics]): FightState {
  const S = structuredClone(prev);
  if (S.result) return S;
  const round = S.nextRound;
  let rs = S.rng;
  const rng = () => {
    rs = (rs + 0x6d2b79f5) >>> 0;
    let t = rs;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
  const F = S.combatants, hp = S.hp, maxHp = S.maxHp, stamina = S.stamina, stats = S.stats, events = S.events, timeline = S.timeline;
  const P = [tacticParams(tactics[0]), tacticParams(tactics[1])];
  const before = structuredClone(stats);
  let ground = false, top: 0 | 1 = 0;

  const sf = (i: number) => 0.5 + 0.5 * clamp(stamina[i]!, 0, 100) / 100;
  const strikeSkill = (c: Combatant) => Math.max(c.stats.boxing, c.stats.kickboxing, c.stats.muaythai) * 0.8 + c.stats.precision * 0.2;
  const rd = [0, 0], ctrl = [0, 0], tds = [0, 0];

  const summary = (score: [number, number]): RoundSummary => {
    const d = (i: 0 | 1): RoundStat => ({
      landed: stats[i].strikesLanded - before[i].strikesLanded, thrown: stats[i].strikesThrown - before[i].strikesThrown,
      tdOk: stats[i].takedowns - before[i].takedowns, tdTried: stats[i].takedownsTried - before[i].takedownsTried,
      control: stats[i].controlSec - before[i].controlSec, damage: Math.round((stats[i].damage - before[i].damage) * 10) / 10,
    });
    return {
      round, score, stats: [d(0), d(1)],
      hpPct: [Math.round(Math.max(0, hp[0]!) / maxHp[0]! * 100), Math.round(Math.max(0, hp[1]!) / maxHp[1]! * 100)],
      staminaPct: [Math.round(clamp(stamina[0]!, 0, 100)), Math.round(clamp(stamina[1]!, 0, 100))], tactics,
    };
  };
  const stop = (winner: 0 | 1, method: 'KO' | 'TKO' | 'SUB', sec: number): FightState => {
    S.rounds.push(summary([0, 0]));
    S.rng = rs;
    S.result = { winner, method, round, timeSec: sec + TICK, stats, scores: S.scores, events, timeline, maxHp };
    return S;
  };

  for (let sec = 0; sec < ROUND_SEC; sec += TICK) {
    const clock = (round - 1) * ROUND_SEC + sec + TICK;
    const acts: [FightAction, FightAction] = [{ kind: 'idle' }, { kind: 'idle' }];
    const pushFrame = (end?: FightFrame['end'], winner?: 0 | 1 | null) => timeline.push({
      round, sec, ground, top: ground ? top : null, actions: [{ ...acts[0] }, { ...acts[1] }],
      hp: [Math.max(0, hp[0]!), Math.max(0, hp[1]!)], stamina: [Math.max(0, stamina[0]!), Math.max(0, stamina[1]!)], end, winner,
    });
    for (const i of [0, 1] as const) {
      const o = (1 - i) as 0 | 1, A = F[i]!, B = F[o]!, tp = P[i]!, po = P[o]!;
      stamina[i] = stamina[i]! - ((1 - A.stats.cardio / 100) * 0.6 + 0.15) * tp.drain;
      let dmg = 0;
      if (!ground) {
        const tdP = (0.04 + 0.12 * (A.stats.wrestling / 100) * (1 - tp.aggr * 0.3)) * tp.tdMult;
        if (rng() < tdP * sf(i)) {
          stats[i].takedownsTried++;
          const p = clamp(sig((A.stats.wrestling * 0.7 + A.stats.strength * 0.3 - (B.stats.wrestling * 0.6 + B.stats.defense * 0.4)) / 18) - po.tdDefBonus, 0.02, 0.98);
          stamina[i] = stamina[i]! - 3;
          const ok = rng() < p;
          acts[i] = { kind: 'takedown', ok };
          if (ok) { ground = true; top = i; stats[i].takedowns++; tds[i]!++; events.push({ round, sec, kind: 'takedown', actor: i, text: `${A.name}: obalenie` }); }
        } else if (rng() < (0.3 + 0.5 * tp.aggr) * sf(i) * tp.strikeMult) {
          stats[i].strikesThrown++;
          const atk = strikeSkill(A) * sf(i), def = (B.stats.defense * 0.6 + B.stats.reflex * 0.4) * sf(o);
          acts[i] = { kind: strikeKind(A, clock / TICK + i), hit: false };
          if (rng() < sig((atk - def) / 20) * 0.8 + tp.hitBonus - po.defBonus) {
            stats[i].strikesLanded++;
            acts[i].hit = true;
            dmg = (1 + A.stats.strength * 0.04) * (0.5 + rng()) * (rng() < 0.03 ? 3 : 1) * tp.dmgMult;
            stamina[i] = stamina[i]! - 1.5;
          }
        }
      } else if (top === i) {
        stats[i].controlSec += TICK; ctrl[i]! += TICK; stamina[i] = stamina[i]! - 1;
        acts[i] = { kind: 'control' };
        if (rng() < 0.25 * sf(i)) {
          acts[i] = { kind: 'sub' };
          const p = sig((A.stats.bjj * 0.8 + A.stats.fightIQ * 0.2 - (B.stats.bjj * 0.6 + B.stats.defense * 0.4)) / 12) * 0.35;
          if (rng() < p) { events.push({ round, sec, kind: 'sub', actor: i, text: `${A.name}: poddanie` }); pushFrame('SUB', i); return stop(i, 'SUB', sec); }
        } else if (rng() < 0.2 + 0.5 * tp.aggr) {
          stats[i].strikesThrown++; stats[i].strikesLanded++;
          acts[i] = { kind: 'gnp', hit: true };
          dmg = (0.8 + A.stats.strength * 0.03) * (0.5 + rng()) * tp.dmgMult;
        }
      } else if (rng() < 0.08 + 0.25 * sig((A.stats.wrestling * 0.5 + A.stats.bjj * 0.5 - (B.stats.wrestling * 0.6 + B.stats.strength * 0.4)) / 20)) {
        ground = false;
        acts[i] = { kind: 'escape' };
      }
      if (dmg > 0) {
        hp[o] = hp[o]! - dmg; stats[i].damage += dmg; rd[i]! += dmg;
        stamina[o] = stamina[o]! - dmg * 0.2 * tp.bodyDrain;
        const chinKO = dmg >= 4 && hp[o]! < maxHp[o]! * 0.55 && rng() > B.stats.durability / 100 + 0.35;
        if (chinKO || hp[o]! <= 0) {
          const method = chinKO ? 'KO' : 'TKO';
          events.push({ round, sec, kind: 'ko', actor: i, text: `${A.name}: ${method}` });
          pushFrame(method, i);
          return stop(i, method, sec);
        }
      }
    }
    pushFrame();
  }

  const score = (i: 0 | 1) => rd[i]! + ctrl[i]! * 0.15 + tds[i]! * 3;
  const d = score(0) - score(1);
  const sc: [number, number] = Math.abs(d) < 1 ? [10, 10] : d > 0 ? [10, 9] : [9, 10];
  S.scores = [S.scores[0] + sc[0], S.scores[1] + sc[1]];
  S.rounds.push(summary(sc));
  for (const i of [0, 1]) stamina[i] = Math.min(100, stamina[i]! + 12 + F[i]!.stats.cardio * 0.1);
  S.nextRound = round + 1;
  S.rng = rs;
  if (round === ROUNDS) {
    const winner = S.scores[0] === S.scores[1] ? null : S.scores[0] > S.scores[1] ? 0 : 1;
    const last = timeline[timeline.length - 1]!;
    last.end = winner === null ? 'DRAW' : 'DEC'; last.winner = winner;
    S.result = { winner, method: winner === null ? 'DRAW' : 'DEC', round: ROUNDS, timeSec: ROUND_SEC, stats, scores: S.scores, events, timeline, maxHp };
  }
  return S;
}

/** Cała walka przy stałych taktykach (NPC vs NPC, testy, automatyczna symulacja). */
export function simulateFight(a: Combatant, b: Combatant, seed: number): FightResult {
  let s = startFight(a, b, seed);
  const t: [Tactics, Tactics] = [defaultTactics(a), defaultTactics(b)];
  while (!s.result) s = simulateRound(s, t);
  return s.result;
}

export interface Advice { focus: Focus; aggression: number; text: string }

/** Rada narożnika po rundzie, na podstawie liczb z ostatniej rundy. */
export function adviseTactics(state: FightState, i: 0 | 1): Advice {
  const last = state.rounds[state.rounds.length - 1];
  if (!last) return { focus: 'balanced', aggression: 0.5, text: 'Zacznij spokojnie i sprawdź rywala.' };
  const me = last.stats[i], op = last.stats[1 - i as 0 | 1], st = last.staminaPct[i];
  const diff = state.scores[i] - state.scores[1 - i as 0 | 1];
  if (st < 35) return { focus: 'conserve', aggression: 0.35, text: 'Brakuje Ci tchu. Oszczędzaj siły i nie daj się wciągnąć w wymianę.' };
  if (op.tdOk >= 2) return { focus: 'distance', aggression: 0.5, text: 'Rywal zbyt łatwo Cię obala. Pracuj na dystans i pilnuj nóg.' };
  if (me.tdOk >= 1 && me.control >= 40) return { focus: 'takedown', aggression: 0.6, text: 'Obalenia działają. Zabieraj go do parteru.' };
  if (op.damage > me.damage * 1.4 && last.hpPct[i] < 60) return { focus: 'counter', aggression: 0.4, text: 'Dostajesz więcej niż oddajesz. Wycofaj się i szukaj kontr.' };
  if (diff < 0) return { focus: 'pressure', aggression: 0.75, text: 'Przegrywasz na kartach. Trzeba docisnąć tempo.' };
  if (diff > 0 && st < 60) return { focus: 'conserve', aggression: 0.4, text: 'Wygrywasz, ale kondycja spada. Kontroluj tempo.' };
  if (me.landed >= op.landed * 1.3) return { focus: 'body', aggression: 0.6, text: 'Trafiasz regularnie. Zejdź na korpus i zmęcz rywala.' };
  return { focus: 'balanced', aggression: 0.5, text: 'Jest wyrównanie. Trzymaj plan i szukaj okazji.' };
}

/** Rywal koryguje taktykę tą samą logiką, ale z pełną wiedzą o rundzie. */
export function opponentTactics(state: FightState): Tactics {
  const a = adviseTactics(state, 1);
  return { aggression: a.aggression, focus: a.focus };
}
