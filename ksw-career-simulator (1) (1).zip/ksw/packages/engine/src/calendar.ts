import { monthlyExpenses } from './finance';
import { healBonusDay } from './staff';
import { monthlyMedia } from './media';
import { housingRecovery, monthlyLifestyle } from './lifestyle';
import type { Fighter, Injury } from './types';

export const INJURY_DAYS: Record<Injury['severity'], number> = { 1: 7, 2: 21, 3: 56 };

export function addDays(iso: string, n: number): string {
  const d = new Date(`${iso}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
}

const toward = (v: number, target: number, step: number) =>
  v < target ? Math.min(target, v + step) : Math.max(target, v - step);
const round1 = (v: number) => Math.round(v * 10) / 10;

/** Jeden dzień: regeneracja zmęczenia, leczenie kontuzji, powrót zdrowia/formy/stresu do normy. */
export function advanceDay(f: Fighter, restBonus = 0): Fighter {
  const date = addDays(f.gameDate, 1);
  const dec = 1 + healBonusDay(f, date);
  const injuries = f.injuries.map((i) => ({ ...i, daysLeft: i.daysLeft - dec })).filter((i) => i.daysLeft > 0);
  const healthCap = Math.max(10, 100 - injuries.reduce((s, i) => s + i.severity * 10, 0));
  const c = f.condition;
  const next: Fighter = {
    ...f,
    gameDate: date,
    injuries,
    condition: {
      ...c,
      fatigue: round1(Math.max(0, c.fatigue - Math.max(4, 10 + restBonus + housingRecovery(f)))),
      health: round1(toward(c.health, healthCap, injuries.length ? 1 : 2)),
      form: round1(toward(c.form, 50, 1)),
      stress: round1(toward(c.stress, 10, 1)),
    },
  };
  const rested: Fighter = next.media ? { ...next, media: { ...next.media, fatigue: Math.max(0, (next.media.fatigue ?? 0) - 8) } } : next;
  return rested.gameDate.endsWith('-01') ? monthlyMedia(monthlyLifestyle(monthlyExpenses(rested))) : rested;
}

export function daysBetween(a: string, b: string): number {
  return Math.round((Date.parse(`${b}T00:00:00Z`) - Date.parse(`${a}T00:00:00Z`)) / 86400000);
}

/** Ile dni do zaplanowanej walki (0 = dziś walka), null gdy brak walki. */
export function daysToFight(f: Fighter): number | null {
  return f.nextFight ? Math.max(0, daysBetween(f.gameDate, f.nextFight.date)) : null;
}

export function advanceDays(f: Fighter, days: number): Fighter {
  let out = f;
  for (let i = 0; i < days; i++) out = advanceDay(out);
  return out;
}
