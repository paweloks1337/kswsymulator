import { START_MONEY } from './finance';
import {
  ATTRIBUTES, STYLES, APPEARANCE_OPTIONS,
  type Attribute, type Fighter, type FighterProfile, type Stats, type Style, type WeightClass,
} from './types';

export const WEIGHT_CLASSES: WeightClass[] = [
  { id: 'feather', name: 'Piórkowa', maxKg: 66 },
  { id: 'light', name: 'Lekka', maxKg: 70 },
  { id: 'welter', name: 'Półśrednia', maxKg: 77 },
  { id: 'middle', name: 'Średnia', maxKg: 84 },
  { id: 'lightheavy', name: 'Półciężka', maxKg: 93 },
  { id: 'heavy', name: 'Ciężka', maxKg: 120 },
];

export const LIMITS = {
  age: [18, 45], height: [150, 215], weight: [52, 120], experience: [0, 25],
} as const;

export function weightClassFor(kg: number): WeightClass | null {
  return WEIGHT_CLASSES.find((c) => kg <= c.maxKg) ?? null;
}

const SKILLS: Attribute[] = ['boxing', 'kickboxing', 'muaythai', 'wrestling', 'bjj'];
const BASE = 30;
export const START_DATE = '2027-01-04';

const STYLE_BONUS: Record<Style, Partial<Record<Attribute, number>>> = {
  boxing: { boxing: 22, precision: 8, reflex: 6, defense: 6, speed: 3 },
  kickboxing: { kickboxing: 20, boxing: 8, speed: 5, cardio: 4, defense: 3 },
  muaythai: { muaythai: 22, kickboxing: 6, durability: 6, strength: 3, defense: 3 },
  wrestling: { wrestling: 22, strength: 8, cardio: 6, durability: 3, bjj: 3 },
  bjj: { bjj: 22, wrestling: 6, fightIQ: 6, defense: 3 },
  mma: { boxing: 7, kickboxing: 7, muaythai: 5, wrestling: 7, bjj: 7, fightIQ: 5, cardio: 3 },
};

const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v));

export function validateProfile(p: FighterProfile): string[] {
  const e: string[] = [];
  const inRange = (v: number, [lo, hi]: readonly [number, number]) => Number.isFinite(v) && v >= lo && v <= hi;
  if (!p.firstName.trim() || p.firstName.length > 30) e.push('Podaj imię (do 30 znaków).');
  if (!p.lastName.trim() || p.lastName.length > 30) e.push('Podaj nazwisko (do 30 znaków).');
  if (p.nickname.length > 30) e.push('Pseudonim może mieć najwyżej 30 znaków.');
  if (!p.nationality.trim()) e.push('Podaj narodowość.');
  if (!inRange(p.age, LIMITS.age)) e.push(`Wiek musi mieścić się w przedziale ${LIMITS.age[0]}-${LIMITS.age[1]} lat.`);
  if (!inRange(p.heightCm, LIMITS.height)) e.push(`Wzrost musi mieścić się w przedziale ${LIMITS.height[0]}-${LIMITS.height[1]} cm.`);
  if (!inRange(p.weightKg, LIMITS.weight)) e.push(`Waga musi mieścić się w przedziale ${LIMITS.weight[0]}-${LIMITS.weight[1]} kg.`);
  if (!Number.isFinite(p.reachCm) || p.reachCm < p.heightCm - 10 || p.reachCm > p.heightCm + 25)
    e.push('Zasięg ramion może różnić się od wzrostu o -10 do +25 cm.');
  if (!inRange(p.experienceYears, LIMITS.experience)) e.push(`Doświadczenie: ${LIMITS.experience[0]}-${LIMITS.experience[1]} lat.`);
  else if (p.experienceYears > p.age - 14) e.push('Doświadczenie nie może zaczynać się przed 14. rokiem życia.');
  if (!STYLES.includes(p.style)) e.push('Wybierz styl walki.');
  for (const k of Object.keys(APPEARANCE_OPTIONS) as (keyof typeof APPEARANCE_OPTIONS)[]) {
    if (!(APPEARANCE_OPTIONS[k] as readonly string[]).includes(p.appearance[k])) e.push(`Nieprawidłowy wybór wyglądu: ${k}.`);
  }
  return e;
}

/** Deterministyczne statystyki startowe: styl + doświadczenie + wiek + waga. Bez losowości. */
export function computeStartingStats(p: FighterProfile): Stats {
  const s = Object.fromEntries(ATTRIBUTES.map((a) => [a, BASE])) as Stats;
  const bonus = STYLE_BONUS[p.style];
  const exp = Math.min(14, p.experienceYears * 1.4);
  for (const a of ATTRIBUTES) {
    const b = bonus[a] ?? 0;
    s[a] += b;
    if (SKILLS.includes(a) && b >= 5) s[a] += exp * Math.min(1, b / 22);
  }
  s.fightIQ += Math.min(20, p.experienceYears * 1.3);
  s.cardio += Math.min(6, p.experienceYears * 0.5);

  const physical: Attribute[] = ['strength', 'speed', 'cardio', 'reflex'];
  const agePenalty = p.age < 27 ? (27 - p.age) * 0.8 : p.age > 31 ? (p.age - 31) * 1.4 : 0;
  for (const a of physical) s[a] -= agePenalty;
  if (p.age > 33) s.durability -= (p.age - 33) * 1.0;

  s.strength += (p.weightKg - 77) * 0.12;
  s.speed -= (p.weightKg - 77) * 0.1;

  for (const a of ATTRIBUTES) s[a] = clamp(Math.round(s[a]), 1, 100);
  return s;
}

export function overallRating(stats: Stats): number {
  const v = ATTRIBUTES.map((a) => stats[a]);
  return Math.round(v.reduce((x, y) => x + y, 0) / v.length);
}

export function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function rollPotential(age: number, seed: number): number {
  const r = mulberry32(seed)();
  return clamp(Math.round(60 + r * 35 - Math.max(0, age - 26) * 1.5), 40, 99);
}

export function createFighter(profile: FighterProfile, seed: number): Fighter {
  const errors = validateProfile(profile);
  if (errors.length) throw new Error(errors.join(' '));
  const weightClass = weightClassFor(profile.weightKg)!;
  return {
    id: `f-${seed.toString(36)}`,
    profile,
    weightClass,
    stats: computeStartingStats(profile),
    condition: {
      form: 50, fatigue: 0, health: 100,
      confidence: 50 + Math.min(10, profile.experienceYears),
      stress: 10, experience: Math.min(100, profile.experienceYears * 4),
    },
    potential: rollPotential(profile.age, seed),
    record: { wins: 0, losses: 0, draws: 0 },
    createdAt: new Date(seed).toISOString(),
    gameDate: START_DATE,
    trained: {},
    injuries: [],
    money: START_MONEY,
    staff: [],
    lifestyle: { housing: 'flat', car: 'none', gym: 0 },
    media: { popularity: 5, reputation: 10, charisma: Math.min(60, Math.max(25, 30 + profile.experienceYears * 1.5)), controversy: 0, lastActionDate: null },
    sponsors: [],
    log: [],
    ledger: [],
    contract: null,
    nextFight: null,
    history: [],
  };
}
