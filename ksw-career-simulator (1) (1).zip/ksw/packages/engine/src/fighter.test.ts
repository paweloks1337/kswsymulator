import { describe, expect, it } from 'vitest';
import {
  ATTRIBUTES, computeStartingStats, createFighter, rollPotential, validateProfile, weightClassFor,
  type FighterProfile,
} from './index';

const base: FighterProfile = {
  firstName: 'Jan', lastName: 'Kowalski', nickname: 'Młot', age: 25, nationality: 'Polska',
  heightCm: 180, weightKg: 77, reachCm: 183, dominantHand: 'right', style: 'boxing', experienceYears: 5,
  appearance: { face: 'Kanciasta', hair: 'Krótkie', beard: 'Brak', build: 'Atletyczna', tattoos: 'Brak', kit: 'Czerwony' },
};

describe('weight classes', () => {
  it('maps weight to the right class', () => {
    expect(weightClassFor(66)?.id).toBe('feather');
    expect(weightClassFor(66.1)?.id).toBe('light');
    expect(weightClassFor(120)?.id).toBe('heavy');
    expect(weightClassFor(121)).toBeNull();
  });
});

describe('validation', () => {
  it('accepts a valid profile', () => expect(validateProfile(base)).toEqual([]));
  it('rejects bad data', () => {
    expect(validateProfile({ ...base, firstName: ' ' }).length).toBeGreaterThan(0);
    expect(validateProfile({ ...base, age: 17 }).length).toBeGreaterThan(0);
    expect(validateProfile({ ...base, weightKg: 130 }).length).toBeGreaterThan(0);
    expect(validateProfile({ ...base, reachCm: 230 }).length).toBeGreaterThan(0);
    expect(validateProfile({ ...base, age: 20, experienceYears: 10 }).length).toBeGreaterThan(0);
  });
  it('createFighter throws on invalid input', () => {
    expect(() => createFighter({ ...base, age: 5 }, 1)).toThrow();
  });
});

describe('starting stats', () => {
  it('are deterministic and within 1..100', () => {
    const a = computeStartingStats(base);
    expect(a).toEqual(computeStartingStats(base));
    for (const k of ATTRIBUTES) expect(a[k]).toBeGreaterThanOrEqual(1), expect(a[k]).toBeLessThanOrEqual(100);
  });
  it('favour the chosen style', () => {
    expect(computeStartingStats(base).boxing).toBeGreaterThan(computeStartingStats({ ...base, style: 'bjj' }).boxing);
    expect(computeStartingStats({ ...base, style: 'bjj' }).bjj).toBeGreaterThan(computeStartingStats(base).bjj);
  });
  it('reward experience in the main skill', () => {
    expect(computeStartingStats({ ...base, experienceYears: 10 }).boxing)
      .toBeGreaterThan(computeStartingStats({ ...base, experienceYears: 1 }).boxing);
  });
  it('penalise physical stats of older fighters', () => {
    expect(computeStartingStats({ ...base, age: 40 }).speed).toBeLessThan(computeStartingStats(base).speed);
  });
  it('MMA style is balanced across disciplines', () => {
    const s = computeStartingStats({ ...base, style: 'mma' });
    const skills = [s.boxing, s.kickboxing, s.wrestling, s.bjj];
    expect(Math.max(...skills) - Math.min(...skills)).toBeLessThanOrEqual(4);
  });
});

describe('potential', () => {
  it('is deterministic per seed and bounded', () => {
    expect(rollPotential(22, 7)).toBe(rollPotential(22, 7));
    for (let s = 1; s < 200; s++) {
      const p = rollPotential(30, s);
      expect(p).toBeGreaterThanOrEqual(40), expect(p).toBeLessThanOrEqual(99);
    }
  });
  it('is lower on average for older fighters', () => {
    const avg = (age: number) => Array.from({ length: 300 }, (_, i) => rollPotential(age, i + 1)).reduce((x, y) => x + y) / 300;
    expect(avg(38)).toBeLessThan(avg(20));
  });
});
