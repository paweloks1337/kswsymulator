import { charge } from './finance';
import { mulberry32 } from './fighter';
import { carIsStatus } from './lifestyle';
import type { Fighter, LogEntry, MediaState, SponsorDeal } from './types';

const clamp = (v: number, lo = 0, hi = 100) => Math.min(hi, Math.max(lo, v));
const r1 = (v: number) => Math.round(v * 10) / 10;
const sig = (x: number) => 1 / (1 + Math.exp(-x));

export const DEFAULT_MEDIA: MediaState = { popularity: 5, reputation: 10, charisma: 35, controversy: 0, lastActionDate: null };
export const mediaOf = (f: Fighter): MediaState => f.media ?? DEFAULT_MEDIA;
export const sponsorsOf = (f: Fighter): SponsorDeal[] => f.sponsors ?? [];

const addLog = (f: Fighter, text: string): LogEntry[] => [...(f.log ?? []), { date: f.gameDate, text }].slice(-20);
const daysToNext = (f: Fighter): number | null =>
  f.nextFight ? Math.round((Date.parse(`${f.nextFight.date}T00:00:00Z`) - Date.parse(`${f.gameDate}T00:00:00Z`)) / 86400000) : null;

export interface MediaAction { id: string; label: string; description: string }
export const MEDIA_ACTIONS: MediaAction[] = [
  { id: 'interview_calm', label: 'Spokojny wywiad', description: 'Pewny wzrost popularności i reputacji, bez ryzyka.' },
  { id: 'interview_bold', label: 'Odważny wywiad', description: 'Większy wzrost popularności, ale ryzyko źle odebranych słów i kontrowersje.' },
  { id: 'social', label: 'Media społecznościowe', description: 'Mały, stały przyrost popularności. Rzadko trafia się wpadka.' },
  { id: 'press', label: 'Konferencja prasowa', description: 'Dostępna do 14 dni przed walką, raz na walkę. Popularność rośnie.' },
  { id: 'trash_talk', label: 'Trash talk', description: 'Dostępny do 21 dni przed walką (do 2 razy). Duża popularność i kontrowersje, ale porażka po głośnych słowach boli podwójnie.' },
  { id: 'face_off', label: 'Face-off', description: 'Dostępny w ostatnich 2 dniach przed walką, raz na walkę. Może dodać albo odebrać pewności siebie.' },
];

/** Powód niedostępności akcji lub null, gdy można ją wykonać. */
export function mediaBlocked(f: Fighter, id: string): string | null {
  if (f.activeFight) return 'Trwa walka.';
  if (mediaOf(f).lastActionDate === f.gameDate) return 'Dziś wykonałeś już akcję medialną. Wróć jutro.';
  const d = daysToNext(f), nf = f.nextFight;
  if (id === 'press') { if (d === null || d > 14) return 'Dostępna do 14 dni przed walką.'; if (nf?.press) return 'Konferencja do tej walki już się odbyła.'; }
  if (id === 'trash_talk') { if (d === null || d > 21) return 'Dostępny do 21 dni przed walką.'; if ((nf?.hype ?? 0) >= 2) return 'Powiedziałeś już wszystko, co się dało.'; }
  if (id === 'face_off') { if (d === null || d > 2) return 'Dostępny w ostatnich 2 dniach przed walką.'; if (nf?.faceOff) return 'Face-off do tej walki już się odbył.'; }
  return null;
}

export interface MediaResult { fighter: Fighter; text: string; good: boolean }

export function doMedia(f: Fighter, id: string, seed: number): MediaResult {
  if (!MEDIA_ACTIONS.some((a) => a.id === id)) throw new Error('Nieznana akcja medialna.');
  const why = mediaBlocked(f, id);
  if (why) throw new Error(why);
  const rng = mulberry32(seed), roll = rng();
  const m = { ...mediaOf(f) };
  const cf = m.charisma / 100;
  let nf = f.nextFight, text = '', good = true, conf = 0;
  const tired = 1 - (m.fatigue ?? 0) / 120;
  const gain = (pop: number, contr = 0, rep = 0) => { m.popularity = clamp(m.popularity + (pop > 0 ? pop * (1 - m.popularity / 110) * tired : pop)); m.controversy = clamp(m.controversy + contr); m.reputation = clamp(m.reputation + rep * tired); };

  switch (id) {
    case 'interview_calm': gain(0.8 + 1.2 * cf, -1, 0.3); text = 'Spokojny, rzeczowy wywiad. Kibice i media doceniają klasę.'; break;
    case 'interview_bold':
      if (roll < sig((m.charisma - 45) / 20)) { gain(2 + 2 * cf, 2); text = 'Odważne słowa chwyciły. Wywiad robi dużo szumu.'; }
      else { good = false; gain(-1, 4); text = 'Wypowiedź została źle odebrana. Media piszą o wpadce.'; }
      break;
    case 'social':
      if (roll < 0.12) { good = false; gain(-2, 6); text = 'Wpis wywołał burzę w komentarzach.'; }
      else { gain(0.5 + cf); text = 'Wpis zebrał solidny zasięg.'; }
      break;
    case 'press': gain(1.5 + 2 * cf, 1); nf = { ...nf!, press: true }; text = 'Konferencja prasowa podbija zainteresowanie walką.'; break;
    case 'trash_talk':
      if (roll < sig((m.charisma - 50) / 15)) { gain(3 + 3 * cf, 5); text = 'Prowokacja zadziałała. Wszyscy mówią o tej walce.'; }
      else { good = false; gain(-2, 8); text = 'Trash talk wypadł żenująco. Zebrałeś krytykę.'; }
      nf = { ...nf!, hype: (nf!.hype ?? 0) + 1 };
      break;
    case 'face_off':
      if (roll < sig((m.charisma - 45 + (f.condition.confidence - 50)) / 20)) { conf = 6; gain(1.5); text = 'Wygrywasz face-off wzrokiem. Rywal wygląda na zdenerwowanego.'; }
      else { good = false; conf = -4; text = 'Rywal przejął kontrolę w face-offie.'; }
      nf = { ...nf!, faceOff: true };
      break;
  }
  m.charisma = clamp(m.charisma + (good ? 0.4 : 0.1), 0, 100);
  m.popularity = r1(m.popularity); m.reputation = r1(m.reputation); m.controversy = r1(m.controversy); m.charisma = r1(m.charisma);
  m.lastActionDate = f.gameDate;
  m.fatigue = Math.min(100, (m.fatigue ?? 0) + 22);
  const c = f.condition;
  return {
    fighter: { ...f, media: m, nextFight: nf, condition: { ...c, confidence: clamp(c.confidence + conf) }, log: addLog(f, text) },
    text, good,
  };
}

/** Skutki walki dla wizerunku: wygrana buduje, porażka po głośnych słowach boli, sponsorzy płacą premie za zwycięstwo. */
export function applyFightMedia(f: Fighter, outcome: { won: boolean; lost: boolean; finish: boolean }, hype: number): Fighter {
  const m = { ...mediaOf(f) };
  const { won, lost, finish } = outcome;
  if (won) { m.reputation += 3 + (finish ? 2 : 0); m.popularity += 2 + (finish ? 2 : 0) + 2 * hype; }
  else if (lost) { m.reputation -= 2; m.popularity -= 1 + 3 * hype; m.controversy += hype ? 3 : 0; }
  m.popularity = r1(clamp(m.popularity)); m.reputation = r1(clamp(m.reputation)); m.controversy = r1(clamp(m.controversy));
  let next: Fighter = { ...f, media: m };
  if (won) for (const s of sponsorsOf(f)) next = charge(next, `Premia sponsorska: ${s.name}`, s.winBonus);
  if (lost && hype) next = { ...next, log: addLog(next, 'Porażka po głośnych zapowiedziach. Media nie zostawiły suchej nitki.') };
  return next;
}

export interface SponsorTier { id: string; name: string; minPop: number; monthly: number; winBonus: number; maxControversy: number }
export const SPONSOR_TIERS: SponsorTier[] = [
  { id: 'local', name: 'Lokalna siłownia i sklep sportowy', minPop: 10, monthly: 400, winBonus: 150, maxControversy: 90 },
  { id: 'brand', name: 'Marka odzieży sportowej', minPop: 30, monthly: 1200, winBonus: 400, maxControversy: 70 },
  { id: 'global', name: 'Globalna marka napojów', minPop: 60, monthly: 3500, winBonus: 1500, maxControversy: 40 },
];
export const SPONSOR_MONTHS = 6;

export function sponsorOffers(f: Fighter): SponsorTier[] {
  const m = mediaOf(f), have = new Set(sponsorsOf(f).map((s) => s.id));
  return SPONSOR_TIERS.filter((t) => !have.has(t.id) && m.popularity >= t.minPop && m.controversy <= t.maxControversy);
}

export function signSponsor(f: Fighter, id: string): Fighter {
  const t = sponsorOffers(f).find((x) => x.id === id);
  if (!t) throw new Error('Ta oferta sponsorska jest niedostępna.');
  return { ...f, sponsors: [...sponsorsOf(f), { id: t.id, name: t.name, monthly: t.monthly, winBonus: t.winBonus, monthsLeft: SPONSOR_MONTHS, maxControversy: t.maxControversy }], log: addLog(f, `Nowy sponsor: ${t.name}.`) };
}

/** Początek miesiąca: pensje od sponsorów, wygasanie umów, zerwanie przy kontrowersjach, wygasanie sławy i skandali. */
export function monthlyMedia(f: Fighter): Fighter {
  const m = { ...mediaOf(f) };
  let next: Fighter = f;
  const kept: SponsorDeal[] = [];
  for (const s of sponsorsOf(f)) {
    if (m.controversy > s.maxControversy) { next = { ...next, log: addLog(next, `${s.name} zrywa umowę z powodu kontrowersji.`) }; continue; }
    next = charge(next, `Sponsor: ${s.name}`, s.monthly);
    if (s.monthsLeft > 1) kept.push({ ...s, monthsLeft: s.monthsLeft - 1 });
    else next = { ...next, log: addLog(next, `Umowa z ${s.name} dobiegła końca.`) };
  }
  m.popularity = r1(clamp(m.popularity - Math.max(1, m.popularity * 0.06) + (carIsStatus(f) ? 1 : 0))); m.controversy = r1(clamp(m.controversy - 4));
  return { ...next, sponsors: kept, media: m };
}
