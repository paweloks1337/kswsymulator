import { advanceDay, INJURY_DAYS } from './calendar';
import { charge } from './finance';
import { commuteFatigue, gymMultiplier, hasHomeGym } from './lifestyle';
import { fatigueMultiplier, gainMultiplier, injuryRiskMultiplier } from './staff';
import { mulberry32 } from './fighter';
import type { Attribute, Fighter, Injury, InjuryArea } from './types';

export interface Activity {
  id: string; label: string; intensity: 1 | 2 | 3;
  gains: Partial<Record<Attribute, number>>;
  fatigue: number; injuryRisk: number; areas: InjuryArea[]; restBonus?: number; cost: number;
}

// Każda sesja zajmuje 1 dzień i kosztuje (sala, trener, sprzęt).
export const ACTIVITIES: Activity[] = [
  { id: 'boxing', cost: 40, label: 'Trening bokserski', intensity: 2, gains: { boxing: 1.0, precision: 0.3, reflex: 0.2 }, fatigue: 18, injuryRisk: 0.03, areas: ['hand', 'shoulder'] },
  { id: 'kickboxing', cost: 40, label: 'Kickboxing', intensity: 2, gains: { kickboxing: 1.0, speed: 0.3, cardio: 0.2 }, fatigue: 18, injuryRisk: 0.035, areas: ['knee', 'muscle'] },
  { id: 'muaythai', cost: 45, label: 'Muay Thai', intensity: 2, gains: { muaythai: 1.0, durability: 0.3, strength: 0.2 }, fatigue: 20, injuryRisk: 0.04, areas: ['knee', 'ribs'] },
  { id: 'wrestling', cost: 50, label: 'Zapasy', intensity: 3, gains: { wrestling: 1.0, strength: 0.3, defense: 0.2 }, fatigue: 24, injuryRisk: 0.05, areas: ['shoulder', 'knee', 'ribs'] },
  { id: 'bjj', cost: 45, label: 'BJJ', intensity: 2, gains: { bjj: 1.0, fightIQ: 0.3, defense: 0.2 }, fatigue: 16, injuryRisk: 0.035, areas: ['shoulder', 'knee'] },
  { id: 'gym', cost: 30, label: 'Siłownia', intensity: 2, gains: { strength: 0.9, durability: 0.4 }, fatigue: 20, injuryRisk: 0.03, areas: ['muscle', 'shoulder'] },
  { id: 'cardio', cost: 10, label: 'Kondycja', intensity: 2, gains: { cardio: 1.0, speed: 0.2 }, fatigue: 15, injuryRisk: 0.02, areas: ['muscle', 'knee'] },
  { id: 'sparring', cost: 60, label: 'Sparing', intensity: 3, gains: { fightIQ: 0.7, defense: 0.5, reflex: 0.4, precision: 0.3, boxing: 0.2, wrestling: 0.2, bjj: 0.2 }, fatigue: 28, injuryRisk: 0.09, areas: ['head', 'hand', 'ribs', 'knee'] },
  { id: 'recovery', cost: 25, label: 'Regeneracja', intensity: 1, gains: {}, fatigue: 0, injuryRisk: 0, areas: [], restBonus: 25 },
];

export const MAX_TRAINING_FATIGUE = 90;
/** Mnożnik tempa rozwoju (wyznaczony symulacjami balansu). */
export const GAIN_SCALE = 1.3;

export type TrainResult =
  | { ok: true; fighter: Fighter; gains: Partial<Record<Attribute, number>>; injury?: Injury }
  | { ok: false; reason: string };

/** Malejące zyski: im więcej już wytrenowano dany atrybut, tym mniej daje kolejna sesja. */
export const diminishing = (trained: number) => 1 / (1 + trained / 15);

export function trainDay(f: Fighter, activityId: string, seed: number): TrainResult {
  const act = ACTIVITIES.find((a) => a.id === activityId);
  if (!act) return { ok: false, reason: 'Nieznana aktywność.' };
  if (act.id !== 'recovery' && f.condition.fatigue >= MAX_TRAINING_FATIGUE)
    return { ok: false, reason: 'Zbyt duże zmęczenie. Zrób regenerację.' };

  const cost = act.id === 'gym' && hasHomeGym(f) ? 0 : act.cost;
  if (f.money < cost) return { ok: false, reason: 'Brak środków na ten trening.' };
  const rng = mulberry32(seed);
  const fatigue = f.condition.fatigue;
  const injuryPenalty = f.injuries.length ? 0.5 : 1;
  const stats = { ...f.stats };
  const trained = { ...f.trained };
  const gains: Partial<Record<Attribute, number>> = {};

  for (const [a, base] of Object.entries(act.gains) as [Attribute, number][]) {
    const headroom = Math.min(1, Math.max(0, (f.potential + 10 - stats[a]) / 30));
    const g = GAIN_SCALE * base * diminishing(trained[a] ?? 0) * (1 - fatigue / 150) * injuryPenalty * headroom * gainMultiplier(f, a) * (act.id === 'gym' ? gymMultiplier(f, a) : 1);
    stats[a] = Math.min(100, Math.round((stats[a] + g) * 100) / 100);
    trained[a] = (trained[a] ?? 0) + base;
    gains[a] = Math.round(g * 100) / 100;
  }

  let injury: Injury | undefined;
  const risk = act.injuryRisk * injuryRiskMultiplier(f) * (1 + fatigue / 100) * (1 + (100 - f.condition.health) / 100);
  if (act.areas.length && rng() < risk) {
    const r = rng();
    const severity: Injury['severity'] = r < 0.65 ? 1 : r < 0.92 ? 2 : 3;
    const area = act.areas[Math.floor(rng() * act.areas.length)]!;
    injury = { area, severity, daysLeft: INJURY_DAYS[severity] };
  }

  const c = f.condition;
  const next: Fighter = {
    ...(cost > 0 ? charge(f, act.label, -cost) : f), stats, trained,
    injuries: injury ? [...f.injuries, injury] : f.injuries,
    condition: {
      ...c,
      fatigue: Math.min(100, c.fatigue + Math.round(act.fatigue * fatigueMultiplier(f)) + (act.id === 'recovery' ? 0 : commuteFatigue(f))),
      form: Math.min(100, c.form + (act.id === 'recovery' ? 0 : act.intensity)),
      health: Math.max(0, c.health - (injury ? injury.severity * 10 : 0)),
    },
  };
  return { ok: true, fighter: advanceDay(next, act.restBonus ?? 0), gains, injury };
}
