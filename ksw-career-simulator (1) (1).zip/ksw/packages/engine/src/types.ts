export const STYLES = ['boxing', 'kickboxing', 'muaythai', 'wrestling', 'bjj', 'mma'] as const;
export type Style = (typeof STYLES)[number];

export const STYLE_LABELS: Record<Style, string> = {
  boxing: 'Boks', kickboxing: 'Kickboxing', muaythai: 'Muay Thai',
  wrestling: 'Zapasy', bjj: 'BJJ', mma: 'MMA',
};

export const ATTRIBUTES = [
  'strength', 'speed', 'cardio', 'durability', 'precision', 'reflex',
  'boxing', 'kickboxing', 'muaythai', 'wrestling', 'bjj', 'defense', 'fightIQ',
] as const;
export type Attribute = (typeof ATTRIBUTES)[number];
export type Stats = Record<Attribute, number>;

export const ATTRIBUTE_LABELS: Record<Attribute, string> = {
  strength: 'Siła', speed: 'Szybkość', cardio: 'Kondycja', durability: 'Wytrzymałość fizyczna',
  precision: 'Precyzja', reflex: 'Refleks', boxing: 'Boks', kickboxing: 'Kickboxing',
  muaythai: 'Muay Thai', wrestling: 'Zapasy', bjj: 'BJJ', defense: 'Obrona', fightIQ: 'Inteligencja walki',
};

export type DominantHand = 'right' | 'left' | 'switch';

export const APPEARANCE_OPTIONS = {
  face: ['Kanciasta', 'Szczupła', 'Szeroka', 'Wyrzeźbiona'],
  hair: ['Łysy', 'Krótkie', 'Zaczes', 'Dłuższe', 'Irokez'],
  beard: ['Brak', 'Zarost', 'Broda', 'Pełna broda'],
  build: ['Szczupła', 'Atletyczna', 'Muskularna', 'Masywna'],
  tattoos: ['Brak', 'Ramiona', 'Tułów', 'Pełne'],
  kit: ['Czerwony', 'Czarny', 'Biały', 'Grafitowy'],
} as const;
export type Appearance = { [K in keyof typeof APPEARANCE_OPTIONS]: (typeof APPEARANCE_OPTIONS)[K][number] };

export interface FighterProfile {
  firstName: string;
  lastName: string;
  nickname: string;
  age: number;
  nationality: string;
  heightCm: number;
  weightKg: number;
  reachCm: number;
  dominantHand: DominantHand;
  style: Style;
  experienceYears: number;
  appearance: Appearance;
}

export interface WeightClass { id: string; name: string; maxKg: number }

export interface Condition {
  form: number; fatigue: number; health: number;
  confidence: number; stress: number; experience: number;
}

export interface Record_ { wins: number; losses: number; draws: number }

import type { FightState } from './fight';
export interface ActiveFight { state: FightState; opponentId: string }

export interface Fighter {
  id: string;
  profile: FighterProfile;
  weightClass: WeightClass;
  stats: Stats;
  condition: Condition;
  /** Ukryty potencjał rozwoju (40-99). Nie pokazywać graczowi wprost. */
  potential: number;
  record: Record_;
  createdAt: string;
  gameDate: string;
  /** Suma wykonanej pracy na atrybut, podstawa malejących zysków. */
  trained: Partial<Record<Attribute, number>>;
  injuries: Injury[];
  money: number;
  staff: StaffMember[];
  lifestyle?: Lifestyle;
  media?: MediaState;
  sponsors?: SponsorDeal[];
  log?: LogEntry[];
  ledger: LedgerEntry[];
  contract: Contract | null;
  nextFight: ScheduledFight | null;
  /** Walka w toku (po rundzie, z możliwością zmiany taktyki). */
  activeFight?: ActiveFight | null;
  history: FightHistoryEntry[];
}

export type InjuryArea = 'hand' | 'knee' | 'shoulder' | 'muscle' | 'ribs' | 'head';
export const INJURY_LABELS: Record<InjuryArea, string> = {
  hand: 'Dłoń', knee: 'Kolano', shoulder: 'Bark', muscle: 'Uraz mięśnia', ribs: 'Żebra', head: 'Głowa',
};
export interface Injury { area: InjuryArea; severity: 1 | 2 | 3; daysLeft: number }

export interface LedgerEntry { date: string; label: string; amount: number }
export interface Contract { federationId: string; fightsLeft: number; purse: number; winBonus: number; koBonus: number; subBonus: number }
export interface ScheduledFight { date: string; opponentId: string; federationId: string; hype?: number; faceOff?: boolean; press?: boolean }
export interface FightHistoryEntry { date: string; opponent: string; result: 'W' | 'L' | 'D'; method: string; round: number; federationId: string }
export interface Federation { id: string; name: string; prestige: 1 | 2 | 3; purseBase: number; minWins: number; minRating: number }
export interface Npc { id: string; name: string; age: number; weightClassId: string; federationId: string; stats: Stats; record: Record_; potential?: number; injuredDays?: number }
export interface WorldNews { date: string; text: string }
export interface TitleHolder { holderId: string; since: string }
export interface World {
  federations: Federation[]; npcs: Npc[];
  /** Data w świecie NPC (stan symulacji). */
  date?: string; news?: WorldNews[];
  /** Mistrzowie: klucz `${federacja}:${kategoria}`. */
  titles?: Record<string, TitleHolder>;
}

export type StaffRole = 'head' | 'boxing' | 'wrestling' | 'bjj' | 'fitness' | 'physio' | 'manager';
export interface StaffMember {
  id: string; name: string; role: StaffRole;
  skill: number; experience: number; reputation: number;
  /** Pensja miesięczna. */
  salary: number;
  /** 0-100, rośnie z każdym przepracowanym miesiącem. */
  cooperation: number;
}

export interface MediaState { popularity: number; reputation: number; charisma: number; controversy: number; lastActionDate: string | null; /** Zmęczenie medialne: powtarzane akcje dają coraz mniej. */ fatigue?: number }
export interface SponsorDeal { id: string; name: string; monthly: number; winBonus: number; monthsLeft: number; maxControversy: number }
export interface LogEntry { date: string; text: string }

export type HousingId = 'room' | 'flat' | 'penthouse' | 'house';
export type CarId = 'none' | 'used' | 'sport';
export interface Lifestyle { housing: HousingId; car: CarId; gym: 0 | 1 | 2 }
